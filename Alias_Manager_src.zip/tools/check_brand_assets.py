#!/usr/bin/env python3
"""Measure (not eyeball) the Orbit icon assets. Exit code 1 on any failure.   python3 tools/check_brand_assets.py"""
import json, sys
from pathlib import Path
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
fails = []
def check(ok, msg):
    print(("PASS  " if ok else "FAIL  ") + msg)
    if not ok: fails.append(msg)

def img(rel, mode="RGBA"):
    return Image.open(ROOT / rel).convert(mode)

# 1. sizes
for rel, size in {"assets/icon.png": 1024, "assets/icon-foreground.png": 1024, "assets/icon-background.png": 1024,
                  "assets/splash.png": 2732, "www/icon-192.png": 192, "www/icon-512.png": 512,
                  "www/icon-maskable-192.png": 192, "www/icon-maskable-512.png": 512, "www/logo-192.png": 192,
                  "native/res/drawable-nodpi/orbit_icon_fg.png": 648, "native/res/mipmap-nodpi/orbit_launcher.png": 192}.items():
    check(img(rel).size == (size, size), "%s is %dx%d" % (rel, size, size))

# 2. background layers are pure black
bg = np.array(img("assets/icon-background.png", "RGB"))
check(bg.max() == 0, "assets/icon-background.png is pure black (max channel = %d)" % bg.max())
xml = (ROOT / "native/res/drawable/orbit_icon_bg.xml").read_text()
check("#FF000000" in xml, "native orbit_icon_bg.xml is solid #FF000000")

# 3. foreground over black == approved artwork (the layer is lossless apart from near-black noise)
fg = img("native/res/drawable-nodpi/orbit_icon_fg.png")
comp = Image.new("RGBA", fg.size, (0, 0, 0, 255)); comp.alpha_composite(fg)
comp = np.array(comp.convert("RGB")).astype(int)
master = Image.open(ROOT / "tools/brand/Orbit_Icon_Master_1536.png").convert("RGB")
f = (34.0 / 726.0) * 6
n = round(1536 * f); ox = round(324 - 781 * f); oy = round(324 - 738 * f)
ref = Image.new("RGB", (648, 648), (0, 0, 0)); ref.paste(master.resize((n, n), Image.LANCZOS), (ox, oy))
ref = np.array(ref).astype(int)
diff = np.abs(comp - ref)
check(diff.max() <= 6, "adaptive foreground over black matches the scaled master (max channel diff %d, mean %.3f)" % (diff.max(), diff.mean()))

# 4. mask clipping: how much visible mark falls outside each launcher mask (72 dp visible window, 6 px/dp)
lum = comp.max(axis=2)
S = 648; yy, xx = np.mgrid[0:S, 0:S]; u = (xx + .5 - S / 2) / 216.0; v = (yy + .5 - S / 2) / 216.0   # 216 px = 36 dp
masks = {"circle": u ** 2 + v ** 2 <= 1, "squircle": u ** 4 + v ** 4 <= 1}
r = np.minimum(np.abs(u), np.abs(v)); rr = 0.44   # rounded square, corner radius 0.22 of the side
cx = np.clip(np.abs(u) - (1 - rr), 0, None); cy = np.clip(np.abs(v) - (1 - rr), 0, None)
masks["rounded-square"] = (np.abs(u) <= 1) & (np.abs(v) <= 1) & (cx ** 2 + cy ** 2 <= rr ** 2)
for k, m in masks.items():
    outside = ((lum > 40) & ~m).sum(); glow = ((lum > 12) & ~m).sum()
    check(outside == 0, "%s mask: %d bright mark pixels (>40) outside the visible window; %d faint glow pixels (>12)" % (k, outside, glow))
ys, xs = np.where(lum > 40)
rad_dp = np.hypot(xs - S / 2, ys - S / 2).max() / 6
check(rad_dp <= 35.0, "mark core radius = %.2f dp (safe zone 33, visible circle 36)" % rad_dp)
bw = (xs.max() - xs.min() + 1) / 6; bh = (ys.max() - ys.min() + 1) / 6
check(bw >= 58, "mark is %.1f x %.1f dp inside the 72 dp visible area (%.0f%% of its width)" % (bw, bh, bw / 72 * 100))
cen = ((xs.min() + xs.max()) / 2 / 6 - 54, (ys.min() + ys.max()) / 2 / 6 - 54)
check(abs(cen[0]) < 3 and abs(cen[1]) < 3, "bbox centre offset from canvas centre = (%.1f, %.1f) dp" % cen)

# 5. maskable PWA icons: mark inside the 40% safe-zone circle
for s in (192, 512):
    a = np.array(img("www/icon-maskable-%d.png" % s, "RGB")).astype(int).max(axis=2)
    ys, xs = np.where(a > 40)
    rad = np.hypot(xs - s / 2, ys - s / 2).max() / s
    check(rad <= 0.405, "icon-maskable-%d mark radius = %.3f of the side (limit 0.40)" % (s, rad))

# 6. 'any' icons keep the whole composition (no cropping): bright pixels never touch the edge
for rel in ("www/icon-512.png", "www/icon-192.png", "assets/icon.png"):
    a = np.array(img(rel, "RGB")).astype(int).max(axis=2); e = max(2, a.shape[0] // 100)
    edge = max(a[:e].max(), a[-e:].max(), a[:, :e].max(), a[:, -e:].max())
    check(edge <= 12, "%s: nothing bright at the outer edge (max %d)" % (rel, edge))

# 7. splash: pure black with the mark centred, ~34% wide
sp = np.array(img("assets/splash.png", "RGB")).astype(int).max(axis=2)
ys, xs = np.where(sp > 40)
w = (xs.max() - xs.min() + 1) / 2732
check(0.30 <= w <= 0.38, "splash mark width = %.1f%% of the canvas" % (w * 100))
check(sp[:50, :50].max() == 0, "splash corner is pure black")

# 8. manifest / sw reference files that exist
man = json.loads((ROOT / "www/manifest.json").read_text())
for ic in man["icons"]:
    check((ROOT / "www" / ic["src"]).exists(), "manifest icon exists: %s (%s)" % (ic["src"], ic.get("purpose")))
sw = (ROOT / "www/sw.js").read_text()
for ic in man["icons"]:
    check("/" + ic["src"] in sw, "sw.js precaches /%s" % ic["src"])

print("\n%d failure(s)" % len(fails))
sys.exit(1 if fails else 0)
