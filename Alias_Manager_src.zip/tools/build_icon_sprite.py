#!/usr/bin/env python3
"""Build the inline SVG icon sprite for www/index.html from the Orbit Icon Pack V3 (SVG folder).

  python3 tools/build_icon_sprite.py /path/to/Orbit_Icon_Pack_V3_Complete/SVG  > sprite.txt

The pack is two-tone lavender (#DCD4F8 + #AA8CFF). Here the primary stroke becomes currentColor and the
accent stroke/fill becomes var(--ic-accent, currentColor), so by default every icon is ONE colour (quiet,
consistent) and a surface can opt in to a cyan accent with the class .ic-duo.
Symbol ids are short names; ids that the old UI already used (plus, search, check, refresh, gear, open, copy,
star, star-on, edit, trash, skip, orbit) are kept so no JS / markup has to change.
"""
import re, sys
from pathlib import Path

GEAR_PATH = "M9.87 5.02 L10.20 2.27 L13.80 2.27 L14.13 5.02 L15.43 5.55 L17.61 3.84 L20.16 6.39 L18.45 8.57 L18.98 9.87 L21.73 10.20 L21.73 13.80 L18.98 14.13 L18.45 15.43 L20.16 17.61 L17.61 20.16 L15.43 18.45 L14.13 18.98 L13.80 21.73 L10.20 21.73 L9.87 18.98 L8.57 18.45 L6.39 20.16 L3.84 17.61 L5.55 15.43 L5.02 14.13 L2.27 13.80 L2.27 10.20 L5.02 9.87 L5.55 8.57 L3.84 6.39 L6.39 3.84 L8.57 5.55Z"

MAP = {  # symbol id : pack file (folder/name)
    # ids already used by the dashboard
    "plus": "Actions/action_add", "search": "Navigation/nav_search", "check": "Controls/control_checkbox_checked",
    "refresh": "Actions/action_refresh", "gear": "System/sys_settings", "open": "System/sys_globe",
    "copy": "Actions/action_copy", "star": "Files/file_favorite", "edit": "Actions/action_edit", "trash": "Actions/action_delete",
    # navigation
    "close": "Navigation/nav_close", "chev-down": "Navigation/nav_chevron_down", "chev-up": "Navigation/nav_chevron_up",
    "chev-left": "Navigation/nav_chevron_left", "chev-right": "Navigation/nav_chevron_right", "menu": "Navigation/nav_menu",
    "more": "Navigation/nav_more_horizontal", "more-v": "Navigation/nav_more_vertical", "filter": "Navigation/nav_filter",
    "sort": "Navigation/nav_sort", "back": "Navigation/nav_back", "forward": "Navigation/nav_forward", "home": "Navigation/nav_home",
    "list": "Navigation/nav_list_view", "grid": "Navigation/nav_grid_view", "tabs": "Navigation/nav_tabs",
    "browser": "Navigation/nav_browser_window", "sidebar": "Navigation/nav_sidebar",
    # system
    "accounts": "System/sys_accounts", "profile": "System/sys_profile", "bell": "System/sys_notifications", "help": "System/sys_help",
    "info": "System/sys_info", "dashboard": "System/sys_dashboard", "widgets": "System/sys_widgets", "display": "System/sys_display",
    "sun": "System/sys_theme_light", "moon": "System/sys_theme_dark", "theme-auto": "System/sys_theme_auto", "lock": "System/sys_lock",
    "unlock": "System/sys_unlock", "shield": "System/sys_shield", "shield-check": "System/sys_shield_check", "key": "System/sys_key",
    "battery": "System/sys_battery", "pin": "System/sys_pin", "apps": "System/sys_apps",
    # actions
    "minus": "Actions/action_remove", "paste": "Actions/action_paste", "duplicate": "Actions/action_duplicate",
    "share": "Actions/action_share", "link": "Actions/action_link", "link-alias": "Actions/action_link_alias",
    "external": "Actions/action_external", "save": "Actions/action_save", "download": "Actions/action_download",
    "upload": "Actions/action_upload", "import": "Actions/action_import", "export": "Actions/action_export",
    "undo": "Actions/action_undo", "redo": "Actions/action_redo", "reset": "Actions/action_reset",
    "expand": "Actions/action_expand", "collapse": "Actions/action_collapse", "fullscreen": "Actions/action_fullscreen",
    # status
    "ok": "Status/status_success", "warn": "Status/status_warning", "error": "Status/status_error", "pending": "Status/status_pending",
    "loading": "Status/status_loading", "sync": "Status/status_syncing", "offline": "Status/status_offline", "online": "Status/status_online",
    "connected": "Status/status_connected", "disconnected": "Status/status_disconnected", "update": "Status/status_update_available",
    "disabled": "Status/status_disabled", "show": "Status/status_show", "hide": "Status/status_hide",
    # controls / files / ai
    "toggle-on": "Controls/control_toggle_on", "toggle-off": "Controls/control_toggle_off", "box-on": "Controls/control_checkbox_checked",
    "box-off": "Controls/control_checkbox_unchecked", "radio-on": "Controls/control_radio_selected", "radio-off": "Controls/control_radio_unselected",
    "clock": "Controls/control_clock", "calendar": "Controls/control_calendar", "dropdown": "Controls/control_dropdown",
    "folder": "Files/file_folder", "file": "Files/file_file", "image": "Files/file_image", "archive": "Files/file_archive",
    "attach": "Files/file_attachment", "rename": "Files/file_rename", "bookmark": "Files/file_bookmark", "history": "Files/file_history",
    "spark": "AI_Optional/ai_spark", "chat": "AI_Optional/ai_chat", "new-chat": "AI_Optional/ai_new_chat", "send": "AI_Optional/ai_send",
}
WRAP = 'fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"'


def convert(svg_text):
    body = re.search(r"<svg[^>]*>(.*)</svg>", svg_text, re.S).group(1)
    body = re.sub(r"<title>.*?</title>", "", body, flags=re.S)
    body = re.sub(r'\s+stroke="#DCD4F8"', "", body)                         # primary stroke -> inherited currentColor
    body = re.sub(r'\s+fill="#DCD4F8"', ' fill="currentColor"', body)
    body = re.sub(r'\s+stroke="#AA8CFF"', ' class="ia"', body)              # accent stroke
    body = re.sub(r'<(\w+)([^>]*?)\s+fill="#AA8CFF"([^>]*?)/>',             # accent fill (dots)
                  lambda m: "<%s%s%s class=\"ifa\"/>" % (m.group(1), m.group(2), m.group(3)), body)
    assert "#" not in body, body
    return body.strip()


def main(pack):
    pack = Path(pack)
    out = []
    for sid, rel in MAP.items():
        body = convert((pack / (rel + ".svg")).read_text())
        if sid == "gear":  # Batch 7: the pack's settings icon (circle + rays) looked like a sun; use a real cog (8 teeth + hub)
            body = '<path d="%s"/><circle cx="12" cy="12" r="3.1" class="ia"/>' % GEAR_PATH
        out.append('<symbol id="i-%s" viewBox="0 0 24 24"><g %s>%s</g></symbol>' % (sid, WRAP, body))
    # filled star (pinned state) = the pack star with a solid fill
    star = convert((pack / "Files/file_favorite.svg").read_text())
    out.append('<symbol id="i-star-on" viewBox="0 0 24 24"><g %s>%s</g></symbol>' % (WRAP.replace('fill="none"', 'fill="currentColor"'), star))
    # kept from the previous UI (no pack equivalent): next/skip and the planet glyph
    out.append('<symbol id="i-skip" viewBox="0 0 24 24"><g %s><path d="M6 6l8 6-8 6zM17.5 6v12"/></g></symbol>' % WRAP)
    out.append('<symbol id="i-orbit" viewBox="0 0 24 24"><g %s><circle cx="12" cy="12" r="3.2" fill="currentColor"/>'
               '<ellipse cx="12" cy="12" rx="9.5" ry="4" transform="rotate(-24 12 12)"/><circle cx="19" cy="7.4" r="1.4" fill="currentColor"/></g></symbol>' % WRAP)
    print("\n".join("      " + s for s in out))


if __name__ == "__main__":
    main(sys.argv[1])
