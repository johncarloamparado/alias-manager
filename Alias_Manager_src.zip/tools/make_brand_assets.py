#!/usr/bin/env python3
"""Generate every Orbit icon / splash asset from the ONE approved master artwork.

  python3 tools/make_brand_assets.py [--preview out.png]

Source : tools/brand/Orbit_Icon_Master_1536.png  (user-approved artwork, pure black background)
Writes : assets/{icon,icon-foreground,icon-background,splash}.png
         www/{icon-192,icon-512,icon-maskable-192,icon-maskable-512,logo-192}.png
         native/res/drawable-nodpi/orbit_icon_fg.png, native/res/mipmap-nodpi/orbit_launcher.png

The artwork is never cropped, stretched, recoloured or redrawn: it is only scaled uniformly and
placed. The mark is wide, so every composition is sized by the radius of the circle that encloses
the mark (the diagonal ellipse tips are the farthest points), not by its bounding box.
"""
import sys
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "tools" / "brand" / "Orbit_Icon_Master_1536.png"

# Visual centre of the mark in the 1536 master: midpoint of the bbox centre (771.5, 736) and the
# luminance centroid (790, 741). Measured, not guessed.
CX, CY = 781.0, 738.0
R_CORE = 726.0           # px: radius around (CX, CY) that encloses every pixel with brightness > 40
SRC_SIZE = 1536

ADAPTIVE_R_DP = 34.0     # core radius on the 108 dp adaptive canvas (safe zone r=33, visible circle r=36)
MASKABLE_R = 0.40        # PWA maskable safe zone: circle of 80% diameter
LEGACY_R = 0.45          # pre-Android-8 launcher icon
SPLASH_MARK_W = 0.34     # mark width as a share of the splash width
MARK_W_SRC = 1310.0      # px: width of the mark's bounding box in the master (brightness > 40)


def load_master():
    im = Image.open(SRC).convert("RGB")
    assert im.size == (SRC_SIZE, SRC_SIZE), im.size
    return im


def place(master, canvas, f, rgba=False):
    """Scale master uniformly by f and place it so (CX, CY) lands on the canvas centre."""
    n = max(1, round(SRC_SIZE * f))
    art = master.resize((n, n), Image.LANCZOS)
    ox = round(canvas / 2 - CX * f)
    oy = round(canvas / 2 - CY * f)
    out = Image.new("RGB", (canvas, canvas), (0, 0, 0))
    out.paste(art, (ox, oy))
    if not rgba:
        return out
    # Transparent layer whose alpha is the mark's own brightness. Composited over pure black it
    # reproduces the approved artwork exactly (checked in tests); keeps parallax layers clean.
    a = np.array(out).astype(np.float32)
    alpha = a.max(axis=2)
    alpha[alpha < 3] = 0
    safe = np.where(alpha > 0, alpha, 1)[..., None]
    rgb = np.clip(a * 255.0 / safe, 0, 255)
    res = np.dstack([rgb, alpha]).astype(np.uint8)
    return Image.fromarray(res, "RGBA")


def save(img, rel):
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    img.save(p, optimize=True)
    print("wrote %-48s %dx%d" % (rel, img.size[0], img.size[1]))


def main():
    m = load_master()

    # --- Android adaptive icon (108 dp canvas) ---
    f_ad = ADAPTIVE_R_DP / R_CORE                      # canvas dp per source px
    save(place(m, 648, f_ad * 6, rgba=True), "native/res/drawable-nodpi/orbit_icon_fg.png")   # 6 px/dp
    save(place(m, 1024, f_ad * (1024 / 108), rgba=True), "assets/icon-foreground.png")
    save(Image.new("RGB", (1024, 1024), (0, 0, 0)), "assets/icon-background.png")

    # --- legacy launcher icon (Android 6-7), whole square visible ---
    save(place(m, 192, LEGACY_R * 192 / R_CORE), "native/res/mipmap-nodpi/orbit_launcher.png")

    # --- Capacitor source icon + PWA "any" icons: the approved artwork as supplied ---
    save(m.resize((1024, 1024), Image.LANCZOS), "assets/icon.png")
    save(m.resize((512, 512), Image.LANCZOS), "www/icon-512.png")
    save(m.resize((192, 192), Image.LANCZOS), "www/icon-192.png")
    save(m.resize((192, 192), Image.LANCZOS), "www/logo-192.png")        # in-app brand tile (clipped round in SVG)

    # --- PWA maskable icons ---
    for s in (192, 512):
        save(place(m, s, MASKABLE_R * s / R_CORE), "www/icon-maskable-%d.png" % s)

    # --- splash ---
    save(place(m, 2732, SPLASH_MARK_W * 2732 / MARK_W_SRC), "assets/splash.png")

    if "--preview" in sys.argv:
        preview(sys.argv[sys.argv.index("--preview") + 1])


def preview(out_path):
    """Contact sheet: the real adaptive icon under circle / squircle / rounded-square masks."""
    fg = Image.open(ROOT / "native/res/drawable-nodpi/orbit_icon_fg.png").convert("RGBA")
    S = 648                                             # 6 px per dp
    base = Image.new("RGBA", (S, S), (0, 0, 0, 255))
    base.alpha_composite(fg)
    vis = 72 * 6
    off = (S - vis) // 2

    def mask(kind, size, ss=4):
        big = size * ss
        mk = Image.new("L", (big, big), 0)
        d = ImageDraw.Draw(mk)
        if kind == "circle":
            d.ellipse((0, 0, big - 1, big - 1), fill=255)
        elif kind == "rounded":
            d.rounded_rectangle((0, 0, big - 1, big - 1), radius=int(big * 0.22), fill=255)
        else:  # squircle: superellipse |x|^4 + |y|^4 <= 1
            yy, xx = np.mgrid[0:big, 0:big]
            u = (xx + .5) / big * 2 - 1
            v = (yy + .5) / big * 2 - 1
            mk = Image.fromarray(((u ** 4 + v ** 4) <= 1).astype(np.uint8) * 255, "L")
        return mk.resize((size, size), Image.LANCZOS)

    tiles = []
    for kind in ("circle", "squircle", "rounded"):
        crop = base.crop((off, off, off + vis, off + vis))
        tile = Image.new("RGBA", (vis, vis), (0, 0, 0, 0))
        tile.paste(crop, (0, 0), mask(kind, vis))
        tiles.append((kind, tile))

    pad = 28
    sheet = Image.new("RGB", (pad + 3 * (vis + pad), vis + pad * 2 + 140), (46, 48, 56))
    d = ImageDraw.Draw(sheet)
    for i, (kind, tile) in enumerate(tiles):
        x = pad + i * (vis + pad)
        sheet.paste(tile, (x, pad), tile)
        d.text((x, pad + vis + 8), kind, fill=(220, 224, 235))
    # small sizes row (48 dp-ish) to judge recognisability
    x = pad
    for kind, tile in tiles:
        small = tile.resize((96, 96), Image.LANCZOS)
        sheet.paste(small, (x, pad + vis + 40), small)
        x += 120
    sheet.save(out_path)
    print("preview ->", out_path)


if __name__ == "__main__":
    main()
