import javax.tools.*;
import com.sun.source.util.JavacTask;
import java.util.*;
import java.io.*;
import java.net.URI;
import java.nio.file.*;

/**
 * Symbol-level Java check that works WITHOUT the Android SDK.
 *
 *   java tools/JavaSymbolGate.java --record tools/java_symbols.baseline native/java/*.java     (after reviewing every NEW symbol)
 *   java tools/JavaSymbolGate.java --check  tools/java_symbols.baseline native/java/*.java     (exit 1 = real error or new symbol to review)
 *
 * It runs a full javac analysis of the 5 native files together. Android classes do not exist here, so ~1,200 "cannot find symbol" / "package does not exist"
 * errors are the normal baseline. What this gate adds over ParseJava (syntax only):
 *   1. any error of another kind (wrong arguments to one of OUR methods, incompatible types between OUR types, missing return, duplicate variable, ...) FAILS;
 *   2. any NEW unresolved symbol that is not in the baseline is listed: a typo in one of our own constants/methods/variables shows up here as a brand-new name,
 *      and a first-time use of an Android API shows up so it can be checked by hand.
 * It CANNOT see: a wrong method name or wrong argument type on an Android object (its type is unknown here), or anything that only Gradle/AAPT would catch.
 */
public class JavaSymbolGate {
    public static void main(String[] a) throws Exception {
        String mode = a[0], baseFile = a[1];
        JavaCompiler c = ToolProvider.getSystemJavaCompiler();
        List<JavaFileObject> fos = new ArrayList<>();
        Map<String, String> sources = new HashMap<>();
        for (int i = 2; i < a.length; i++) {
            final String src = new String(Files.readAllBytes(Paths.get(a[i])), "UTF-8").replace("__PACKAGE__", "com.aliasmanager.app");
            sources.put(new File(a[i]).getName(), src);
            fos.add(new SimpleJavaFileObject(URI.create("string:///" + new File(a[i]).getName()), JavaFileObject.Kind.SOURCE) { public CharSequence getCharContent(boolean b) { return src; } });
        }
        DiagnosticCollector<JavaFileObject> d = new DiagnosticCollector<>();
        JavacTask t = (JavacTask) c.getTask(null, null, d, Arrays.asList("-proc:none", "-Xmaxerrs", "100000", "-Xmaxwarns", "0"), null, fos);
        t.parse(); t.analyze();
        Set<String> resolution = new HashSet<>(Arrays.asList("compiler.err.cant.resolve", "compiler.err.cant.resolve.location", "compiler.err.cant.resolve.location.args",
            "compiler.err.cant.resolve.args", "compiler.err.doesnt.exist", "compiler.err.invalid.mref", "compiler.err.method.does.not.override.superclass",
            "compiler.err.cant.resolve.location.args.params"));
        TreeMap<String, String> keys = new TreeMap<>();   // key -> first "file:line"
        List<String> real = new ArrayList<>();
        for (Diagnostic<? extends JavaFileObject> x : d.getDiagnostics()) {
            if (x.getKind() != Diagnostic.Kind.ERROR) continue;
            String where = x.getSource().getName() + ":" + x.getLineNumber();
            String msg = x.getMessage(null).replace("com.aliasmanager.app.", "");
            if (!resolution.contains(x.getCode())) { real.add(where + " [" + x.getCode().replace("compiler.err.", "") + "] " + msg.replace("\n", " | ")); continue; }
            String norm = msg.replace("\r", "").replaceAll("\\s*\n\\s*", " | ").replaceAll("\\s+", " ");
            if ("compiler.err.doesnt.exist".equals(x.getCode())) {   // add WHICH qualified name was used, so a first-time android.x.Y is listed even if package android.x was seen before
                String src = sources.get(x.getSource().getName().replaceFirst("^/", "")); long st = x.getStartPosition(), en = x.getEndPosition();
                if (src != null && st >= 0 && en > st && en <= src.length()) norm += " | uses: " + src.substring((int) st, (int) en).replaceAll("\\s+", "");
            }
            keys.putIfAbsent(x.getSource().getName() + " | " + x.getCode().replace("compiler.err.", "") + " | " + norm, where);
        }
        if (mode.equals("--record")) {
            Files.write(Paths.get(baseFile), keys.keySet(), java.nio.charset.StandardCharsets.UTF_8);
            System.out.println("recorded " + keys.size() + " distinct unresolved symbols (the Android baseline) -> " + baseFile);
            if (!real.isEmpty()) { System.out.println("WARNING: " + real.size() + " real (non-resolution) errors exist right now:"); for (String r : real) System.out.println("  " + r); }
            return;
        }
        Set<String> base = new HashSet<>(Files.readAllLines(Paths.get(baseFile), java.nio.charset.StandardCharsets.UTF_8));
        List<String> fresh = new ArrayList<>(), gone = new ArrayList<>();
        for (Map.Entry<String, String> e : keys.entrySet()) if (!base.contains(e.getKey())) fresh.add(e.getValue() + "  " + e.getKey());
        for (String b : base) if (!keys.containsKey(b)) gone.add(b);
        System.out.println("analysed " + (a.length - 2) + " files: " + keys.size() + " distinct unresolved symbols (baseline " + base.size() + "), " + real.size() + " real errors");
        for (String r : real) System.out.println("REAL ERROR  " + r);
        for (String f : fresh) System.out.println("NEW SYMBOL  " + f);
        if (!gone.isEmpty()) System.out.println("(" + gone.size() + " baseline symbols no longer used - harmless; re-record the baseline when you are done)");
        if (!real.isEmpty() || !fresh.isEmpty()) { System.out.println(real.isEmpty() ? "NEW SYMBOLS: verify each is a real Android/AndroidX API or a name you defined, then --record." : "FAILED"); System.exit(1); }
        System.out.println("SYMBOL GATE OK (no real errors, no new unresolved symbols)");
    }
}
