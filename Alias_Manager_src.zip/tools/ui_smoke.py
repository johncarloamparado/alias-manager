#!/usr/bin/env python3
"""Real-browser smoke test for the Orbit dashboard (headless Chromium via Playwright). Exit 1 on any FAIL.

  python3 tools/ui_smoke.py [screenshot_dir]

Serves www/ on localhost, seeds localStorage in the REAL stored format (alias_manager_v5 / alias_manager_settings),
and drives the existing UI. The native Capacitor plugin does not exist here, so native-only paths are NOT covered.
Batch 2 version: new dashboard (summary tiles, counts, empty states, compact mode, bulk tap), layout at 320 px / 200% font / tablet,
touch targets, keyboard focus, accessible names, contrast measured on live elements with translucent backgrounds blended.
"""
import json, sys, threading, time, http.server, socketserver, functools, io
from pathlib import Path
import numpy as np
from PIL import Image
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("/tmp/orbit_shots")
OUT.mkdir(parents=True, exist_ok=True)
fails = []
def check(ok, msg):
    print(("PASS  " if ok else "FAIL  ") + msg)
    if not ok: fails.append(msg)

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
handler = functools.partial(Quiet, directory=str(ROOT / "www"))
# Threaded on purpose: Chromium opens idle pre-connect sockets, and a single-threaded server would block the next page load (intermittent goto timeouts).
socketserver.ThreadingTCPServer.allow_reuse_address = True
socketserver.ThreadingTCPServer.daemon_threads = True
srv = socketserver.ThreadingTCPServer(("127.0.0.1", 0), handler)
URL = "http://127.0.0.1:%d/" % srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

H = 3600 * 1000
now = int(time.time() * 1000)
def alias(i, email, note, **kw):
    a = dict(id="t%d" % i, email=email, note=note, tags=[], color="", services=["claude"], manual={}, auto={}, timers={},
             pinned=False, isCurrent=False, created=now - i * 86400000, lastUsed=None, history=[])
    a.update(kw); return a
ALIASES = [
    alias(1, "work.one@duck.com", "Claude 1", lastUsed=now - 1 * H, manual={"claude": now}, pinned=True, tags=["work"], color="#7c9cff", history=[now - 1 * H]),
    alias(2, "work.two@duck.com", "Claude 2", lastUsed=now - 6 * H, manual={"claude": now}, tags=["work", "test"]),
    alias(3, "fresh.three@duck.com", "", services=["claude", "chatgpt"]),
    alias(4, "multi.four@duck.com", "Multi", services=["claude", "chatgpt", "gemini", "grok"], manual={"claude": now, "chatgpt": now}, timers={"chatgpt": now - 2 * H}, color="#4ade80"),
    alias(5, "a.very.long.address.that.must.truncate.safely@example-domain.com", "Long address", services=["perplexity", "deepseek", "mistral"]),
    alias(6, "idle.six@duck.com", "Idle six", manual={"claude": now}),
]
N = len(ALIASES)   # 6: running 2 (1,4) | ready 1 (2) | pinned 1 | not started 3 (3,5,6) | needs connect 3 (3,4,5)
SETTINGS = dict(autoRefresh=0, theme="dark", readyAlert=0, orbitAutoStart=1, orbitKeep=2, lastBackup=now, alertedReady={}, hours={}, appLock=0)

def lum(c):
    f = lambda v: (v / 255.0 / 12.92) if v / 255.0 <= 0.03928 else (((v / 255.0) + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2])
def ratio(a, b):
    la, lb = lum(a), lum(b)
    if la < lb: la, lb = lb, la
    return (la + 0.05) / (lb + 0.05)

JS_COLORS = """(sel) => {
  const el = document.querySelector(sel); if (!el) return null;
  const parse = s => { const m = s.match(/rgba?\\(([^)]+)\\)/); if (!m) return null; const p = m[1].split(',').map(x => parseFloat(x)); return {r:p[0], g:p[1], b:p[2], a: p.length > 3 ? p[3] : 1}; };
  const layers = []; let n = el; while (n) { const c = parse(getComputedStyle(n).backgroundColor); if (c && c.a > 0) layers.push(c); n = n.parentElement; }
  layers.reverse(); let base = {r: 0, g: 0, b: 0};
  layers.forEach(c => { base = {r: c.r * c.a + base.r * (1 - c.a), g: c.g * c.a + base.g * (1 - c.a), b: c.b * c.a + base.b * (1 - c.a)}; });
  let fg = parse(getComputedStyle(el).color); if (fg.a < 1) fg = {r: fg.r * fg.a + base.r * (1 - fg.a), g: fg.g * fg.a + base.g * (1 - fg.a), b: fg.b * fg.a + base.b * (1 - fg.a), a: 1};
  return {fg, bg: base};
}"""

errors = []
with sync_playwright() as p:
    br = p.chromium.launch()
    def new_page(theme="dark", aliases=ALIASES, settings=None, w=390, h=844, reduced=False):
        """A FRESH browser context (own localStorage) per page, so tests never leak state into each other."""
        c = br.new_context(viewport={"width": w, "height": h}, device_scale_factor=2, is_mobile=w < 700, has_touch=True, service_workers="block",
                           reduced_motion="reduce" if reduced else "no-preference")
        pg = c.new_page()
        pg.on("pageerror", lambda e: errors.append("pageerror: %s" % e))
        pg.on("console", lambda m: errors.append("console.error: %s" % m.text) if m.type == "error" else None)
        s = dict(SETTINGS); s["theme"] = theme
        if settings: s.update(settings)
        pg.add_init_script("if (!localStorage.getItem('__seeded')) { localStorage.setItem('__seeded', '1'); localStorage.setItem('alias_manager_v5', %s); localStorage.setItem('alias_manager_settings', %s); }" % (json.dumps(json.dumps(aliases)), json.dumps(json.dumps(s))))
        pg.goto(URL); pg.wait_for_selector(".card, #empty", state="attached"); pg.wait_for_timeout(250)
        return pg
    def shot(pg, name, full=True):
        pg.wait_for_timeout(420); pg.screenshot(path=str(OUT / name), full_page=full)
    def hscroll(pg):
        return pg.evaluate("document.documentElement.scrollWidth - window.innerWidth")

    # ---- 1. three themes: render, meta, contrast on live elements (translucent backgrounds blended) ----
    PAIRS = {".card-title": "card title", ".card .email": "card email", ".badge-info": "running badge", ".badge-ok": "ready badge", ".badge-warn": "needs-sign-in badge",
             ".status-row .badge:not(.badge-info):not(.badge-ok):not(.badge-warn)": "not-started badge", ".stat-label": "summary label", ".filter-btn:not(.active)": "filter chip",
             ".filter-btn.active": "active filter chip", ".svc.off .svc-name": "off provider chip", ".svc.on .svc-name": "on provider chip", ".history": "history line",
             ".brand .sub": "header summary", ".launch-copy span": "launch sub-line", ".action-btn.primary.tonal": "Sign in button", ".stat-card.active .stat-val": "active tile value",
             ".list-meta": "list meta"}
    for theme in ("dark", "amoled", "light"):
        pg = new_page(theme)
        check(pg.locator(".card").count() == N, "[%s] %d alias cards rendered" % (theme, N))
        check(pg.evaluate("document.body.classList.contains('light')") == (theme == "light") and pg.evaluate("document.body.classList.contains('amoled')") == (theme == "amoled"), "[%s] body theme class applied" % theme)
        check(pg.evaluate("document.querySelector('meta[name=theme-color]').content") == {"dark": "#05060b", "amoled": "#000000", "light": "#f2f5fc"}[theme], "[%s] meta theme-color matches" % theme)
        check(hscroll(pg) <= 0, "[%s] no horizontal page scroll" % theme)
        pg.click('.stat-card[data-stat="all"]')   # makes .stat-card.active exist deterministically
        shot(pg, "dashboard_%s.png" % theme)
        worst = (99, "")
        for sel, name in PAIRS.items():
            c = pg.evaluate(JS_COLORS, sel)
            if not c: check(False, "[%s] could not find %s (%s)" % (theme, name, sel)); continue
            r = ratio((c["fg"]["r"], c["fg"]["g"], c["fg"]["b"]), (c["bg"]["r"], c["bg"]["g"], c["bg"]["b"]))
            if r < worst[0]: worst = (r, name)
            check(r >= 4.5, "[%s] contrast %-20s %.2f:1" % (theme, name, r))
        g = pg.evaluate("(() => { const cs = getComputedStyle(document.querySelector('#btnAdd')); return {img: cs.backgroundImage, color: cs.color}; })()")
        import re as _re
        stops = [tuple(int(x) for x in m) for m in _re.findall(r"rgb\((\d+), (\d+), (\d+)\)", g["img"])]
        fgc = tuple(int(x) for x in _re.findall(r"\d+", g["color"])[:3])
        rr = min(ratio(fgc, s) for s in stops) if stops else 0
        check(len(stops) >= 2 and rr >= 4.5, "[%s] primary button text vs gradient stops %.2f:1 (%d stops)" % (theme, rr, len(stops)))
        pg.context.close()

    # ---- 2. dashboard content: states, badges, primary actions ----
    pg = new_page("dark")
    txt = lambda sel: pg.locator(sel).first.inner_text()
    check(txt("#subLine").startswith("%d accounts" % N), "header summary line: %s" % txt("#subLine"))
    check([pg.inner_text(i) for i in ("#sTotal", "#sCurrent", "#sReady", "#sCooldown")] == [str(N), "2", "1", "3"], "summary tiles = total %d / running 2 / ready 1 / not started 3" % N)
    check([pg.inner_text('[data-count="%s"]' % k) for k in ("all", "running", "ready", "pinned", "idle", "todo")] == [str(N), "2", "1", "1", "3", "3"], "filter chips show live counts (6/2/1/1/3/3)")
    cards = pg.locator(".card")
    first = cards.nth(0)
    check("Running" in first.locator(".badge-info").inner_text() and "left" in first.locator(".badge-info").inner_text(), "running card badge: '%s'" % first.locator(".badge-info").inner_text().replace("\n", " "))
    check(first.locator(".bar[role=progressbar]").count() == 1, "running card has an accessible progress bar")
    check(first.locator(".pin-mark").count() == 1 and first.locator('[data-action="pin"][aria-pressed="true"]').count() == 1, "pinned card shows the pin mark and aria-pressed=true")
    check(pg.locator(".badge-ok").count() == 1 and "Ready" in pg.locator(".badge-ok").inner_text(), "one Ready badge")
    check(pg.locator(".badge-warn").filter(has_text="Needs sign-in").count() == 2, "unconnected aliases show 'Needs sign-in' (2)")
    check(pg.locator(".status-row .badge").filter(has_text="Not started").count() == 1, "connected + never started shows 'Not started' (1)")
    signin = pg.locator('.card:has-text("fresh.three") .action-btn.primary')
    check(signin.get_attribute("data-action") == "svc" and signin.get_attribute("data-svc") == "claude" and "Sign in" in signin.inner_text(), "unconnected card: primary = Sign in -> existing 'svc' action for its first AI")
    openbtn = pg.locator('.card:has-text("work.one") .action-btn.primary')
    check(openbtn.get_attribute("data-action") == "orbit" and "Open" in openbtn.inner_text(), "connected card: primary = Open -> existing 'orbit' action")
    check(pg.locator('.card:has-text("work.one") .svc.on .svc-state').count() == 1 and pg.locator('.card:has-text("work.one") .svc.on').get_attribute("aria-label").startswith("Claude, connected"), "connected chip has a check icon and an aria-label with its state")
    check("not connected" in pg.locator('.card:has-text("fresh.three") .svc').first.get_attribute("aria-label"), "unconnected chip says 'not connected' to screen readers")
    lbl = pg.locator('.card:has-text("Long address")')
    check(lbl.locator(".card-title").inner_text().startswith("Long address") and lbl.locator(".email").get_attribute("title").startswith("a.very.long"), "label is the title; long email kept in the title attribute")
    check(pg.locator('.card:has-text("fresh.three") .card-title.is-email').count() == 1, "alias without a label shows its email as the title")
    ov = pg.evaluate("Array.from(document.querySelectorAll('.card')).filter(c => c.scrollWidth > c.clientWidth + 1).length")
    check(ov == 0, "no card content overflows its card (%d)" % ov)
    pg.close()

    # ---- 3. handlers: summary tiles, filters, search, sort, pin, copy, delete, bulk, add, paste, settings ----
    pg = new_page("dark")
    def n_cards(): return pg.locator(".card").count()
    pg.click('.stat-card[data-stat="ready"]')
    check(n_cards() == 1 and pg.get_attribute('.filter-btn[data-filter="ready"]', "class").find("active") != -1 and pg.get_attribute('.stat-card[data-stat="ready"]', "aria-pressed") == "true", "tap 'Ready' tile -> filters to 1 card, filter chip + tile both active")
    pg.click('.stat-card[data-stat="running"]'); check(n_cards() == 2, "tap 'Running' tile -> 2 cards")
    pg.click('.stat-card[data-stat="idle"]'); check(n_cards() == 3, "tap 'Not started' tile -> 3 cards")
    pg.click('.filter-btn[data-filter="todo"]'); check(n_cards() == 3, "filter 'Needs sign-in' -> 3 cards")
    pg.click('.filter-btn[data-filter="pinned"]'); check(n_cards() == 1, "filter Pinned -> 1 card")
    pg.click('.stat-card[data-stat="all"]'); check(n_cards() == N, "tap 'Aliases' tile -> all %d" % N)
    pg.fill("#search", "chatgpt"); check(n_cards() == 2 and not pg.locator("#btnSearchClear").is_hidden(), "search 'chatgpt' -> 2 cards, clear button appears")
    pg.click("#btnSearchClear"); check(pg.input_value("#search") == "" and n_cards() == N and pg.locator("#btnSearchClear").is_hidden(), "clear button empties the search and restores the list")
    pg.fill("#search", "zzzz"); pg.click('.filter-btn[data-filter="running"]')
    check(n_cards() == 0 and pg.is_visible("#emptyNone") and not pg.is_visible("#empty") and "zzzz" in pg.inner_text("#emptyNoneText") and "Running" in pg.inner_text("#emptyNoneText"), "no-match state names the search and the filter: '%s'" % pg.inner_text("#emptyNoneText"))
    shot(pg, "state_no_results.png", full=False)
    pg.click("#btnResetFilters"); check(n_cards() == N and pg.input_value("#search") == "" and "active" in pg.get_attribute('.filter-btn[data-filter="all"]', "class"), "'Reset search and filters' restores everything")
    pg.select_option("#sortSelect", "alpha"); check("Long address" in pg.locator(".card").first.inner_text() and pg.inner_text("#sortLabel") == "A–Z", "sort A-Z: first card is the a.very.long alias; sort label reads 'A–Z'")
    pg.select_option("#sortSelect", "recent")
    pg.locator('.card [data-action="pin"]').nth(1).click(); check(pg.locator(".card.pinned").count() == 2, "pin button pins a second card")
    check(sum(1 for a in json.loads(pg.evaluate("localStorage.getItem('alias_manager_v5')")) if a["pinned"]) == 2, "pin persisted to alias_manager_v5")
    pg.locator(".card-copy").first.click(); pg.wait_for_timeout(200); check("Copied" in pg.inner_text("#toast"), "copy button shows the 'Copied' toast")
    # delete opens the in-app confirm sheet naming the alias (no phone dialog any more)
    pg.locator('.card:has-text("idle.six") .action-btn.delete').click(); pg.wait_for_timeout(150)
    check(pg.is_visible("#confirmSheet") and "idle.six@duck.com" in pg.inner_text("#confirmBody") and n_cards() == N, "delete opens the confirm sheet naming the alias; nothing deleted yet")
    pg.click("#confirmCancel"); pg.wait_for_timeout(120); check(not pg.is_visible("#confirmSheet") and n_cards() == N, "Cancel keeps the alias")
    pg.locator('.card:has-text("idle.six") .action-btn.delete').click(); pg.wait_for_timeout(150); pg.click("#confirmOk"); pg.wait_for_timeout(200)
    check(n_cards() == N - 1, "confirming delete removes the card (%d left)" % n_cards())
    # bulk mode
    pg.click("#btnBulk"); check(pg.is_visible("#bulkBar") and pg.locator("#btnBulk svg").count() == 1 and pg.inner_text("#btnBulk") == "Done" and pg.get_attribute("#btnBulk", "aria-pressed") == "true", "bulk mode: bar visible, button keeps its icon, label 'Done', aria-pressed")
    pg.locator(".card .card-title").nth(0).click(); check("1 selected" in pg.inner_text("#bulkCount"), "tapping a card selects it ('1 selected')")
    pg.locator(".card .card-title").nth(1).click(); check("2 selected" in pg.inner_text("#bulkCount") and pg.locator(".card.selected").count() == 2, "tapping a second card selects it; both highlighted")
    pg.locator(".card .card-title").nth(1).click(); check("1 selected" in pg.inner_text("#bulkCount"), "tapping again deselects")
    pg.locator(".card-check").nth(2).check(); check("2 selected" in pg.inner_text("#bulkCount"), "the checkbox itself still works (no double toggle)")
    pg.evaluate("window.scrollTo(0, 800)"); pg.wait_for_timeout(150)
    top = pg.evaluate("document.getElementById('bulkBar').getBoundingClientRect().top")
    check(0 <= top <= 24, "bulk bar stays pinned at the top while scrolling (top=%.0f px)" % top)
    shot(pg, "state_bulk_mode.png", full=False)
    pg.evaluate("window.scrollTo(0, 0)")
    pg.click("#bulkDelete"); pg.wait_for_timeout(150); check(pg.is_visible("#confirmSheet") and "aliases?" in pg.inner_text("#confirmTitle"), "bulk delete opens the confirm sheet: '%s'" % pg.inner_text("#confirmTitle"))
    pg.click("#confirmCancel"); pg.wait_for_timeout(120); check(n_cards() == N - 1, "bulk delete: Cancel keeps all")
    pg.click("#bulkPin"); check(pg.locator(".card.pinned").count() >= 3, "bulk Pin pins the selection")
    pg.click("#bulkCancel"); check(not pg.is_visible("#bulkBar") and pg.inner_text("#btnBulk") == "Select" and pg.locator("#btnBulk svg").count() == 1, "Cancel leaves bulk mode, button back to 'Select' with its icon")
    # add / duplicate / paste many / settings / compact
    pg.click("#btnAdd"); check(pg.is_visible("#formPanel"), "Add alias opens the sheet"); shot(pg, "sheet_add_dark.png", full=False)
    pg.fill("#emailInput", "new.seven@duck.com"); pg.fill("#noteInput", "Seven"); pg.click("#btnSave")
    n_after_add = n_cards(); check(n_after_add == N and not pg.is_visible("#formPanel"), "Save adds the alias and closes the sheet (%d cards)" % n_after_add)
    pg.click("#btnAdd"); pg.fill("#emailInput", "new.seven@duck.com"); pg.click("#btnSave"); check(pg.is_visible("#formPanel") and n_cards() == n_after_add, "duplicate email is refused, sheet stays open"); pg.click("#btnCancel")
    pg.click("#btnAdd"); pg.click("#btnBulkAdd"); check(pg.is_visible("#bulkAddPanel"), "Bulk add sheet opens")
    pg.fill("#bulkText", "x1@duck.com, x2@duck.com\nbad-address"); pg.fill("#bulkPrefix", "Batch "); pg.click("#bulkAddGo"); pg.wait_for_timeout(250)
    check(n_cards() == n_after_add + 2, "bulk add adds 2 valid emails and skips the bad one (%d cards)" % n_cards())
    h_normal = pg.evaluate("document.querySelector('.card').getBoundingClientRect().height")
    pg.click("#btnSettings"); check(pg.is_visible("#settingsOverlay") and pg.is_visible("#compactDash"), "Settings opens and has the Dashboard compact mode row")
    pg.select_option("#compactDash", "1"); pg.wait_for_timeout(150)
    h_compact = pg.evaluate("document.querySelector('.card').getBoundingClientRect().height")
    check(pg.evaluate("document.body.classList.contains('compact')") and h_compact < h_normal - 8, "Compact mode applies instantly: card %.0f px -> %.0f px" % (h_normal, h_compact))
    check(json.loads(pg.evaluate("localStorage.getItem('alias_manager_settings')"))["compactDash"] == 1, "compactDash saved to alias_manager_settings")
    pg.click("#btnCloseSettings")
    pg.reload(); pg.wait_for_selector(".card"); check(pg.evaluate("document.body.classList.contains('compact')") and pg.input_value("#compactDash") == "1" if pg.click("#btnSettings") is None else False, "compact mode persists after reload")
    pg.click("#btnCloseSettings")
    # compact never shrinks touch targets below their normal size
    small = pg.evaluate("Array.from(document.querySelectorAll('.card .action-btn, .card .icon-btn, .filter-btn, .stat-card, #btnAdd, #btnOrbitBrowser')).filter(e => e.offsetParent).map(e => Math.round(e.getBoundingClientRect().height)).reduce((a, b) => Math.min(a, b), 999)")
    check(small >= 29, "compact mode keeps every control >= 29 px high (smallest %d px)" % small)
    # button size setting: Tiny is clearly thinner than Normal, applies at once and is remembered
    hn = pg.evaluate("Math.round(document.getElementById('btnOrbitBrowser').getBoundingClientRect().height)")
    pg.click("#btnSettings"); pg.select_option("#btnSize", "tiny"); pg.click("#btnCloseSettings")
    ht = pg.evaluate("Math.round(document.getElementById('btnOrbitBrowser').getBoundingClientRect().height)")
    check(33 <= hn <= 36 and 24 <= ht <= 28 and ht < hn - 5, "button size: Normal is %d px, Tiny is %d px (thinner at once)" % (hn, ht))
    pg.reload(); pg.wait_for_selector(".card")
    check(pg.evaluate("document.body.classList.contains('btn-tiny')"), "button size Tiny is remembered after reload")
    pg.click("#btnSettings"); pg.select_option("#btnSize", "normal"); pg.click("#btnCloseSettings")
    pg.select_option("#themeSelect", "light") if False else None
    pg.close()

    # ---- 3b. native bridge wiring: a mocked OrbitBrowser plugin records exactly what each card control sends ----
    c = br.new_context(viewport={"width": 390, "height": 844}, service_workers="block"); pg = c.new_page(); pg.on("pageerror", lambda e: errors.append("pageerror: %s" % e))
    pg.add_init_script("window.__calls = []; window.Capacitor = { Plugins: { OrbitBrowser: { open: async (o) => { window.__calls.push(o); return {}; } } } };"
                       "if (!localStorage.getItem('__seeded')) { localStorage.setItem('__seeded', '1'); localStorage.setItem('alias_manager_v5', %s); localStorage.setItem('alias_manager_settings', %s); }" % (json.dumps(json.dumps(ALIASES)), json.dumps(json.dumps(SETTINGS))))
    pg.goto(URL); pg.wait_for_selector(".card"); calls = lambda: pg.evaluate("window.__calls")
    pg.locator('.card:has-text("work.one") .action-btn.primary').click(); pg.wait_for_timeout(100)
    c1 = calls()[-1]; check(c1["aliasId"] == "t1" and c1["service"] == "" and c1["createIfMissing"] is False and len(c1["aliases"]) == N, "Open -> plugin.open({aliasId:'t1', service:'', createIfMissing:false}) with %d aliases" % len(c1["aliases"]))
    pg.locator('.card:has-text("fresh.three") .action-btn.primary').click(); pg.wait_for_timeout(100)
    c2 = calls()[-1]; check(c2["aliasId"] == "t3" and c2["service"] == "claude" and c2["createIfMissing"] is True, "Sign in -> plugin.open({aliasId:'t3', service:'claude', createIfMissing:true}) (creates the profile)")
    pg.locator('.card:has-text("multi.four") .svc[data-svc="chatgpt"]').click(); pg.wait_for_timeout(100)
    c3 = calls()[-1]; check(c3["aliasId"] == "t4" and c3["service"] == "chatgpt" and c3["createIfMissing"] is True, "provider chip -> plugin.open({aliasId:'t4', service:'chatgpt'})")
    pg.click("#btnOrbitBrowser"); pg.wait_for_timeout(100); c4 = calls()[-1]; check(c4["aliasId"] == "" and c4["service"] == "", "launch card Open -> plugin.open({aliasId:''})")
    n0 = len(calls()); pg.click("#btnOrbitNext"); pg.wait_for_timeout(150)
    c5 = calls()[-1] if len(calls()) > n0 else None; check(c5 is not None and c5["aliasId"] == "t4", "Next -> existing rule: a never-started connected Claude alias counts as oldest (multi.four, before the 6h-old work.two) via plugin.open")
    pg.close(); c.close()
    # Edit flow
    pg = new_page("dark"); pg.locator('.card:has-text("work.two") .action-btn[data-action="edit"]').click()
    check(pg.is_visible("#formPanel") and pg.input_value("#emailInput") == "work.two@duck.com" and pg.input_value("#noteInput") == "Claude 2", "Edit opens the sheet filled with the alias (email + label)")
    pg.fill("#noteInput", "Renamed two"); pg.click("#btnSave"); pg.wait_for_timeout(150)
    check(pg.locator(".card").filter(has_text="work.two@duck.com").locator(".card-title").inner_text().startswith("Renamed two") and json.loads(pg.evaluate("localStorage.getItem('alias_manager_v5')"))[1]["note"] == "Renamed two", "saving the edit updates the card title and storage"); pg.close()

    # ---- 3c. a clean capture of compact mode from stored settings (same seed data as the other screenshots) ----
    pg = new_page("dark", settings={"compactDash": 1}); check(pg.evaluate("document.body.classList.contains('compact')") and pg.locator(".card").count() == N, "compactDash=1 in stored settings applies on first load")
    shot(pg, "dashboard_compact_dark.png"); pg.close()

    # ---- 4. first-launch empty state ----
    pg = new_page("dark", aliases=[])
    check(pg.is_visible("#empty") and not pg.is_visible("#emptyNone") and "Add your first alias" in pg.inner_text("#empty") and pg.locator("#list .card").count() == 0, "first launch: guided empty state (not the no-results state)")
    check(not pg.is_visible("#statsBar") and not pg.is_visible(".toolbar") and not pg.is_visible(".filters") and not pg.is_visible(".sec-head"), "first launch: summary, search, filters and section header are hidden (only the guided empty state + Orbit Browser card)")
    shot(pg, "state_empty_dark.png", full=False)
    pg.click("#btnEmptyAdd"); check(pg.is_visible("#formPanel"), "empty-state 'Add alias' opens the same Add sheet"); pg.close()

    # ---- 4b. install banner (PWA install prompt) shows and can be dismissed ----
    pg = new_page("dark"); check(not pg.is_visible("#installBanner"), "install banner hidden by default")
    pg.evaluate("window.dispatchEvent(new Event('beforeinstallprompt'))"); pg.wait_for_timeout(150)
    check(pg.is_visible("#installBanner") and pg.locator("#btnDismissInstall svg").count() == 1 and pg.get_attribute("#btnDismissInstall", "aria-label") == "Dismiss install banner", "install banner appears on the install prompt; dismiss is an icon button with a name")
    bh = pg.evaluate("document.getElementById('btnDismissInstall').getBoundingClientRect().height"); check(bh >= 32, "install banner dismiss target is %d px high" % bh)
    shot(pg, "state_install_banner.png", full=False); pg.click("#btnDismissInstall"); check(not pg.is_visible("#installBanner"), "dismiss hides the install banner"); pg.close()

    # ---- 5. theme + old data compatibility ----
    pg = new_page("dark"); pg.click("#btnSettings"); pg.select_option("#themeSelect", "light"); pg.wait_for_timeout(150)
    check(pg.evaluate("document.body.classList.contains('light')") and json.loads(pg.evaluate("localStorage.getItem('alias_manager_settings')"))["theme"] == "light", "theme select -> light applied + saved")
    pg.click("#btnHours"); check(pg.is_visible("#hoursOverlay"), "Timer-hours sheet opens"); pg.click("#hoursDone"); pg.reload(); pg.wait_for_selector(".card")
    check(pg.evaluate("document.body.classList.contains('light')"), "theme persists after reload"); pg.close()
    c = br.new_context(viewport={"width": 390, "height": 844}, service_workers="block"); pg = c.new_page(); pg.on("pageerror", lambda e: errors.append("pageerror: %s" % e))
    old = [{"email": "legacy@duck.com", "note": "Legacy", "lastUsed": now - 2 * H, "pinned": False}]
    pg.add_init_script("if (!localStorage.getItem('__seeded')) { localStorage.setItem('__seeded', '1'); localStorage.setItem('alias_manager_v4', %s); localStorage.setItem('alias_manager_settings', %s); }" % (json.dumps(json.dumps(old)), json.dumps(json.dumps({"theme": "amoled"}))))
    pg.goto(URL); pg.wait_for_selector(".card")
    check(pg.locator(".card").count() == 1 and "Legacy" in pg.inner_text(".card .card-title"), "old alias_manager_v4 data still loads (no compactDash key needed)")
    check(pg.evaluate("document.body.classList.contains('amoled') && !document.body.classList.contains('compact')"), "partial old settings still load; compact defaults to off")
    c.close()
    # hostile colour value from an imported backup must not reach the style attribute
    evil = [alias(1, "evil@duck.com", "Evil", color='red;background:url(x)" onmouseover="alert(1)', manual={"claude": now})]
    pg = new_page("dark", aliases=evil)
    check(pg.locator(".card .avatar").first.get_attribute("style") is None, "an invalid alias colour is dropped instead of being written into style=")
    pg.close()

    # ---- 6. layout at other sizes: 320 px, 360 px, 412 px, tablet, 130% and 200% text ----
    for (w, h, scale, name) in [(320, 640, 1.0, "320"), (360, 740, 1.0, "360"), (412, 915, 1.0, "412"), (768, 1024, 1.0, "tablet"), (390, 844, 1.3, "text130"), (390, 844, 2.0, "text200"), (320, 640, 2.0, "320_text200")]:
        pg = new_page("dark", w=w, h=h)
        if scale != 1.0: pg.add_style_tag(content="html { font-size: %dpx !important; }" % round(16 * scale)); pg.wait_for_timeout(200)
        hs = hscroll(pg)
        cl = pg.evaluate("Array.from(document.querySelectorAll('.card, .launch, .stats-bar, .toolbar, .sec-head')).filter(e => e.scrollWidth > e.clientWidth + 1).map(e => e.className.split(' ')[0])")
        cut = pg.evaluate("""Array.from(document.querySelectorAll('.card .action-btn, .sec-actions .btn, .launch-btns .btn, .toolbar > *')).filter(e => { const r = e.getBoundingClientRect(); return r.right > window.innerWidth + 1 || r.left < -1; }).length""")
        check(hs <= 0 and not cl and cut == 0, "[%s] no horizontal scroll, no overflowing container, no control pushed off-screen (page %+d px, overflow %s, cut %d)" % (name, hs, cl, cut))
        cols = pg.evaluate("getComputedStyle(document.getElementById('list')).gridTemplateColumns.split(' ').length")
        if name == "tablet": check(cols == 2, "[tablet] cards use two columns")
        if name in ("320", "tablet", "text200", "320_text200"): shot(pg, "dashboard_%s.png" % name)
        pg.context.close()

    # ---- 7. touch targets, accessible names, keyboard focus, reduced motion ----
    pg = new_page("dark")
    sizes = pg.evaluate("""(() => { const m = {}; const add = (k, sel) => { m[k] = Array.from(document.querySelectorAll(sel)).filter(e => e.offsetParent).map(e => { const r = e.getBoundingClientRect(); return [Math.round(r.width), Math.round(r.height)]; }); };
      add('btn', '.btn:not(.btn-sm)'); add('action', '.action-btn'); add('tile', '.stat-card'); add('filter', '.filter-btn'); add('icon', '.icon-btn'); add('chip', '.svc'); add('sort', '.sort-wrap'); add('search', '#search'); return m; })()""")
    need = {"btn": 32, "action": 32, "tile": 44, "filter": 29, "icon": 32, "chip": 28, "sort": 32, "search": 32}  # Batch 7: compact controls (owner request); WCAG 2.2 AA needs 24 px
    for k, mn in need.items():
        lo = min(min(s) for s in sizes[k]) if sizes[k] else 0
        check(lo >= mn, "touch target '%s' smallest side %d px (need >= %d)" % (k, lo, mn))
    unnamed = pg.evaluate("""Array.from(document.querySelectorAll('button, select, input:not([type=file]):not([type=hidden]), textarea')).filter(e => e.offsetParent || e.closest('.sort-wrap')).filter(e => { const n = (e.getAttribute('aria-label') || e.innerText || e.getAttribute('title') || e.getAttribute('placeholder') || (e.id && document.querySelector('label[for=' + e.id + ']') ? 'x' : '') || '').trim(); return !n; }).map(e => e.id || e.className)""")
    check(not unnamed, "every visible dashboard control has an accessible name%s" % (" - MISSING: %s" % unnamed if unnamed else ""))
    ring = []
    for i in range(6):
        pg.keyboard.press("Tab"); ring.append(pg.evaluate("(() => { const e = document.activeElement; const cs = getComputedStyle(e); return [e.id || e.className.split(' ')[0] || e.tagName, cs.outlineStyle, cs.outlineWidth]; })()"))
    check(all(r[1] != "none" and r[2] != "0px" for r in ring), "keyboard focus ring visible on the first 6 tab stops: %s" % ", ".join(r[0] for r in ring))
    pg.close()
    pg = new_page("dark", reduced=True)
    d = pg.evaluate("parseFloat(getComputedStyle(document.querySelector('.btn')).transitionDuration)")
    check(d < 0.01, "prefers-reduced-motion: button transitions collapse (%.4f s)" % d); pg.close()

    # ---- 8. icon sprite gallery ----
    pg = new_page("dark"); names = pg.evaluate("Array.from(document.querySelectorAll('symbol')).map(s => s.id)")
    pg.evaluate("""(names) => { const w = document.createElement('div'); w.id = 'gal'; w.style.cssText = 'position:fixed;inset:0;z-index:999;background:#0d1220;color:#f3f5ff;display:flex;flex-wrap:wrap;gap:6px;padding:8px;align-content:flex-start;overflow:auto';
      names.forEach(n => { const d = document.createElement('div'); d.style.cssText = 'width:42px;text-align:center;font:8px sans-serif;color:#9aa8bf'; d.className = n === 'i-mark' ? '' : 'ic-duo'; d.innerHTML = '<svg style="width:30px;height:30px;display:block;margin:0 auto 2px" data-n="' + n + '"><use href="#' + n + '"/></svg>' + n.slice(2); w.appendChild(d); }); document.body.appendChild(w); }""", names)
    pg.wait_for_timeout(300); pg.screenshot(path=str(OUT / "icon_gallery.png"))
    empty = []
    for n in names:
        if n == "i-mark": continue
        box = pg.locator('svg[data-n="%s"]' % n).bounding_box()
        arr = np.array(Image.open(io.BytesIO(pg.screenshot(clip={"x": box["x"], "y": box["y"], "width": box["width"], "height": box["height"]}))).convert("RGB")).astype(int)
        if int((arr.max(axis=2) > 90).sum()) < 12: empty.append(n)
    check(not empty, "all %d sprite symbols draw visible pixels%s" % (len(names) - 1, (" - EMPTY: %s" % empty) if empty else ""))
    used = set(pg.evaluate("Array.from(document.querySelectorAll('use')).map(u => u.getAttribute('href').slice(1))")) - {"i-mark"}
    check(used <= set(names), "every icon used by the dashboard exists in the sprite")
    pg.close()
    br.close()

bad = [e for e in errors if "favicon" not in e.lower() and "manifest" not in e.lower()]
check(not bad, "no JS page errors / console errors (%d)%s" % (len(bad), (": " + " | ".join(bad[:3])) if bad else ""))
print("\n%d failure(s). Screenshots in %s" % (len(fails), OUT))
sys.exit(1 if fails else 0)
