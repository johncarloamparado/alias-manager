#!/usr/bin/env python3
"""Tests the scheduled-message page script (AUTO_JS in OrbitBrowserActivity.java) against small MOCK Claude-like pages in headless Chromium.
  python3 tools/test_autosend_js.py
It takes the script straight out of the Java source (what ships), then calls it once per poll like the app does (every ~0.8 s).
It does NOT prove the real claude.ai page behaves the same: that needs a phone (use 'Send a test now' in Orbit)."""
import json, re, sys, time
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
src = (ROOT / "native/java/OrbitBrowserActivity.java").read_text(encoding="utf-8")
m = re.search(r'AUTO_JS = ""(.*?);\n', src, re.S)
assert m, "AUTO_JS not found"
JS = "".join(json.loads(p) for p in re.findall(r'"(?:[^"\\]|\\.)*"', m.group(1)))
fails = []
def check(ok, msg):
    print(("PASS  " if ok else "FAIL  ") + msg)
    if not ok: fails.append(msg)

def call(page, text, inc=False):
    return page.evaluate("(" + JS + ")(" + json.dumps(text) + "," + ("true" if inc else "false") + ")")

def run(page, text, inc=False, max_polls=40):
    seq = []
    for _ in range(max_polls):
        r = call(page, text, inc); seq.append(r)
        if r in ("done", "limit", "login") or r.startswith("failed") or r.startswith("error"): break
        page.wait_for_timeout(120)
    return seq

EDITABLE = """<html><body><div id=msgs></div>
<div data-testid="chat-input" class="ProseMirror" contenteditable="true" style="min-height:40px;border:1px solid #888"></div>
<button id=send aria-label="Send message" disabled>send</button>
<script>
var c=document.querySelector('[data-testid=chat-input]'),b=document.getElementById('send');
c.addEventListener('input',function(){b.disabled=!c.innerText.trim();});
b.addEventListener('click',function(){var t=c.innerText.trim();if(!t)return;var d=document.createElement('div');d.textContent=t;document.getElementById('msgs').appendChild(d);c.innerHTML='';b.disabled=true;});
</script></body></html>"""
TEXTAREA_ENTER = """<html><body><div id=msgs></div><textarea id=t></textarea>
<script>var t=document.getElementById('t');t.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();var d=document.createElement('div');d.textContent=t.value;document.getElementById('msgs').appendChild(d);t.value='';}});</script></body></html>"""
GHOST = """<html><body><button aria-label="Incognito chat" id=g>ghost</button><div id=banner></div>
<div data-testid="chat-input" contenteditable="true" style="min-height:40px"></div><button aria-label="Send message" id=send>send</button><div id=msgs></div>
<script>document.getElementById('g').onclick=function(){document.getElementById('banner').textContent='You\\u2019re incognito. Incognito chats stay out of your history';};
var c=document.querySelector('[data-testid=chat-input]');document.getElementById('send').onclick=function(){var t=c.innerText.trim();if(!t)return;var d=document.createElement('div');d.textContent=t;document.getElementById('msgs').appendChild(d);c.innerHTML='';};</script></body></html>"""

CHATGPT = """<html><body><div id=msgs></div><div id="prompt-textarea" contenteditable="true" style="min-height:40px"></div>
<button data-testid="send-button" aria-label="Send prompt" id=send disabled>send</button>
<script>var c=document.getElementById('prompt-textarea'),b=document.getElementById('send');c.addEventListener('input',function(){b.disabled=!c.innerText.trim();});
b.onclick=function(){var t=c.innerText.trim();if(!t)return;var d=document.createElement('div');d.textContent=t;document.getElementById('msgs').appendChild(d);c.innerHTML='';b.disabled=true;};</script></body></html>"""
GEMINI = """<html><body><div id=msgs></div><div class="ql-editor" contenteditable="true" style="min-height:40px"></div><button aria-label="Send message" id=send>send</button>
<script>var c=document.querySelector('.ql-editor');document.getElementById('send').onclick=function(){var t=c.innerText.trim();if(!t)return;var d=document.createElement('div');d.textContent=t;document.getElementById('msgs').appendChild(d);c.innerHTML='';};</script></body></html>"""
GROK = """<html><body><div id=msgs></div><textarea id=t></textarea><button aria-label="Submit" id=send>go</button>
<script>var t=document.getElementById('t');document.getElementById('send').onclick=function(){if(!t.value.trim())return;var d=document.createElement('div');d.textContent=t.value;document.getElementById('msgs').appendChild(d);t.value='';};</script></body></html>"""
LIMIT = "<html><body><p>You've reached your usage limit. Your limit resets at 3:30 PM.</p><div data-testid='chat-input' contenteditable='true'></div></body></html>"
NOCOMP = "<html><body><p>Loading...</p></body></html>"

def load(page, html, path="/new"):
    page.route("https://claude.ai/**", lambda r: r.fulfill(status=200, content_type="text/html; charset=utf-8", body=html))
    page.goto("https://claude.ai" + path)

with sync_playwright() as pw:
    br = pw.chromium.launch()
    def fresh():
        ctx = br.new_context(); return ctx, ctx.new_page()

    ctx, page = fresh(); load(page, EDITABLE)
    seq = run(page, "Hello Claude")
    check(seq[0] == "typed" and "sent-click" in seq and seq[-1] == "done", "editor + Send button: typed, clicked, done (" + ",".join(seq) + ")")
    check(page.evaluate("document.getElementById('msgs').innerText") == "Hello Claude", "the message appears once on the page")
    ctx.close()

    ctx, page = fresh(); load(page, EDITABLE)
    tricky = 'Line one\n"quoted" and \'single\' </script> \\ backslash \u2019 \U0001F600'
    seq = run(page, tricky)
    shown = page.evaluate("document.getElementById('msgs').innerText")
    check(seq[-1] == "done" and shown.replace("\n", " ").strip().startswith("Line one"), "quotes, newline, </script>, backslash and emoji survive")
    ctx.close()

    ctx, page = fresh(); load(page, TEXTAREA_ENTER)
    seq = run(page, "Hi there")
    check("sent-enter" in seq and seq[-1] == "done", "textarea without a Send button: waits, then presses Enter (" + ",".join(seq) + ")")
    ctx.close()

    ctx, page = fresh(); load(page, GHOST)
    seq = run(page, "Private hello", inc=True)
    check(seq[0] == "ghost-click" and seq[-1] == "done", "Incognito wanted: clicks the Incognito button first, then sends (" + ",".join(seq[:4]) + "...)")
    ctx.close()

    ctx, page = fresh(); load(page, EDITABLE)
    seq = run(page, "x", inc=True, max_polls=6)
    check(seq[-1] == "wait-ghost" and "sent-click" not in seq, "Incognito wanted but no Incognito button: never sends a normal chat by mistake")
    ctx.close()

    ctx, page = fresh(); load(page, LIMIT)
    check(call(page, "hi") == "limit", "usage-limit page is reported as 'limit', nothing typed")
    check(page.evaluate("document.querySelector('[data-testid=chat-input]').innerText") == "", "composer stays empty on the limit page")
    ctx.close()

    ctx, page = fresh(); load(page, EDITABLE, path="/login")
    check(call(page, "hi") == "login", "login page is reported as 'login'")
    ctx.close()

    ctx, page = fresh(); load(page, NOCOMP)
    check(call(page, "hi") == "wait-composer", "no message box yet: waits")
    ctx.close()

    for nm, html in (("ChatGPT-like (#prompt-textarea, Send prompt)", CHATGPT), ("Gemini-like (.ql-editor, Send message)", GEMINI), ("Grok-like (textarea, Submit)", GROK)):
        ctx, page = fresh(); load(page, html, path="/")
        seq = run(page, "Hello there")
        check(seq[-1] == "done" and "sent-click" in seq, nm + ": typed, sent, done (" + ",".join(seq) + ")")
        ctx.close()

    # ---- GHOST_JS: how the app notices that an Incognito chat has started (the address stays https://claude.ai/) ----
    mg = re.search(r'GHOST_JS = (.*?);\n', src, re.S)
    GJ = "".join(json.loads(p) for p in re.findall(r'"(?:[^"\\]|\\.)*"', mg.group(1)))
    def ghost(html):
        ctx, page = fresh(); load(page, html, path="/"); v = page.evaluate(GJ); ctx.close(); return v
    check(ghost("<body><div>Incognito chat</div><h1>You\u2019re incognito</h1><p>Incognito chats stay out of your history and search.</p></body>") == 3, "GHOST_JS: empty incognito screen = 3 (curly apostrophe)")
    check(ghost("<body><div>Incognito chat</div><h1>You're incognito</h1></body>") == 3, "GHOST_JS: empty incognito screen = 3 (straight apostrophe)")
    check(ghost("<body><div>Incognito chat</div><div>hi</div><div>Hi there! How can I help you today?</div><p>Incognito chats stay out of your history, and aren't used to train Claude.</p></body>") == 1, "GHOST_JS: conversation on the incognito page = 1")
    check(ghost("<body><h1>Coffee and Claude time?</h1><div>How can I help you today?</div></body>") == 0, "GHOST_JS: a normal new chat = 0 (no false start)")
    check(ghost("<body><div>Greeting</div><div>hi</div></body>") == 0, "GHOST_JS: a normal conversation = 0")

    # ---- GHOST_JS "message just sent" bit (4) for ANY AI: Incognito/Temporary page + the box emptied + the text now on the page ----
    def gcall(page): return page.evaluate(GJ)
    def typed_and_sent(html, path, header=""):
        ctx, page = fresh(); load(page, html.replace("<body>", "<body>" + header, 1), path=path)
        out = [gcall(page)]                                   # installs the typing hook
        page.click("#prompt-textarea, .ql-editor, #t"); page.keyboard.type("hello world")
        out.append(gcall(page))                               # typed, not sent
        page.click("#send"); out.append(gcall(page))          # sent
        ctx.close(); return out
    r = typed_and_sent(CHATGPT, "/?temporary-chat=true")
    check(r == [1, 1, 5], "ChatGPT temporary chat (address has ?temporary-chat=true): typed = 1, sent = 5 (%s)" % r)
    r = typed_and_sent(CHATGPT, "/", "<div>Temporary Chat</div>")
    check(r == [1, 1, 5], "any AI whose header says Temporary Chat: sent = 5 (%s)" % r)
    r = typed_and_sent(GEMINI, "/", "<div>Incognito chat</div>")
    check(r[-1] == 5, "Gemini-like page in Incognito: sent = 5 (%s)" % r)
    r = typed_and_sent(CHATGPT, "/")
    check(r == [0, 0, 0], "the SAME page in a normal chat never counts as Incognito (%s)" % r)
    ctx, page = fresh(); load(page, CHATGPT, path="/?temporary-chat=true"); gcall(page)
    page.click("#prompt-textarea"); page.keyboard.type("oops"); gcall(page)
    for _ in range(4): page.keyboard.press("Backspace")
    check(gcall(page) == 1, "typing and then deleting the text is NOT a sent message")
    ctx.close()
    ctx, page = fresh(); load(page, CHATGPT.replace("<body>", "<body><div>Incognito chat</div>", 1), path="/"); gcall(page)
    page.click("#prompt-textarea"); page.keyboard.type("hi"); page.click("#send")
    check(gcall(page) == 5, "a very quick 'hi' + send between two checks is still caught (the typing hook sees it)")
    ctx.close()
    br.close()

print("\n%d failure(s)" % len(fails))
sys.exit(1 if fails else 0)
