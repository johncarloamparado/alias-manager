#!/usr/bin/env python3
"""Tests the scheduled-message page script (AUTO_JS in OrbitBrowserActivity.java) against small MOCK Claude-like pages in headless Chromium.
  python3 tools/test_autosend_js.py
It takes the script straight out of the Java source (what ships), then calls it once per poll like the app does (every ~0.8 s).
It does NOT prove the real claude.ai page behaves the same: that needs a phone (use 'Send a test now' in Orbit)."""
import base64, json, re, sys, time
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
src = (ROOT / "native/java/OrbitBrowserActivity.java").read_text(encoding="utf-8")
m = re.search(r'AUTO_JS = ""(.*?);\n', src, re.S)
assert m, "AUTO_JS not found"
JS = "".join(json.loads(p) for p in re.findall(r'"(?:[^"\\]|\\.)*"', m.group(1)))
fails = []
def check(ok, msg):
    print(("PASS  " if ok else "FAIL  ") + msg)
    if not ok: fails.append(msg)

def call(page, text, inc=False):
    return page.evaluate("(" + JS + ")(" + json.dumps(text) + "," + ("true" if inc else "false") + ")")

def run(page, text, inc=False, max_polls=40):
    seq = []
    for _ in range(max_polls):
        r = call(page, text, inc)
        if r != "wait-load": seq.append(r)
        if r in ("done", "limit", "login") or r.startswith("failed") or r.startswith("error"): break
        page.wait_for_timeout(120)
    return seq

EDITABLE = """<html><body><div id=msgs></div>
<div data-testid="chat-input" class="ProseMirror" contenteditable="true" style="min-height:40px;border:1px solid #888"></div>
<button id=send aria-label="Send message" disabled>send</button>
<script>
var c=document.querySelector('[data-testid=chat-input]'),b=document.getElementById('send');
c.addEventListener('input',function(){b.disabled=!c.innerText.trim();});
b.addEventListener('click',function(){var t=c.innerText.trim();if(!t)return;var d=document.createElement('div');d.textContent=t;document.getElementById('msgs').appendChild(d);c.innerHTML='';b.disabled=true;});
</script></body></html>"""
TEXTAREA_ENTER = """<html><body><div id=msgs></div><textarea id=t></textarea>
<script>var t=document.getElementById('t');t.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();var d=document.createElement('div');d.textContent=t.value;document.getElementById('msgs').appendChild(d);t.value='';}});</script></body></html>"""
GHOST = """<html><body><button aria-label="Incognito chat" id=g>ghost</button><div id=banner></div>
<div data-testid="chat-input" contenteditable="true" style="min-height:40px"></div><button aria-label="Send message" id=send>send</button><div id=msgs></div>
<script>document.getElementById('g').onclick=function(){document.getElementById('banner').textContent='You\\u2019re incognito. Incognito chats stay out of your history';};
var c=document.querySelector('[data-testid=chat-input]');document.getElementById('send').onclick=function(){var t=c.innerText.trim();if(!t)return;var d=document.createElement('div');d.textContent=t;document.getElementById('msgs').appendChild(d);c.innerHTML='';};</script></body></html>"""

CHATGPT = """<html><body><div id=msgs></div><div id="prompt-textarea" contenteditable="true" style="min-height:40px"></div>
<button data-testid="send-button" aria-label="Send prompt" id=send disabled>send</button>
<script>var c=document.getElementById('prompt-textarea'),b=document.getElementById('send');c.addEventListener('input',function(){b.disabled=!c.innerText.trim();});
b.onclick=function(){var t=c.innerText.trim();if(!t)return;var d=document.createElement('div');d.textContent=t;document.getElementById('msgs').appendChild(d);c.innerHTML='';b.disabled=true;};</script></body></html>"""
GEMINI = """<html><body><div id=msgs></div><div class="ql-editor" contenteditable="true" style="min-height:40px"></div><button aria-label="Send message" id=send>send</button>
<script>var c=document.querySelector('.ql-editor');document.getElementById('send').onclick=function(){var t=c.innerText.trim();if(!t)return;var d=document.createElement('div');d.textContent=t;document.getElementById('msgs').appendChild(d);c.innerHTML='';};</script></body></html>"""
GROK = """<html><body><div id=msgs></div><textarea id=t></textarea><button aria-label="Submit" id=send>go</button>
<script>var t=document.getElementById('t');document.getElementById('send').onclick=function(){if(!t.value.trim())return;var d=document.createElement('div');d.textContent=t.value;document.getElementById('msgs').appendChild(d);t.value='';};</script></body></html>"""

FILES_PAGE = """<html><body><form id=f><div id=chips></div><input type=file multiple data-testid="file-upload" id=in style="display:none"><div contenteditable="true" data-testid="chat-input"></div></form>
<script>var LIMIT=__LIMIT__,DROP=__DROP__;
document.getElementById('in').addEventListener('change',function(e){var fs=Array.from(e.target.files),chips=document.getElementById('chips');chips.innerHTML='';
if(fs.length>LIMIT){if(!DROP){var a=document.createElement('div');a.setAttribute('role','alert');a.textContent='You can only upload '+LIMIT+' files at once';document.body.appendChild(a);}fs=fs.slice(0,LIMIT);}
fs.forEach(function(f){if(f.type.indexOf('image/')===0){var im=document.createElement('img');im.src=URL.createObjectURL(f);chips.appendChild(im);}else{var s=document.createElement('span');s.textContent=f.name+' ';chips.appendChild(s);}});});</script></body></html>"""
LAZY_INPUT = """<html><body><form><button type=button aria-label="Attach files" id=b>+</button><div id=chips></div></form>
<script>document.getElementById('b').onclick=function(){if(document.querySelector('input[type=file]'))return;var i=document.createElement('input');i.type='file';i.multiple=true;i.style.display='none';document.querySelector('form').appendChild(i);};</script></body></html>"""
LIMIT = "<html><body><p>You've reached your usage limit. Your limit resets at 3:30 PM.</p><div data-testid='chat-input' contenteditable='true'></div></body></html>"
NOCOMP = "<html><body><p>Loading...</p></body></html>"

def load(page, html, path="/new"):
    page.route("https://claude.ai/**", lambda r: r.fulfill(status=200, content_type="text/html; charset=utf-8", body=html))
    page.goto("https://claude.ai" + path)

with sync_playwright() as pw:
    br = pw.chromium.launch()
    def fresh():
        ctx = br.new_context(); return ctx, ctx.new_page()

    ctx, page = fresh(); load(page, EDITABLE)
    seq = run(page, "Hello Claude")
    check(seq[0] == "typed" and "sent-click" in seq and seq[-1] == "done", "editor + Send button: typed, clicked, done (" + ",".join(seq) + ")")
    check(page.evaluate("document.getElementById('msgs').innerText") == "Hello Claude", "the message appears once on the page")
    ctx.close()

    ctx, page = fresh(); load(page, EDITABLE)
    tricky = 'Line one\n"quoted" and \'single\' </script> \\ backslash \u2019 \U0001F600'
    seq = run(page, tricky)
    shown = page.evaluate("document.getElementById('msgs').innerText")
    check(seq[-1] == "done" and shown.replace("\n", " ").strip().startswith("Line one"), "quotes, newline, </script>, backslash and emoji survive")
    ctx.close()

    ctx, page = fresh(); load(page, TEXTAREA_ENTER)
    seq = run(page, "Hi there")
    check("sent-enter" in seq and seq[-1] == "done", "textarea without a Send button: waits, then presses Enter (" + ",".join(seq) + ")")
    ctx.close()

    ctx, page = fresh(); load(page, GHOST)
    seq = run(page, "Private hello", inc=True)
    check(seq[0] == "ghost-click" and seq[-1] == "done", "Incognito wanted: clicks the Incognito button first, then sends (" + ",".join(seq[:4]) + "...)")
    ctx.close()

    ctx, page = fresh(); load(page, EDITABLE)
    seq = run(page, "x", inc=True, max_polls=6)
    check(seq[-1] == "wait-ghost" and "sent-click" not in seq, "Incognito wanted but no Incognito button: never sends a normal chat by mistake")
    ctx.close()

    ctx, page = fresh(); load(page, LIMIT)
    check(call(page, "hi") == "limit", "usage-limit page is reported as 'limit', nothing typed")
    check(page.evaluate("document.querySelector('[data-testid=chat-input]').innerText") == "", "composer stays empty on the limit page")
    ctx.close()

    ctx, page = fresh(); load(page, EDITABLE, path="/login")
    check(call(page, "hi") == "login", "login page is reported as 'login'")
    ctx.close()

    ctx, page = fresh(); load(page, NOCOMP)
    rv = call(page, "hi"); check(rv.startswith("wait-composer|") and "ed=0" in rv and "ta=0" in rv, "no message box yet: waits and says what the page has (%s)" % rv)
    ctx.close()

    for nm, html in (("ChatGPT-like (#prompt-textarea, Send prompt)", CHATGPT), ("Gemini-like (.ql-editor, Send message)", GEMINI), ("Grok-like (textarea, Submit)", GROK)):
        ctx, page = fresh(); load(page, html, path="/")
        seq = run(page, "Hello there")
        check(seq[-1] == "done" and "sent-click" in seq, nm + ": typed, sent, done (" + ",".join(seq) + ")")
        ctx.close()

    # ---- GHOST_JS: how the app notices that an Incognito chat has started (the address stays https://claude.ai/) ----
    mg = re.search(r'GHOST_JS = (.*?);\n', src, re.S)
    GJ = "".join(json.loads(p) for p in re.findall(r'"(?:[^"\\]|\\.)*"', mg.group(1)))
    def ghost(html):
        ctx, page = fresh(); load(page, html, path="/"); v = page.evaluate(GJ); ctx.close(); return v
    check(ghost("<body><div>Incognito chat</div><h1>You\u2019re incognito</h1><p>Incognito chats stay out of your history and search.</p></body>") == 3, "GHOST_JS: empty incognito screen = 3 (curly apostrophe)")
    check(ghost("<body><div>Incognito chat</div><h1>You're incognito</h1></body>") == 3, "GHOST_JS: empty incognito screen = 3 (straight apostrophe)")
    check(ghost("<body><div>Incognito chat</div><div>hi</div><div>Hi there! How can I help you today?</div><p>Incognito chats stay out of your history, and aren't used to train Claude.</p></body>") == 1, "GHOST_JS: conversation on the incognito page = 1")
    check(ghost("<body><h1>Coffee and Claude time?</h1><div>How can I help you today?</div></body>") == 0, "GHOST_JS: a normal new chat = 0 (no false start)")
    check(ghost("<body><div>Greeting</div><div>hi</div></body>") == 0, "GHOST_JS: a normal conversation = 0")

    # ---- GHOST_JS "message just sent" bit (4) for ANY AI: Incognito/Temporary page + the box emptied + the text now on the page ----
    def gcall(page): return page.evaluate(GJ)
    def typed_and_sent(html, path, header=""):
        ctx, page = fresh(); load(page, html.replace("<body>", "<body>" + header, 1), path=path)
        out = [gcall(page)]                                   # installs the typing hook
        page.click("#prompt-textarea, .ql-editor, #t"); page.keyboard.type("hello world")
        out.append(gcall(page))                               # typed, not sent
        page.click("#send"); out.append(gcall(page))          # sent
        ctx.close(); return out
    r = typed_and_sent(CHATGPT, "/?temporary-chat=true")
    check(r == [1, 1, 13], "ChatGPT temporary chat (address has ?temporary-chat=true): typed = 1, sent = 13 (incognito + sent in incognito + sent) (%s)" % r)
    r = typed_and_sent(CHATGPT, "/", "<div>Temporary Chat</div>")
    check(r == [1, 1, 13], "any AI whose header says Temporary Chat: sent = 13 (%s)" % r)
    r = typed_and_sent(GEMINI, "/", "<div>Incognito chat</div>")
    check(r[-1] == 13, "Gemini-like page in Incognito: sent = 13 (%s)" % r)
    r = typed_and_sent(CHATGPT, "/")
    check(r == [0, 0, 8], "the SAME page in a normal chat is never Incognito (no bit 1/4), but a sent message is still seen (bit 8) so a message in an OLD chat starts the timer (%s)" % r)
    ctx, page = fresh(); load(page, CHATGPT, path="/?temporary-chat=true"); gcall(page)
    page.click("#prompt-textarea"); page.keyboard.type("oops"); gcall(page)
    for _ in range(4): page.keyboard.press("Backspace")
    check(gcall(page) == 1, "typing and then deleting the text is NOT a sent message")
    ctx.close()
    ctx, page = fresh(); load(page, CHATGPT.replace("<body>", "<body><div>Incognito chat</div>", 1), path="/"); gcall(page)
    page.click("#prompt-textarea"); page.keyboard.type("hi"); page.click("#send")
    check(gcall(page) == 13, "a very quick 'hi' + send between two checks is still caught (the typing hook sees it)")
    ctx.close()

    # ---- LIMIT_JS: does Orbit recognise the AI's "limit reached" message (new free-plan wording included)? ----
    ml = re.search(r'LIMIT_JS = (.*?);\n', src, re.S)
    LJ = "".join(json.loads(p) for p in re.findall(r'"(?:[^"\\]|\\.)*"', ml.group(1)))
    def limit(text):
        ctx, page = fresh(); load(page, "<html><body>" + text + "</body></html>", path="/"); v = page.evaluate(LJ); ctx.close(); return v
    check("6:00 PM" in limit("<p>Paused: Your free usage returns at 6:00 PM. Continue then.</p>"), "LIMIT_JS: \"Your free usage returns at 6:00 PM\" is recognised")
    check("6:00 PM" in limit("<div>Write a message</div><div>You are out of free messages until 6:00 PM</div><button>Upgrade</button>"), "LIMIT_JS: \"You are out of free messages until 6:00 PM\" is recognised")
    check("2 hours" in limit("<p>You've reached your usage limit. Your limit resets in 2 hours 10 minutes.</p>"), "LIMIT_JS: the older wording is still recognised")
    check("out of" in limit("<p>You're out of messages. Try again later.</p>"), "LIMIT_JS: \"You're out of messages\" is recognised")
    check(limit("<p>Hi! How can I help you today?</p><p>I want to track my usage on this project.</p>") == "", "LIMIT_JS: a normal chat that only mentions 'usage' is NOT a limit")
    check(limit("<p>The meeting resets at 3 PM and the sprint limit is 5 items.</p>") == "", "LIMIT_JS: other 'resets at' / 'limit' sentences are NOT a limit")

    # ---- HIDDEN_POLY: a page that is not on screen (hidden, no animation frames) is made to behave like a visible one ----
    mh = re.search(r'HIDDEN_POLY = ""(.*?);\n', src, re.S)
    HP = "".join(json.loads(p) for p in re.findall(r'"(?:[^"\\]|\\.)*"', mh.group(1)))
    ctx, page = fresh(); load(page, "<html><body>x</body></html>", path="/")
    page.evaluate("() => { Object.defineProperty(document, 'visibilityState', {get: () => 'hidden', configurable: true}); Object.defineProperty(document, 'hidden', {get: () => true, configurable: true}); window.requestAnimationFrame = () => 0; }")
    page.evaluate(HP)
    fired = page.evaluate("new Promise(res => { let ok = false; window.requestAnimationFrame(() => { ok = true; }); setTimeout(() => res(ok), 120); })")
    check(page.evaluate("document.hidden === false && document.visibilityState === 'visible' && window.__orbitRealVis === 'hidden'") and fired, "HIDDEN_POLY: a hidden page without animation frames now reports visible and gets frames (real state kept: hidden)")
    ctx.close()

    # ---- ATT_JS: photos / files handed to the page's own file box, then verified ----
    ma = re.search(r'ATT_JS = ""(.*?);\n', src, re.S)
    AJ = "".join(json.loads(p) for p in re.findall(r'"(?:[^"\\]|\\.)*"', ma.group(1)))
    def push(page, files):
        page.evaluate(AJ)
        for name, typ, data in files:
            page.evaluate("__orbitAtt.begin(%s,%s)" % (json.dumps(name), json.dumps(typ)))
            for i in range(0, len(data), 7):                        # tiny pieces on purpose: the real app sends big ones
                page.evaluate("__orbitAtt.chunk('%s')" % base64.b64encode(data[i:i + 7]).decode())
            page.evaluate("__orbitAtt.end()")
        return page.evaluate("__orbitAtt.commit()")
    def filepage(limit=20, drop=False):
        ctx, page = fresh(); load(page, FILES_PAGE.replace("__LIMIT__", str(limit)).replace("__DROP__", "true" if drop else "false"), path="/")
        page.evaluate(AJ); return ctx, page
    PNG = b"\x89PNG\r\n\x1a\n" + bytes(range(40))
    f3 = [("notes.txt", "text/plain", "héllo wörld 123".encode()), ("long_report_name_2026.pdf", "application/pdf", b"%PDF-1.4 " + bytes(range(60))), ("photo.png", "image/png", PNG)]
    ctx, page = filepage()
    check(page.evaluate("__orbitAtt.prep()") == "input", "attach: finds the page's file box")
    r = push(page, f3)
    ok1 = r == "committed:3"
    got = page.evaluate("Promise.all(Array.from(document.getElementById('in').files).map(async f => [f.name, f.type, f.size, Array.from(new Uint8Array(await f.arrayBuffer()))]))")
    same = [(g[0], g[1], bytes(g[3])) for g in got] == f3
    check(ok1 and same, "attach: 3 files (text with accents, pdf, png) reach the page's file box byte-for-byte, in order (%s)" % r)
    page.wait_for_timeout(100)
    check(page.evaluate("__orbitAtt.check(2,1)") == "ok", "attach: the page shows 2 named files + 1 picture, check = ok")
    ctx.close()
    ctx, page = filepage(limit=2); page.evaluate("__orbitAtt.prep()"); push(page, f3); page.wait_for_timeout(100)
    rr = page.evaluate("__orbitAtt.check(2,1)")
    check(rr.startswith("error:") and "only upload 2" in rr, "attach: the AI says 'only 2 files' -> check reports the error, nothing would be sent (%s)" % rr)
    ctx.close()
    ctx, page = filepage(limit=2, drop=True); page.evaluate("__orbitAtt.prep()"); push(page, f3); page.wait_for_timeout(100)
    rr = page.evaluate("__orbitAtt.check(2,1)")
    check(rr.startswith("wait:"), "attach: the AI silently keeps only 2 -> check never says ok (%s)" % rr)
    ctx.close()
    ctx, page = fresh(); load(page, LAZY_INPUT, path="/"); page.evaluate(AJ)
    a1 = page.evaluate("__orbitAtt.prep()"); page.wait_for_timeout(50); a2 = page.evaluate("__orbitAtt.prep()")
    check(a1 == "wait-attach" and a2 == "input", "attach: no file box yet -> taps 'Attach files', then finds the box it created (%s, %s)" % (a1, a2))
    ctx.close()
    ctx, page = fresh(); load(page, "<html><body><p>nothing here</p></body></html>", path="/"); page.evaluate(AJ)
    check(page.evaluate("__orbitAtt.prep()") == "no-input", "attach: no file box and no attach button -> 'no-input'")
    ctx.close()
    ctx, page = filepage(); page.evaluate("__orbitAtt.prep()"); push(page, f3[:1]); page.evaluate("var p=document.createElement('div');p.setAttribute('role','progressbar');document.getElementById('f').appendChild(p);")
    check(page.evaluate("__orbitAtt.check(1,0)") == "wait:busy", "attach: an upload still in progress is 'busy', not ok")
    ctx.close()

    # ---- files only (no text): never presses Enter, waits for the Send button, only then sends ----
    FILESONLY = """<html><body><div id=msgs></div><div contenteditable="true" data-testid="chat-input" style="min-height:30px"></div><button aria-label="Send message" id=send disabled>send</button>
<script>document.getElementById('send').onclick=function(){var d=document.createElement('div');d.textContent='[files sent]';document.getElementById('msgs').appendChild(d);};</script></body></html>"""
    ctx, page = fresh(); load(page, FILESONLY, path="/")
    for _ in range(3): call(page, "")   # the page must first settle (3 quiet checks)
    seq = [call(page, "") for _ in range(6)]
    check(set(seq) == {"wait-send"} and page.evaluate("document.getElementById('msgs').innerText") == "", "files only: Send button still disabled (upload not finished) -> waits, never presses Enter (%s)" % ",".join(seq[:3]))
    page.evaluate("document.getElementById('send').disabled = false")
    r1 = call(page, ""); page.evaluate("window.__orbitAuto.sentAt -= 4000"); r2 = call(page, "")
    check(r1 == "sent-click" and r2 == "done" and "[files sent]" in page.evaluate("document.getElementById('msgs').innerText"), "files only: once Send is enabled it clicks it and finishes (%s, %s)" % (r1, r2))
    ctx.close()

    # ---- an old chat opened from the list: the address bar never changes, but the message sent is seen (bit 8) ----
    ctx, page = fresh(); load(page, CHATGPT, path="/chat/5fb6c7f4-0000-4000-8000-c742030e11aa"); gcall(page)
    page.click("#prompt-textarea"); page.keyboard.type("continue"); page.click("#send")
    check(gcall(page) == 8, "an existing (old) chat in normal mode: message sent = 8, not Incognito")
    check(gcall(page) == 0, "...and the same send is not reported twice")
    ctx.close()

    # ---- DL_NAMES_JS: the file name the page gives a download is remembered (a blob: address is only a random id) ----
    md = re.search(r'DL_NAMES_JS = ""(.*?);\n', src, re.S)
    DJ = "".join(json.loads(p) for p in re.findall(r'"(?:[^"\\]|\\.)*"', md.group(1)))
    ctx, page = fresh(); load(page, "<html><body><div id=h></div></body></html>", path="/"); page.evaluate(DJ)
    res = page.evaluate("""() => {
      const mk = (name, data) => { const u = URL.createObjectURL(new Blob([data])); return [u, name]; };
      const [u1, n1] = mk('build.yml', 'a: 1');                      // detached anchor, .click()
      let a = document.createElement('a'); a.href = u1; a.download = n1; a.click();
      const [u2, n2] = mk('codmtex.zip', 'zip');                     // FileSaver style: dispatchEvent
      a = document.createElement('a'); a.href = u2; a.download = n2; a.dispatchEvent(new MouseEvent('click'));
      const [u3, n3] = mk('real click.txt', 'x');                    // an anchor in the page, clicked
      a = document.createElement('a'); a.href = u3; a.download = n3; a.id = 'real'; document.body.appendChild(a); a.addEventListener('click', e => e.preventDefault()); a.click();
      const u4 = URL.createObjectURL(new Blob(['y']));               // no download attribute
      a = document.createElement('a'); a.href = u4; a.click();
      const M = window.__orbitDlNames;
      return [M[u1], M[u2], M[u3], M[u4] === undefined];
    }""")
    check(res == ["build.yml", "codmtex.zip", "real click.txt", True], "DL_NAMES_JS: build.yml / codmtex.zip / a name with a space are remembered; an anchor without a download name is not (%s)" % res)
    ctx.close()

    # ---- "done" needs a NEW copy of the message on the page (slow loading / a page that resets its box must not look like a send) ----
    HIST = """<html><body><div id=msgs><div>continue</div><div>Sure, I will continue now.</div></div><div contenteditable="true" data-testid="chat-input" style="min-height:30px"></div><button aria-label="Send message" id=send>send</button>
<script>var c=document.querySelector('[data-testid=chat-input]');window.REAL=false;
document.getElementById('send').onclick=function(){var t=c.innerText.trim();c.innerHTML='';if(window.REAL){var d=document.createElement('div');d.textContent=t;document.getElementById('msgs').appendChild(d);}};</script></body></html>"""
    ctx, page = fresh(); load(page, HIST, path="/chat/aaaa")
    seq = run(page, "continue", max_polls=12)
    check("sent-click" in seq and "done" not in seq, "an old identical message in the chat + a page that cleared the box WITHOUT sending: never reported as done (%s)" % ",".join(seq))
    page.evaluate("var d=document.createElement('div');d.textContent='continue';document.getElementById('msgs').appendChild(d);")
    check(call(page, "continue") == "done", "...and once the message really appears as a new one, it is done")
    ctx.close()
    ctx, page = fresh(); load(page, HIST, path="/chat/aaaa"); page.evaluate("window.REAL=true")
    seq = run(page, "continue")
    check(seq[-1] == "done" and page.evaluate("document.querySelectorAll('#msgs div').length") == 3, "same page, message really sent: done, exactly one new message (%s)" % ",".join(seq))
    ctx.close()
    # ---- the page must settle before anything is typed ----
    ctx, page = fresh(); load(page, EDITABLE, path="/")
    r1 = call(page, "hi"); page.evaluate("var x=document.createElement('p');x.textContent='more content arrives';document.body.appendChild(x);")
    r2 = call(page, "hi"); r3 = call(page, "hi"); r4 = call(page, "hi"); r5 = call(page, "hi")
    check([r1, r2, r3, r4] == ["wait-load"] * 4 and r5 == "typed", "slow page: nothing is typed while the page is still changing; it types after 2 quiet checks (%s)" % [r1, r2, r3, r4, r5])
    ctx.close()
    # ---- browser side: deleting your own text, or an old identical message, is not a send ----
    ctx, page = fresh(); load(page, HIST.replace("<body>", "<body><div>Incognito chat</div>", 1).replace('contenteditable="true"', 'contenteditable="true" id="prompt-textarea"'), path="/"); gcall(page)
    page.click("#prompt-textarea"); page.keyboard.type("continue")
    for _ in range(8): page.keyboard.press("Backspace")
    check(gcall(page) & 8 == 0, "typing 'continue' (also in the history) and deleting it is NOT a send")
    page.keyboard.type("continue"); page.evaluate("window.REAL=true"); page.click("#send")
    check(gcall(page) & 8 == 8, "typing it again and really sending it IS a send")
    ctx.close()
    br.close()

print("\n%d failure(s)" % len(fails))
sys.exit(1 if fails else 0)
