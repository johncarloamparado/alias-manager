import javax.tools.*;
import com.sun.source.util.JavacTask;
import java.util.*;
import java.io.*;
import java.net.URI;
public class ParseJava {
    public static void main(String[] a) throws Exception {
        JavaCompiler c = ToolProvider.getSystemJavaCompiler();
        if (c == null) { System.out.println("NO COMPILER"); return; }
        int bad = 0;
        for (String f : a) {
            String src = new String(java.nio.file.Files.readAllBytes(java.nio.file.Paths.get(f)), "UTF-8").replace("__PACKAGE__", "com.aliasmanager.app");
            JavaFileObject fo = new SimpleJavaFileObject(URI.create("string:///" + new File(f).getName()), JavaFileObject.Kind.SOURCE) { public CharSequence getCharContent(boolean b) { return src; } };
            DiagnosticCollector<JavaFileObject> d = new DiagnosticCollector<>();
            JavacTask t = (JavacTask) c.getTask(null, null, d, Arrays.asList("-proc:none"), null, Arrays.asList(fo));
            t.parse();
            for (Diagnostic<? extends JavaFileObject> x : d.getDiagnostics()) if (x.getKind() == Diagnostic.Kind.ERROR) { bad++; System.out.println(f + ":" + x.getLineNumber() + ": " + x.getMessage(null)); }
        }
        System.out.println(bad == 0 ? "PARSE OK (syntax only)" : bad + " syntax errors");
    }
}
