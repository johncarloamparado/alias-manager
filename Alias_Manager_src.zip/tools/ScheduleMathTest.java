// Tests the pure rules of the scheduled message (native/java/OrbitScheduleMath.java) on a computer.
//   java tools/ScheduleMathTest.java
// It compiles the shipped file (package line removed) in a temp folder and calls it by reflection.
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.*;
import java.util.*;
import javax.tools.*;

public class ScheduleMathTest {
    static int fails = 0;
    static void check(boolean ok, String msg) { System.out.println((ok ? "PASS  " : "FAIL  ") + msg); if (!ok) fails++; }
    public static void main(String[] a) throws Exception {
        Path src = Paths.get("native/java/OrbitScheduleMath.java");
        Path dir = Files.createTempDirectory("sm");
        Files.writeString(dir.resolve("OrbitScheduleMath.java"), Files.readString(src).replace("package __PACKAGE__;", ""));
        JavaCompiler jc = ToolProvider.getSystemJavaCompiler();
        int rc = jc.run(null, null, null, "-d", dir.toString(), dir.resolve("OrbitScheduleMath.java").toString());
        if (rc != 0) { System.out.println("FAIL  OrbitScheduleMath.java does not compile"); System.exit(1); }
        Class<?> c = new URLClassLoader(new URL[]{dir.toUri().toURL()}).loadClass("OrbitScheduleMath");
        Method next = c.getDeclaredMethod("nextTimeOfDay", int.class, int.class, long.class); next.setAccessible(true);
        Method should = c.getDeclaredMethod("shouldRun", boolean.class, long.class, long.class, long.class); should.setAccessible(true);
        Method dayOff = c.getDeclaredMethod("dayOffset", long.class, long.class); dayOff.setAccessible(true);
        Method ram = c.getDeclaredMethod("ramOk", long.class, boolean.class); ram.setAccessible(true);
        Method retry = c.getDeclaredMethod("canRetry", int.class); retry.setAccessible(true);

        Calendar cal = Calendar.getInstance(); cal.set(2026, Calendar.NOVEMBER, 10, 22, 3, 0); cal.set(Calendar.MILLISECOND, 0);
        long now = cal.getTimeInMillis();                                    // Nov 10, 10:03 PM
        long t = (Long) next.invoke(null, 21, 59, now);                      // 9:59 PM already passed today
        Calendar r = Calendar.getInstance(); r.setTimeInMillis(t);
        check(r.get(Calendar.DAY_OF_MONTH) == 11 && r.get(Calendar.HOUR_OF_DAY) == 21 && r.get(Calendar.MINUTE) == 59, "9:59 PM asked at 10:03 PM means TOMORROW 9:59 PM");
        check((Integer) dayOff.invoke(null, t, now) == 1, "that time is reported as 'tomorrow'");
        long t2 = (Long) next.invoke(null, 22, 30, now); r.setTimeInMillis(t2);
        check(r.get(Calendar.DAY_OF_MONTH) == 10 && r.get(Calendar.MINUTE) == 30, "10:30 PM asked at 10:03 PM means today");
        check((Integer) dayOff.invoke(null, t2, now) == 0, "that time is reported as 'today'");
        long t3 = (Long) next.invoke(null, 22, 3, now + 30000L);
        r.setTimeInMillis(t3);
        check(r.get(Calendar.DAY_OF_MONTH) == 11, "the minute that is already running (plus 30 s) rolls to tomorrow, never 'right now'");

        long at = t;
        check((Boolean) should.invoke(null, true, at, at, at), "alarm for the scheduled time, schedule on: runs");
        check(!(Boolean) should.invoke(null, false, at, at, at), "schedule OFF: never runs");
        check(!(Boolean) should.invoke(null, true, at - 86400000L, at, at), "stale alarm (set for yesterday's time): ignored");
        check(!(Boolean) should.invoke(null, true, at, at, at - 60000L), "alarm one minute early: ignored");
        check((Boolean) should.invoke(null, true, at, at, at + 20 * 60000L), "alarm 20 minutes late (Doze): still runs");
        check(!(Boolean) should.invoke(null, true, at, at, at + 7 * 3600000L), "alarm 7 hours late: ignored");
        check((Boolean) should.invoke(null, true, 0L, at, at + 1000L), "alarm from an older version (no time carried): runs when the time matches");
        check(!(Boolean) should.invoke(null, true, 0L, 0L, at), "no scheduled time at all: never runs");
        check((Boolean) ram.invoke(null, 800L * 1024 * 1024, false) && !(Boolean) ram.invoke(null, 200L * 1024 * 1024, false) && !(Boolean) ram.invoke(null, 800L * 1024 * 1024, true), "RAM check: 800 MB free ok; 200 MB free not; 'low memory' flag not");
        check((Boolean) retry.invoke(null, 0) && (Boolean) retry.invoke(null, 9) && !(Boolean) retry.invoke(null, 10) && !(Boolean) retry.invoke(null, -1), "low-memory retries: 10 checks (0..9) are allowed, the 11th is not");
        System.out.println("\n" + fails + " failure(s)");
        System.exit(fails == 0 ? 0 : 1);
    }
}
