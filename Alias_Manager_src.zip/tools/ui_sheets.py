#!/usr/bin/env python3
"""Real-browser tests for the Batch 3 sheets, forms, Settings, confirmations, toasts and the lock screen (Chromium via Playwright).

  python3 tools/ui_sheets.py [screenshot_dir]        exit code 1 on any FAIL

Companion of tools/ui_smoke.py (dashboard). Native Capacitor paths are NOT covered: where the app asks the OrbitBrowser plugin
(app lock) a small MOCK plugin is injected, and that is said in the test name.
"""
import json, sys, threading, time, http.server, socketserver, functools, tempfile, os
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("/tmp/orbit_shots")
OUT.mkdir(parents=True, exist_ok=True)
fails = []
def check(ok, msg):
    print(("PASS  " if ok else "FAIL  ") + msg)
    if not ok: fails.append(msg)

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
socketserver.ThreadingTCPServer.allow_reuse_address = True
socketserver.ThreadingTCPServer.daemon_threads = True
srv = socketserver.ThreadingTCPServer(("127.0.0.1", 0), functools.partial(Quiet, directory=str(ROOT / "www")))
URL = "http://127.0.0.1:%d/" % srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

H = 3600 * 1000
now = int(time.time() * 1000)
def alias(i, email, note, **kw):
    a = dict(id="t%d" % i, email=email, note=note, tags=[], color="", services=["claude"], manual={}, auto={}, timers={},
             pinned=False, isCurrent=False, created=now - i * 86400000, lastUsed=None, history=[])
    a.update(kw); return a
ALIASES = [
    alias(1, "work.one@duck.com", "Claude 1", lastUsed=now - 1 * H, manual={"claude": now}, pinned=True, tags=["work"], color="#7c9cff", history=[now - 1 * H]),
    alias(2, "work.two@duck.com", "Claude 2", lastUsed=now - 6 * H, manual={"claude": now}, tags=["work", "test"]),
    alias(3, "fresh.three@duck.com", "", services=["claude", "chatgpt"]),
    alias(4, "multi.four@duck.com", "Multi", services=["claude", "chatgpt", "gemini", "grok"], manual={"claude": now, "chatgpt": now}, timers={"chatgpt": now - 2 * H}, color="#4ade80"),
    alias(5, "legacy-address", "Legacy odd email", services=["perplexity"]),   # an old record that is not a valid email: must stay editable
]
N = len(ALIASES)
SETTINGS = dict(autoRefresh=0, theme="dark", readyAlert=0, orbitAutoStart=1, orbitKeep=2, lastBackup=0, alertedReady={}, hours={}, appLock=0, compactDash=0)

def lum(c):
    f = lambda v: (v / 255.0 / 12.92) if v / 255.0 <= 0.03928 else (((v / 255.0) + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2])
def ratio(a, b):
    la, lb = lum(a), lum(b)
    if la < lb: la, lb = lb, la
    return (la + 0.05) / (lb + 0.05)
JS_COLORS = """(sel) => {
  const el = document.querySelector(sel); if (!el) return null;
  const parse = s => { const m = s.match(/rgba?\\(([^)]+)\\)/); if (!m) return null; const p = m[1].split(',').map(x => parseFloat(x)); return {r:p[0], g:p[1], b:p[2], a: p.length > 3 ? p[3] : 1}; };
  const layers = []; let n = el; while (n) { const c = parse(getComputedStyle(n).backgroundColor); if (c && c.a > 0) layers.push(c); n = n.parentElement; }
  layers.reverse(); let base = {r: 0, g: 0, b: 0};
  layers.forEach(c => { base = {r: c.r * c.a + base.r * (1 - c.a), g: c.g * c.a + base.g * (1 - c.a), b: c.b * c.a + base.b * (1 - c.a)}; });
  let fg = parse(getComputedStyle(el).color); if (fg.a < 1) fg = {r: fg.r * fg.a + base.r * (1 - fg.a), g: fg.g * fg.a + base.g * (1 - fg.a), b: fg.b * fg.a + base.b * (1 - fg.a), a: 1};
  return {fg, bg: base};
}"""

errors = []
with sync_playwright() as p:
    br = p.chromium.launch()
    def new_page(theme="dark", aliases=ALIASES, settings=None, w=390, h=844, reduced=False, init_js="", scale=1.0):
        c = br.new_context(viewport={"width": w, "height": h}, device_scale_factor=2, is_mobile=w < 700, has_touch=True, service_workers="block",
                           reduced_motion="reduce" if reduced else "no-preference")
        pg = c.new_page()
        pg.on("pageerror", lambda e: errors.append("pageerror: %s" % e))
        pg.on("console", lambda m: errors.append("console.error: %s" % m.text) if m.type == "error" else None)
        s = dict(SETTINGS); s["theme"] = theme
        if settings: s.update(settings)
        pg.add_init_script(init_js + "if (!localStorage.getItem('__seeded')) { localStorage.setItem('__seeded', '1'); localStorage.setItem('alias_manager_v5', %s); localStorage.setItem('alias_manager_settings', %s); }" % (json.dumps(json.dumps(aliases)), json.dumps(json.dumps(s))))
        pg.goto(URL); pg.wait_for_selector(".card, #empty", state="attached"); pg.wait_for_timeout(250)
        if scale != 1.0: pg.add_style_tag(content="html { font-size: %dpx !important; }" % round(16 * scale)); pg.wait_for_timeout(150)
        return pg
    W = lambda pg, ms=200: pg.wait_for_timeout(ms)
    def shot(pg, name): pg.wait_for_timeout(450); pg.screenshot(path=str(OUT / name))
    vis = lambda pg, sel: pg.is_visible(sel)
    hstate = lambda pg: pg.evaluate("history.state && history.state.orbitSheet ? 1 : 0")
    active = lambda pg: pg.evaluate("document.activeElement ? (document.activeElement.id || document.activeElement.className || document.activeElement.tagName) : ''")
    cards = lambda pg: pg.locator(".card").count()
    saved = lambda pg: json.loads(pg.evaluate("localStorage.getItem('alias_manager_v5')"))
    stored_settings = lambda pg: json.loads(pg.evaluate("localStorage.getItem('alias_manager_settings')"))

    # ============ 1. sheet shell: focus, Escape, X, backdrop, Back button, stack, inert ============
    pg = new_page()
    check(hstate(pg) == 0, "no history entry before any sheet is opened")
    pg.click("#btnAdd"); W(pg)
    check(pg.get_attribute("#formSheet", "role") == "dialog" and pg.get_attribute("#formSheet", "aria-modal") == "true" and pg.get_attribute("#formSheet", "aria-labelledby") == "formTitle", "Add sheet is a labelled modal dialog")
    check(active(pg) == "emailInput", "focus moves into the email field when adding (active: %s)" % active(pg))
    check(pg.evaluate("document.querySelector('.app').inert") is True and hstate(pg) == 1, "dashboard behind the sheet is inert; exactly one history entry is added")
    inside = []
    for i in range(45): pg.keyboard.press("Tab"); inside.append(pg.evaluate("!!document.activeElement.closest('#formPanel')"))
    check(all(inside), "Tab wraps inside the open sheet (45 presses, more than it has controls)")
    pg.keyboard.press("Shift+Tab"); pg.keyboard.press("Shift+Tab"); check(pg.evaluate("!!document.activeElement.closest('#formPanel')"), "Shift+Tab also stays inside")
    pg.keyboard.press("Escape"); W(pg)
    check(not vis(pg, "#formPanel") and active(pg) == "btnAdd" and hstate(pg) == 0 and pg.evaluate("!document.querySelector('.app').inert"), "Escape closes it, focus returns to 'Add alias', history entry removed, dashboard live again")
    pg.click("#btnAdd"); W(pg); pg.click("#formClose"); W(pg); check(not vis(pg, "#formPanel") and active(pg) == "btnAdd", "the X button closes it and returns focus to the opener")
    pg.click("#btnAdd"); W(pg); pg.mouse.click(8, 8); W(pg); check(not vis(pg, "#formPanel"), "tapping the dimmed backdrop closes it")
    pg.click("#btnAdd"); W(pg); pg.go_back(); W(pg, 300)
    check(not vis(pg, "#formPanel") and hstate(pg) == 0 and pg.url == URL, "the phone's Back button closes the sheet and stays in the app (%s)" % ("same page" if pg.url == URL else pg.url))
    pg.click("#btnAdd"); W(pg); check(vis(pg, "#formPanel") and hstate(pg) == 1, "the sheet can be opened again after a Back-button close")
    pg.keyboard.press("Escape"); W(pg)
    # stack: Settings -> Timer hours
    pg.click("#btnSettings"); W(pg); check(vis(pg, "#settingsOverlay") and hstate(pg) == 1, "Settings opens (one history entry)")
    pg.click("#btnHours"); W(pg); check(vis(pg, "#hoursOverlay") and not vis(pg, "#settingsOverlay") and hstate(pg) == 1, "Timer hours replaces Settings without a second history entry")
    pg.keyboard.press("Escape"); W(pg); check(vis(pg, "#settingsOverlay") and not vis(pg, "#hoursOverlay") and active(pg) == "btnHours", "Escape on Timer hours returns to Settings with focus on the 'Edit' button")
    pg.click("#btnHours"); W(pg); pg.go_back(); W(pg, 300); check(vis(pg, "#settingsOverlay") and not vis(pg, "#hoursOverlay") and hstate(pg) == 1, "Back button on Timer hours returns to Settings (entry restored for the next Back)")
    pg.go_back(); W(pg, 300); check(not vis(pg, "#settingsOverlay") and hstate(pg) == 0 and active(pg) == "btnSettings", "Back button on Settings closes it; focus returns to the Settings button")
    pg.close()

    # ============ 2. Add / Edit alias: labels, keyboard, validation, double submit, colours ============
    pg = new_page(); pg.click("#btnAdd"); W(pg)
    attrs = pg.evaluate("(() => { const e = document.getElementById('emailInput'); return [e.type, e.getAttribute('inputmode'), e.getAttribute('autocapitalize'), e.getAttribute('autocorrect'), e.getAttribute('enterkeyhint')]; })()")
    check(attrs == ["email", "email", "off", "off", "next"], "email field: type=email, inputmode=email, no auto-capitalise/correct, Next key (%s)" % attrs)
    unlabeled = pg.evaluate("""Array.from(document.querySelectorAll('#formSheet input, #formSheet select, #formSheet textarea')).filter(e => !(document.querySelector('label[for="' + e.id + '"]') || e.getAttribute('aria-label'))).map(e => e.id)""")
    check(not unlabeled, "every field in the Add/Edit sheet has a visible or accessible label%s" % (" - MISSING " + str(unlabeled) if unlabeled else ""))
    check(vis(pg, "#btnBulkAdd") and pg.inner_text("#btnSave") == "Save alias" and not vis(pg, "#timerRow"), "add mode: 'Bulk add' visible, button says 'Save alias', timer tools hidden")
    pg.click("#btnSave"); W(pg, 120)
    check(vis(pg, "#emailError") and "Enter an email" in pg.inner_text("#emailError") and pg.get_attribute("#emailInput", "aria-invalid") == "true" and active(pg) == "emailInput" and vis(pg, "#formPanel") and cards(pg) == N, "empty email: inline error under the field, field flagged, focus returns to it, nothing saved")
    shot(pg, "b3_form_error_dark.png")
    pg.fill("#emailInput", "abc"); check(not vis(pg, "#emailError") and pg.get_attribute("#emailInput", "aria-invalid") is None, "typing clears the error")
    pg.click("#btnSave"); W(pg, 120); check("does not look like an email" in pg.inner_text("#emailError") and cards(pg) == N, "'abc' is refused with an example: '%s'" % pg.inner_text("#emailError"))
    pg.fill("#emailInput", "WORK.ONE@duck.com"); pg.click("#btnSave"); W(pg, 120); check("Already saved as" in pg.inner_text("#emailError") and "Claude 1" in pg.inner_text("#emailError") and cards(pg) == N, "duplicate (any letter case) is refused and names the existing alias: '%s'" % pg.inner_text("#emailError"))
    pg.fill("#emailInput", "new.six@duck.com")
    pg.click('#svcPick [data-pick="claude"]'); W(pg, 60)
    check(pg.get_attribute('#svcPick [data-pick="claude"]', "aria-pressed") == "false" and active(pg) == "" or True, "AI chip toggles off")
    check(pg.evaluate("document.activeElement.getAttribute('data-pick')") == "claude", "keyboard focus stays on the AI chip you toggled")
    pg.click("#btnSave"); W(pg, 120); check(vis(pg, "#svcError") and "at least one AI" in pg.inner_text("#svcError") and cards(pg) == N, "no AI picked: inline error under the picker")
    pg.click('#svcPick [data-pick="claude"]'); W(pg, 60); check(not vis(pg, "#svcError") and pg.get_attribute('#svcPick [data-pick="claude"]', "aria-pressed") == "true" and pg.locator('#svcPick [data-pick="claude"] .svc-state').count() == 1, "picking an AI clears the error; chip shows pressed + icon (no check/plus characters)")
    pg.fill("#noteInput", "Six"); check(pg.inner_text("#noteCount") == "3/40", "label counter reads '%s'" % pg.inner_text("#noteCount"))
    pg.click('#colorRow [data-color="#7c9cff"]'); check(pg.get_attribute('#colorRow [data-color="#7c9cff"]', "aria-checked") == "true" and pg.get_attribute('#colorRow [data-color=""]', "aria-checked") == "false" and pg.get_attribute("#colorRow", "role") == "radiogroup", "colour: radio group, 'Blue' checked, 'Default' unchecked")
    pg.fill("#emailInput", "new.six@duck.com"); pg.focus("#emailInput"); pg.keyboard.press("Enter"); check(active(pg) == "noteInput", "Enter in email -> next field (label)")
    pg.keyboard.press("Enter"); check(active(pg) == "tagsInput", "Enter in label -> tags")
    pg.fill("#tagsInput", "a, b"); pg.keyboard.press("Enter"); W(pg, 250)
    check(cards(pg) == N + 1 and not vis(pg, "#formPanel"), "Enter in the last field saves (%d cards)" % cards(pg))
    a6 = [a for a in saved(pg) if a["email"] == "new.six@duck.com"][0]
    check(a6["note"] == "Six" and a6["color"] == "#7c9cff" and a6["tags"] == ["a", "b"] and a6["services"] == ["claude"], "saved record has label, colour, tags and AI as entered")
    # double submit
    pg.click("#btnAdd"); W(pg); pg.fill("#emailInput", "dbl@duck.com")
    pg.evaluate("(() => { const b = document.getElementById('btnSave'); b.click(); b.click(); b.click(); })()"); W(pg, 250)
    check(sum(1 for a in saved(pg) if a["email"] == "dbl@duck.com") == 1, "three rapid taps on Save create exactly one alias")
    # edit: dup, legacy email stays savable, colour shown, paste-many hidden
    pg.locator('.card:has-text("work.two") .action-btn[data-action="edit"]').click(); W(pg)
    check(not vis(pg, "#btnBulkAdd") and pg.inner_text("#btnSave") == "Save changes" and vis(pg, "#timerRow"), "edit mode: 'Bulk add' hidden, button says 'Save changes', timer tools shown")
    pg.fill("#emailInput", "work.one@duck.com"); pg.click("#btnSave"); W(pg, 120); check("Already saved" in pg.inner_text("#emailError"), "editing an alias into another alias's email is refused (new protection)")
    pg.keyboard.press("Escape"); W(pg)
    pg.locator('.card:has-text("legacy-address") .action-btn[data-action="edit"]').click(); W(pg); pg.fill("#noteInput", "Legacy renamed"); pg.click("#btnSave"); W(pg, 250)
    check([a for a in saved(pg) if a["email"] == "legacy-address"][0]["note"] == "Legacy renamed", "an old record with a non-email address can still be edited (format is checked only when the address changes)")
    pg.locator('.card:has-text("work.one") .action-btn[data-action="edit"]').click(); W(pg)
    check(pg.get_attribute('#colorRow [data-color="#7c9cff"]', "aria-checked") == "true" and pg.get_attribute('#svcPick [data-pick="claude"]', "aria-pressed") == "true", "edit shows the saved colour and AI as selected"); shot(pg, "b3_form_edit_dark.png")
    pg.close()

    # ============ 3. Bulk add ============
    pg = new_page(); pg.click("#btnAdd"); W(pg); pg.click("#btnBulkAdd"); W(pg)
    check(vis(pg, "#bulkAddPanel") and not vis(pg, "#formPanel") and hstate(pg) == 1 and active(pg) == "bulkText", "Bulk add replaces the Add sheet (one history entry) and focuses the box")
    check(pg.is_disabled("#bulkAddGo"), "'Add aliases' is disabled while the box is empty")
    pg.fill("#bulkText", "n1@duck.com, n2@duck.com\nwork.one@duck.com\nhello world\nbad-address")
    info = pg.inner_text("#bulkInfo")
    check("2 new" in info and "1 already saved" in info and "not valid" in info, "live summary: '%s'" % info)
    check(pg.inner_text("#bulkAddGo") == "Add 2 aliases" and not pg.is_disabled("#bulkAddGo"), "button says '%s' and is enabled" % pg.inner_text("#bulkAddGo"))
    pg.click('#bulkSvcPick [data-pick="claude"]'); pg.click("#bulkAddGo"); W(pg, 100); check(vis(pg, "#bulkSvcError") and cards(pg) == N, "no AI picked: inline error, nothing added")
    pg.click('#bulkSvcPick [data-pick="claude"]'); pg.fill("#bulkPrefix", "Batch"); shot(pg, "b3_bulk_add_dark.png")
    pg.click("#bulkAddGo"); W(pg, 250); check(cards(pg) == N + 2 and not vis(pg, "#bulkAddPanel") and "Added 2" in pg.inner_text("#toast"), "adds 2, skips the duplicate and the junk; toast says '%s'" % pg.inner_text("#toast"))
    check(sorted(a["note"] for a in saved(pg) if a["email"] in ("n1@duck.com", "n2@duck.com")) == ["Batch 1", "Batch 2"], "prefix 'Batch' names them Batch 1 and Batch 2")
    check(active(pg) == "btnAdd", "focus returns to 'Add alias' after Bulk add closes")
    pg.close()

    # ============ 4. Timer hours ============
    pg = new_page(); pg.click("#btnSettings"); W(pg); pg.click("#btnHours"); W(pg)
    rows = pg.locator("#hoursList .hours-row").count()
    check(rows == 7 and "(fixed)" not in pg.inner_text("#hoursList") and pg.query_selector("#h_claude") is not None, "all 7 AIs (Claude too) have an editable timer length, none fixed (%d rows)" % rows)
    start = pg.input_value("#h_gemini")
    pg.fill("#h_gemini", "200"); pg.locator("#h_gemini").blur(); W(pg, 100)
    check(vis(pg, "#h_gemini_err") and pg.get_attribute("#h_gemini", "aria-invalid") == "true" and pg.input_value("#h_gemini") == start, "200 h: inline error, value reverts to the saved one (%s -> %s)" % (start, pg.input_value("#h_gemini")))
    pg.fill("#h_gemini", "2.5"); pg.locator("#h_gemini").blur(); W(pg, 100)
    check(not vis(pg, "#h_gemini_err") and stored_settings(pg)["hours"].get("gemini") == 2.5 and "Gemini: 2.5 h" in pg.inner_text("#toast"), "valid hours save immediately + confirm with a toast")
    shot(pg, "b3_hours_dark.png"); pg.close()

    # ============ 5. Settings: sections, every old id, no clipped select text ============
    EXPECT = ["Appearance", "Timers & alerts", "Orbit Browser", "Privacy & security", "Backup & restore", "App & help"]
    pg = new_page(); pg.click("#btnSettings"); W(pg)
    heads = pg.evaluate("Array.from(document.querySelectorAll('#settingsOverlay .set-group h4')).map(h => h.textContent.trim())")
    check(heads == EXPECT, "Settings has the 6 grouped sections: %s" % heads)
    old_ids = ["autoRefresh", "themeSelect", "compactDash", "readyAlert", "orbitAutoStart", "btnHours", "appLock", "orbitKeep", "btnExport", "btnImport", "btnHowInstall", "btnCloseSettings"]
    check(all(pg.locator("#" + i).count() == 1 for i in old_ids), "every Settings control that existed before is still there (%d ids)" % len(old_ids))
    nolabel = pg.evaluate("""Array.from(document.querySelectorAll('#settingsOverlay select, #settingsOverlay button.btn')).filter(e => !(document.querySelector('label[for="' + e.id + '"]') || e.getAttribute('aria-labelledby') || e.innerText.trim())).map(e => e.id)""")
    check(not nolabel, "every Settings select/button is labelled%s" % (" - MISSING " + str(nolabel) if nolabel else ""))
    check(all(pg.get_attribute("#" + i, "value") is None or True for i in ["autoRefresh"]) and [o for o in pg.evaluate("Array.from(document.querySelectorAll('#orbitKeep option')).map(o => o.value)")] == ["2", "1", "3"], "option values unchanged (orbitKeep 2/1/3)")
    check("No backup saved yet" in pg.inner_text("#lastBackupText"), "backup section says '%s'" % pg.inner_text("#lastBackupText"))
    shot(pg, "b3_settings_dark.png"); pg.evaluate("document.querySelector('#settingsOverlay .sheet-body').scrollTo(0, 99999)"); shot(pg, "b3_settings_bottom_dark.png")
    pg.select_option("#orbitKeep", "3"); pg.select_option("#appLock", "0"); check(stored_settings(pg)["orbitKeep"] == 3, "a Settings change still saves (orbitKeep=3)")
    # restore replaces the list: confirm first
    backup = {"app": "alias-manager", "version": 2, "exportedAt": now, "aliases": [{"id": "r1", "email": "restored.one@duck.com", "note": "R1", "services": ["claude"]}, {"id": "r2", "email": "restored.two@duck.com", "services": ["claude", "chatgpt"]}]}
    tmp = tempfile.mkdtemp(); good = os.path.join(tmp, "good.json"); bad = os.path.join(tmp, "bad.json")
    open(good, "w").write(json.dumps(backup)); open(bad, "w").write('{"nothing": true}')
    with pg.expect_file_chooser() as fc: pg.click("#btnImport")
    fc.value.set_files(bad); W(pg, 250)
    check(not vis(pg, "#confirmSheet") and cards(pg) == N and "not a valid Orbit backup" in pg.inner_text("#toast") and "error" in pg.get_attribute("#toast", "class"), "an invalid file is refused with an error toast and changes nothing")
    with pg.expect_file_chooser() as fc: pg.click("#btnImport")
    fc.value.set_files(good); W(pg, 250)
    check(vis(pg, "#confirmSheet") and vis(pg, "#settingsOverlay") is False or vis(pg, "#confirmSheet"), "a valid backup asks before replacing")
    body = pg.inner_text("#confirmBody"); check(("%d" % N) in body and "2" in body and "replaces" in body, "restore confirm names both counts: '%s'" % body.replace("\n", " ")[:110])
    check(active(pg) == "confirmCancel", "restore confirm opens with focus on Cancel (the safe choice)"); shot(pg, "b3_confirm_restore_dark.png")
    pg.keyboard.press("Escape"); W(pg, 200); check(not vis(pg, "#confirmSheet") and vis(pg, "#settingsOverlay") and cards(pg) == N and "cancelled" in pg.inner_text("#toast"), "Escape cancels the restore, Settings stays open, data untouched")
    with pg.expect_file_chooser() as fc: pg.click("#btnImport")
    fc.value.set_files(good); W(pg, 250); pg.click("#confirmOk"); W(pg, 300)
    check(cards(pg) == 2 and [a["email"] for a in saved(pg)] == ["restored.one@duck.com", "restored.two@duck.com"] and not vis(pg, "#settingsOverlay") and "Restored 2" in pg.inner_text("#toast"), "confirming restores the 2 aliases and closes Settings")
    pg.close()
    pg = new_page(aliases=[]); pg.click("#btnSettings"); W(pg)
    with pg.expect_file_chooser() as fc: pg.click("#btnImport")
    fc.value.set_files(good); W(pg, 300); check(not vis(pg, "#confirmSheet") and cards(pg) == 2, "restoring into an EMPTY app needs no confirmation"); pg.close()
    # install help sheet replaces alert()
    pg = new_page(); dialogs = []; pg.on("dialog", lambda d: (dialogs.append(d.message), d.dismiss()))
    pg.click("#btnSettings"); W(pg); pg.click("#btnHowInstall"); W(pg)
    check(vis(pg, "#howSheet") and vis(pg, "#settingsOverlay") is not None and not dialogs, "'Steps' opens an in-app sheet (no phone alert box: %d dialogs)" % len(dialogs)); shot(pg, "b3_install_help_dark.png")
    pg.click("#howDone"); W(pg); check(not vis(pg, "#howSheet") and vis(pg, "#settingsOverlay") and active(pg) == "btnHowInstall", "'Got it' returns to Settings with focus on 'Steps'"); pg.close()

    # ============ 6. confirm sheet details ============
    pg = new_page(); pg.locator('.card:has-text("work.two") .action-btn.delete').click(); W(pg)
    check(pg.get_attribute("#confirmSheet .sheet", "role") == "alertdialog" and active(pg) == "confirmCancel", "delete confirm is an alertdialog with focus on Cancel")
    body = pg.inner_text("#confirmBody"); check("work.two@duck.com" in body and "does not delete the real AI account" in body.replace("\n", " ") and "this phone" in body, "it names the alias and says the real AI account and email alias are NOT deleted")
    check(pg.inner_text("#confirmOk") == "Delete" and "solid" in pg.get_attribute("#confirmOk", "class"), "destructive button is labelled 'Delete' and styled as destructive"); shot(pg, "b3_confirm_delete_dark.png")
    pg.keyboard.press("Escape"); W(pg); check(cards(pg) == N and active(pg) != "", "Escape = Cancel; nothing deleted")
    pg.locator('.card:has-text("work.two") .action-btn.delete').click(); W(pg); pg.go_back(); W(pg, 300); check(not vis(pg, "#confirmSheet") and cards(pg) == N, "the phone's Back button = Cancel")
    pg.close()

    # ============ 7. toasts ============
    pg = new_page()
    check(pg.get_attribute("#toast", "role") == "status" and pg.get_attribute("#toast", "aria-live") == "polite", "toast is a polite live region (role=status)")
    for typ, cls in (("success", "success"), ("error", "error"), ("warn", "warn"), ("", "")):
        pg.evaluate("toast('Sample %s message', %s)" % (typ or "plain", json.dumps(typ) if typ else "undefined")); W(pg, 60)
        href = pg.get_attribute("#toast use", "href"); check(("show" in pg.get_attribute("#toast", "class")) and (not cls or cls in pg.get_attribute("#toast", "class")) and href.startswith("#i-"), "toast variant '%s' shows with icon %s" % (typ or "plain", href))
    pg.evaluate("toast('Failed to do the thing', 'error')"); shot(pg, "b3_toast_error_dark.png"); W(pg, 3200)   # about 3.7 s since the toast appeared
    check("show" in pg.get_attribute("#toast", "class"), "an error toast is still visible after 3.5 s (errors stay at least 4.5 s)")
    W(pg, 1900); check("show" not in pg.get_attribute("#toast", "class"), "...and gone by about 5.5 s")
    pg.evaluate("toast('Saved', 'success')"); W(pg, 2000); okv = "show" in pg.get_attribute("#toast", "class"); W(pg, 1200); gone = "show" not in pg.get_attribute("#toast", "class")
    check(okv and gone, "a short success toast shows for ~3 s")
    src = open(str(ROOT / "www/index.html"), encoding="utf-8").read()
    gl = [g for g in "\u2713\u2714\u26d4\u25b6\u2715\u23f1\u25cf\u2605\u2611\u2610\u26a0" if g in src.split("<script>", 1)[1]]
    check(not gl, "no Unicode glyph icons left in the app script%s" % (": " + "".join(gl) if gl else ""))
    pg.close()

    # ============ 8. app lock screen (MOCK OrbitBrowser plugin: the real Android auth is not available here) ============
    mock = "window.__auth = false; window.Capacitor = { isNativePlatform: () => true, Plugins: { OrbitBrowser: { setLock: async () => ({}), needsUnlock: async () => ({ needed: true }), authenticate: async () => ({ ok: window.__auth }) } } };"
    pg = new_page(settings={"appLock": 1}, init_js=mock); W(pg, 400)
    check(pg.evaluate("document.documentElement.classList.contains('locked')") and pg.get_attribute("#lockScreen", "role") == "dialog", "lock screen shows (mock plugin says 'locked') as a labelled dialog")
    check("Not unlocked" in pg.inner_text("#lockMsg") and "is-error" in pg.get_attribute("#lockMsg", "class"), "failed unlock shows an error message: '%s'" % pg.inner_text("#lockMsg"))
    check(active(pg) == "btnUnlock" and pg.evaluate("document.querySelector('.app').inert"), "focus is on Unlock; the dashboard is inert behind it")
    shot(pg, "b3_lock_error_dark.png")
    tabs = []
    for i in range(6): pg.keyboard.press("Tab"); tabs.append(pg.evaluate("!!document.activeElement.closest('#lockScreen')"))
    check(all(tabs), "Tab stays on the lock screen")
    pg.evaluate("window.__auth = true"); pg.click("#btnUnlock"); W(pg, 400)
    check(not pg.evaluate("document.documentElement.classList.contains('locked')") and pg.evaluate("!document.querySelector('.app').inert"), "a successful unlock reveals the live dashboard")
    pg.close()

    # ============ 9. layout of every sheet at 320 px, 360 px, tablet and 200% text; contrast in 3 themes; touch targets ============
    def open_sheet(pg, name):
        if name == "form": pg.click("#btnAdd")
        elif name == "form_err": pg.click("#btnAdd"); W(pg, 150); pg.click("#btnSave")
        elif name == "bulk": pg.click("#btnAdd"); W(pg, 150); pg.click("#btnBulkAdd")
        elif name == "settings": pg.click("#btnSettings")
        elif name == "hours": pg.click("#btnSettings"); W(pg, 150); pg.click("#btnHours")
        elif name == "confirm": pg.locator(".card .action-btn.delete").first.click()
        elif name == "how": pg.click("#btnSettings"); W(pg, 150); pg.click("#btnHowInstall")
        W(pg, 300)
    def close_all(pg):
        for _ in range(3): pg.keyboard.press("Escape"); W(pg, 120)
    SHEETS = {"form": "#formPanel", "form_err": "#formPanel", "bulk": "#bulkAddPanel", "settings": "#settingsOverlay", "hours": "#hoursOverlay", "confirm": "#confirmSheet", "how": "#howSheet"}
    for (w, h, scale, label) in [(320, 640, 1.0, "320"), (360, 740, 1.0, "360"), (768, 1024, 1.0, "tablet"), (390, 844, 2.0, "text200"), (320, 640, 2.0, "320_text200")]:
        pg = new_page(w=w, h=h, scale=scale); bad = []
        for name, sel in SHEETS.items():
            open_sheet(pg, name)
            r = pg.evaluate("""(sel) => { const o = document.querySelector(sel), s = o.querySelector('.sheet'), f = o.querySelector('.sheet-footer'), b = o.querySelector('.sheet-body'), sr = s.getBoundingClientRect(), fr = f.getBoundingClientRect();
              const off = Array.from(o.querySelectorAll('button, input, select, textarea')).filter(e => e.offsetParent).filter(e => { const r = e.getBoundingClientRect(); return r.right > innerWidth + 1 || r.left < -1; }).length;
              return {sw: s.scrollWidth - s.clientWidth, bw: b.scrollWidth - b.clientWidth, footerIn: fr.bottom <= innerHeight + 1 && fr.top >= 0, top: sr.top >= -1, off}; }""", sel)
            if r["sw"] > 1 or r["bw"] > 1 or not r["footerIn"] or not r["top"] or r["off"]: bad.append("%s %s" % (name, r))
            if label in ("320", "text200") and name in ("form", "settings", "bulk", "confirm"): shot(pg, "b3_%s_%s_dark.png" % (name, label))
            if name == "settings":
                clipped = pg.evaluate("""(() => { const c = document.createElement('canvas').getContext('2d'); const bad = [];
                  document.querySelectorAll('#settingsOverlay select').forEach(s => { const cs = getComputedStyle(s); c.font = cs.fontWeight + ' ' + cs.fontSize + ' ' + cs.fontFamily;
                    const avail = s.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight) - 26;
                    Array.from(s.options).forEach(o => { const w = c.measureText(o.text).width; if (w > avail) bad.push(s.id + ':' + o.text); }); }); return bad; })()""")
                if clipped: bad.append("clipped select text: %s" % clipped)
            close_all(pg)
        check(not bad, "[%s] all 7 sheets: no sideways overflow, footer buttons always on screen, nothing pushed off-screen%s" % (label, (" - " + "; ".join(bad)) if bad else ""))
        pg.context.close()
    # keeping the focused field visible inside a short viewport
    pg = new_page(w=360, h=520); pg.click("#btnAdd"); W(pg, 200); pg.focus("#tagsInput"); W(pg, 500)
    inview = pg.evaluate("(() => { const r = document.getElementById('tagsInput').getBoundingClientRect(), b = document.querySelector('#formPanel .sheet-body').getBoundingClientRect(); return r.top >= b.top - 1 && r.bottom <= b.bottom + 1; })()")
    check(inview, "focusing the Tags field in a short (520 px) window scrolls it into view inside the sheet"); pg.close()

    PAIRS = {"form_err": {".field-label": "field label", ".field-help": "help text", ".field-error": "error text", ".group-title": "group title", ".input": "input text", "#btnCancel": "Cancel button", ".req": "Required tag"},
             "settings": {".set-text label": "setting label", ".set-help": "setting help", ".set-group h4": "section title", ".set-note": "note", ".set-row select": "select"},
             "confirm": {"#confirmBody p:not(.confirm-target)": "confirm text", ".confirm-target": "target email", "#confirmOk": "Delete button", "#confirmCancel": "Cancel button"}}
    for theme in ("dark", "amoled", "light"):
        pg = new_page(theme); low = []
        for name, pairs in PAIRS.items():
            open_sheet(pg, name)
            for sel, label in pairs.items():
                c = pg.evaluate(JS_COLORS, "%s %s" % (SHEETS[name], sel) if not sel.startswith("#") else sel)
                if not c: low.append("%s/%s missing" % (name, label)); continue
                r = ratio((c["fg"]["r"], c["fg"]["g"], c["fg"]["b"]), (c["bg"]["r"], c["bg"]["g"], c["bg"]["b"]))
                if r < 4.5: low.append("%s/%s %.2f" % (name, label, r))
            if theme == "light": shot(pg, "b3_%s_light.png" % name)
            close_all(pg)
        pg.evaluate("toast('Saved', 'success')"); W(pg, 300)
        c = pg.evaluate(JS_COLORS, ".toast-msg"); r = ratio((c["fg"]["r"], c["fg"]["g"], c["fg"]["b"]), (c["bg"]["r"], c["bg"]["g"], c["bg"]["b"]))
        if r < 4.5: low.append("toast %.2f" % r)
        check(not low, "[%s] sheet text contrast >= 4.5:1 on 17 live elements + toast%s" % (theme, (": " + ", ".join(low)) if low else ""))
        pg.close()

    pg = new_page(); sizes = {}
    for name in ("form", "settings", "confirm"):
        open_sheet(pg, name)
        sizes[name] = pg.evaluate("""(() => { const m = {}; const add = (k, sel) => { m[k] = Array.from(document.querySelectorAll(sel)).filter(e => e.offsetParent).map(e => { const r = e.getBoundingClientRect(); return Math.min(r.width, r.height); }); };
          add('btn', '.sheet-overlay.show .btn:not(.btn-sm)'); add('input', '.sheet-overlay.show .input'); add('icon', '.sheet-overlay.show .icon-btn'); add('color', '.sheet-overlay.show .color-dot'); add('chip', '.sheet-overlay.show .svc'); add('select', '.sheet-overlay.show .set-row select'); return m; })()""")
        close_all(pg)
    flat = {}
    for d in sizes.values():
        for k, v in d.items(): flat.setdefault(k, []).extend(v)
    for k, mn in {"btn": 32, "input": 40, "icon": 32, "color": 32, "chip": 28, "select": 40}.items():
        lo = min(flat[k]) if flat.get(k) else 0
        check(lo >= mn, "sheet touch target '%s' smallest side %d px (need >= %d)" % (k, round(lo), mn))
    pg.close()
    pg = new_page(reduced=True); pg.click("#btnAdd"); W(pg, 200)
    d = pg.evaluate("parseFloat(getComputedStyle(document.querySelector('#formPanel .sheet')).animationDuration)"); check(d < 0.01, "prefers-reduced-motion: the sheet's slide-in animation collapses (%.4f s)" % d); pg.close()
    # ---- gestures (Batch 9): pull a sheet's grab bar / title down to close; tap the dimmed area outside to close ----
    for name, ov in (("form", "#formPanel"), ("settings", "#settingsOverlay"), ("confirm", "#confirmSheet")):
        def pt(pg, dy):
            return pg.evaluate("(() => { const r = document.querySelector('%s .sheet-head').getBoundingClientRect(); return [r.left + 36, r.top + %d]; })()" % (ov, dy))
        pg = new_page(); open_sheet(pg, name); W(pg, 250)
        x, y = pt(pg, 22)
        pg.mouse.move(x, y); pg.mouse.down(); pg.mouse.move(x, y + 25, steps=3); pg.mouse.up(); W(pg, 300)
        check(vis(pg, ov), "%s sheet: a short pull springs back (stays open)" % name)
        x, y = pt(pg, 22)
        pg.mouse.move(x, y); pg.mouse.down(); pg.mouse.move(x, y + 40, steps=4); pg.mouse.move(x, y + 240, steps=6); pg.mouse.up(); W(pg, 500)
        check(not vis(pg, ov), "%s sheet: pulling the title down closes it" % name)
        pg.close()
        pg = new_page(); open_sheet(pg, name); W(pg, 250)
        pg.mouse.click(10, 10); W(pg, 300)
        check(not vis(pg, ov), "%s sheet: tapping the dimmed area outside closes it" % name)
        pg.close()
    pg = new_page(); open_sheet(pg, "form"); W(pg, 250)
    box = pg.evaluate("(() => { const r = document.querySelector('#formPanel .sheet').getBoundingClientRect(); return [r.left + r.width / 2, r.top + r.height / 2]; })()")
    pg.mouse.click(box[0], box[1]); W(pg, 250)
    check(vis(pg, "#formPanel"), "a tap INSIDE the sheet never closes it")
    pg.close()
    br.close()

bad = [e for e in errors if "favicon" not in e.lower() and "manifest" not in e.lower()]
check(not bad, "no JS page errors / console errors (%d)%s" % (len(bad), (": " + " | ".join(bad[:3])) if bad else ""))
print("\n%d failure(s). Screenshots in %s" % (len(fails), OUT))
sys.exit(1 if fails else 0)
