#!/bin/bash
# One command = every check that can run WITHOUT the Android SDK / network.   bash tools/run_all_checks.sh [screenshot_dir] [all|static|ui]
# "static" = steps 1-6 (about 30 s), "ui" = steps 7-8 (two browser suites, about 4 minutes together). Some tool environments cap one call at 300 s: run the two parts separately there.
# NOT covered here (needs the real build / a phone): javac type-check, Gradle/AAPT, APK contents, any native runtime behaviour.
cd "$(dirname "$0")/.." || exit 1
SHOTS="${1:-/tmp/orbit_shots}"; PART="${2:-all}"; FAIL=0
step() { echo; echo "### $1"; }
ok()   { echo "PASS  $1"; }
bad()  { echo "FAIL  $1"; FAIL=1; }

if [ "$PART" != "ui" ]; then
step "1. Web: inline <script> blocks + service worker parse (node --check)"
python3 - <<'PY'
import re
t=open('www/index.html',encoding='utf-8').read()
for i,b in enumerate(re.findall(r'<script>(.*?)</script>',t,re.S)): open('/tmp/_inline%d.js'%i,'w').write(b)
PY
for f in /tmp/_inline*.js www/sw.js; do node --check "$f" && ok "node --check $f" || bad "node --check $f"; done

step "2. JSON / XML / Python / YAML well-formedness"
python3 -c "import json;[json.load(open(f)) for f in ('www/manifest.json','capacitor.config.json','package.json')]" && ok "manifest.json, capacitor.config.json, package.json" || bad "JSON"
python3 - <<'PY' && ok "all native/res XML files parse" || bad "native/res XML"
import glob, xml.dom.minidom as m
for f in glob.glob('native/res/**/*.xml', recursive=True): m.parse(f)
PY
python3 -c "import ast;ast.parse(open('native_patch.py').read())" && ok "native_patch.py syntax" || bad "native_patch.py syntax"
python3 -c "import yaml;yaml.safe_load(open('.github/workflows/build.yml'))" && ok "build.yml YAML" || bad "build.yml YAML"
python3 -c "
import json;c=json.load(open('capacitor.config.json'));assert c['appId']=='com.aliasmanager.app' and c['appName']=='Orbit'" && ok "appId com.aliasmanager.app + appName Orbit unchanged" || bad "appId/appName changed"

step "3. Java: syntax parse + symbol gate (NO Android SDK here: Android types are unknown to the checker, see tools/JavaSymbolGate.java)"
java tools/ParseJava.java native/java/*.java 2>&1 | tail -2 | grep -q "PARSE OK" && ok "5 native Java files parse" || bad "Java parse"
java tools/JavaSymbolGate.java --check tools/java_symbols.baseline native/java/*.java > /tmp/_gate.out 2>&1; GATE=$?; tail -3 /tmp/_gate.out | cut -c1-200
[ $GATE = 0 ] && ok "symbol gate: no real errors, no new unresolved symbols" || bad "symbol gate (new symbol to verify, or a real error: see above; re-record with --record after checking)"
grep -q "PURPLE" native/java/*.java && bad "stale PURPLE reference" || ok "no stale PURPLE reference (renamed to C_ACCENT)"
python3 - <<'PY' && ok "every glyph->icon name in OrbitBrowserActivity has a native/res/drawable/orbit_ic_<name>.xml" || bad "glyph table points at a missing icon file"
import re,sys
t=open('native/java/OrbitBrowserActivity.java',encoding='utf-8').read()
blk=t[t.index('GLYPH_ICONS = {'):t.index('private String iconNameFor')]
names=set(re.findall(r',\s*"(\w+)"\}',blk)); import os
missing=[n for n in names if not os.path.exists('native/res/drawable/orbit_ic_%s.xml'%n)]
print("icons referenced:",len(names),"missing files:",missing or "none"); sys.exit(1 if missing else 0)
PY

step "4. HTML integrity: every getElementById target exists, no duplicate ids, every icon id exists"
python3 - <<'PY' && ok "ids + icons consistent" || bad "ids/icons"
import re,sys
t=open('www/index.html',encoding='utf-8').read()
html=t[:t.index('<script>',t.index('<body>'))] if False else t
ids=re.findall(r'\bid="([^"]+)"',re.sub(r"<script>.*?</script>","",t,flags=re.S))
js=''.join(re.findall(r'<script>(.*?)</script>',t,re.S))
missing=sorted(set(re.findall(r'getElementById\("([^"]+)"\)',js))-set(ids))
dup=sorted({x for x in ids if ids.count(x)>1})
syms=set(re.findall(r'<symbol id="i-([^"]+)"',t))
used=set(re.findall(r'href="#i-([\w-]+)"',t))|set(re.findall(r'icon\("([\w-]+)"',t))|{'star','star-on'}
miss_i=sorted(used-syms)
print("missing ids:",missing or "none","| duplicate ids:",dup or "none","| missing icons:",miss_i or "none")
sys.exit(1 if (missing or dup or miss_i) else 0)
PY

step "5. Brand assets measured (python3 tools/check_brand_assets.py)"
python3 tools/check_brand_assets.py | grep -E "FAIL|failure" ; [ "${PIPESTATUS[0]}" = "0" ] && ok "brand asset checks" || bad "brand asset checks"

step "6. native_patch.py on a simulated Capacitor project, 4 runs (idempotency)"
W=/tmp/orbit_idem; rm -rf $W; mkdir $W; tar --exclude=__pycache__ --exclude=.git -cf - . | tar -xf - -C $W
( cd $W && mkdir -p android/app/src/main/java/com/aliasmanager/app
  printf 'package com.aliasmanager.app;\n\nimport com.getcapacitor.BridgeActivity;\n\npublic class MainActivity extends BridgeActivity {}\n' > android/app/src/main/java/com/aliasmanager/app/MainActivity.java
  printf '<?xml version="1.0" encoding="utf-8" ?>\n<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n    <application android:allowBackup="true" android:icon="@mipmap/ic_launcher" android:label="@string/app_name" android:roundIcon="@mipmap/ic_launcher_round" android:theme="@style/AppTheme">\n        <activity android:name=".MainActivity" android:exported="true" />\n    </application>\n    <uses-permission android:name="android.permission.INTERNET" />\n</manifest>\n' > android/app/src/main/AndroidManifest.xml
  printf "apply plugin: 'com.android.application'\nandroid { namespace \"com.aliasmanager.app\" }\ndependencies {\n    implementation fileTree(include: ['*.jar'], dir: 'libs')\n}\n" > android/app/build.gradle
  for i in 1 2 3 4; do python3 native_patch.py >/tmp/_np$i.log 2>&1 || { echo "run $i FAILED"; exit 1; }; done
  M=android/app/src/main/AndroidManifest.xml
  for k in OrbitBrowserActivity OrbitReminderReceiver OrbitWidgetProvider OrbitKeepAliveService '@mipmap/orbit_launcher:2' .fileprovider androidx.webkit; do
    n=${k##*:}; key=${k%%:*}; [ "$n" = "$k" ] && n=1
    c=$(grep -o "$key" $M android/app/build.gradle | wc -l); [ "$c" = "$n" ] && echo "PASS  $key x$c" || echo "FAIL  $key x$c (want $n)"; done
  for p in "orbit_icon_fg.png" ; do cmp -s native/res/drawable-nodpi/$p android/app/src/main/res/drawable-nodpi/$p && echo "PASS  $p copied byte-identical" || echo "FAIL  $p"; done
  n_src=$(ls native/res/drawable/orbit_ic_*.xml | wc -l); n_dst=$(ls android/app/src/main/res/drawable/orbit_ic_*.xml 2>/dev/null | wc -l)
  [ "$n_src" = "$n_dst" ] && [ "$n_src" -gt 0 ] && echo "PASS  all $n_src native icons (orbit_ic_*.xml) installed into the Android project" || echo "FAIL  native icons installed: $n_dst of $n_src"
  for f in native/res/drawable/orbit_ic_*.xml; do cmp -s "$f" "android/app/src/main/res/drawable/$(basename $f)" || echo "FAIL  $(basename $f) differs after install"; done
  grep -q 'FF000000' android/app/src/main/res/drawable/orbit_icon_bg.xml && echo "PASS  orbit_icon_bg.xml (black) installed" || echo "FAIL  orbit_icon_bg.xml" ) | tee /tmp/_idem.out
grep -q "^FAIL\|FAILED" /tmp/_idem.out && FAIL=1

fi
if [ "$PART" != "static" ]; then
step "7. Real browser: dashboard (tools/ui_smoke.py, Chromium 390x844 @2x)"
python3 -u tools/ui_smoke.py "$SHOTS" | grep -E "FAIL|failure|Screenshots"; [ "${PIPESTATUS[0]}" = "0" ] && ok "ui_smoke (dashboard)" || bad "ui_smoke (dashboard)"

step "8. Real browser: sheets, forms, Settings, confirmations, toasts, lock screen (tools/ui_sheets.py)"
python3 -u tools/ui_sheets.py "$SHOTS" | grep -E "FAIL|failure|Screenshots"; [ "${PIPESTATUS[0]}" = "0" ] && ok "ui_sheets" || bad "ui_sheets"
fi

echo; [ $FAIL = 0 ] && echo "ALL CHECKS PASSED" || echo "SOME CHECKS FAILED"; exit $FAIL
