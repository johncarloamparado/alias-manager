ORBIT MULTI-PROFILE BROWSER (ANDROID)
====================================

What this adds
--------------
- A new Orbit Browser launcher in the existing Alias Manager UI.
- A native Android browser screen that stays inside the app.
- Named profiles using AndroidX WebKit's MULTI_PROFILE feature.
- Each profile gets separate WebView cookies/site data; only one WebView is active at a time.
- Profile names and selected profile are stored locally. Chat history is not copied into Alias Manager.
- If the installed Android System WebView does not support MULTI_PROFILE, the browser refuses to load a shared-session fallback, to avoid mixing account sessions.

Build behavior
--------------
The repository creates the Android project during GitHub Actions. After `npx cap sync android`,
`native_patch.py` installs the Java plugin/activity (native/java/), adds the AndroidX WebKit dependency, registers
the plugin, and declares the Activity.

How to build
------------
1. Commit/push this ZIP's project files to your repository.
2. Run the existing Compile Android APK GitHub Actions workflow.
3. Download and install the resulting debug APK.
4. Open Alias Manager > Orbit Browser.
5. Add a profile, sign into the official Claude website, then switch profiles to test isolation.

Important compatibility notes
-----------------------------
- This is a native integration, not an HTML-only simulation.
- Multi-profile support depends on the Android System WebView provider/version on the device.
  The app checks support at runtime. Update Android System WebView from the Play Store if needed.
- Claude may restrict sign-in or some functionality in embedded WebViews. This implementation does not
  disable those protections or guarantee compatibility. If Claude refuses the embedded environment,
  use its official supported browser/app instead.
- This is for organizing separate accounts, not bypassing Claude plan limits or service restrictions.
- Inactive WebViews are destroyed on profile switch to reduce RAM; each profile's website data persists.
  The page itself reloads when you switch back, so unsaved page state may be lost.
- Profile removal/data-wipe UI is intentionally not included yet to avoid accidental deletion of login data.

Implementation used: JAVA only (native/java/). The old Kotlin copy was removed because the generated
Capacitor project is Java-only and does not compile .kt files (this caused the OrbitBrowserPlugin
"cannot find symbol" build error).
native_patch.py is idempotent and checks, before Gradle runs, that the plugin sits in the same
folder/package as MainActivity, is registered once, and that the manifest/gradle are patched once.
After the build, the workflow also checks that the APK really contains the latest index.html and the
Orbit classes.
Status: NOT build-verified (Step 11 adds downloads, camera, app lock, widget, per-AI timers). Run the workflow.

Ready notifications
-------------------
OrbitReminderReceiver.java schedules an Android alarm for when each running 5h timer ends and shows a
"Ready" notification. Needs the notification permission on Android 13+ (the app asks). Alarms are inexact
(may be a few minutes late). After a phone reboot they are re-created automatically (BOOT_COMPLETED);
reminders that finished while the phone was off are shown right after boot.
Turn off with Settings > Ready alerts.

Profile management (⋯ button in Orbit)
--------------------------------------
Rename, emoji, color, and Delete (with a confirmation dialog). Renaming only changes the label: each
profile keeps a fixed internal WebView key, so the login is kept. Delete erases that profile's cookies and
site data on this phone (not the Claude account or chats) and removes its alias link. The last profile can't
be deleted. If the data can't be erased, the profile is kept and an error is shown.

Auto-start toggle
-----------------
Alias Manager > Settings > "Orbit auto-start timer" (On/Off). When Off, Orbit still remembers chats it sees
but does not start any timer (the toolbar shows "auto-start OFF"). Use "▶ Start" manually.


Step 8 additions
- Alias list: Alias Manager keeps a saved copy for Orbit (syncAliases), so the 🔗 Alias menu always has your emails.
- ✉ button: Gmail in its own isolated profile. claude.ai links tapped in Gmail open in the active Claude profile.
  Google may refuse sign-in inside an embedded WebView; this app does not try to disguise itself.
- claude.ai/login: the linked alias is filled into the email box (you tap Continue).
- Compact toolbar; ⋯ > Hide address bar for even more room.
- Delete profile: removed at once; its data is erased with retries, or at the next Orbit start.
- Chat detected with no alias linked: asks which alias, then starts that alias timer.
- 🌐 Open only appears for aliases that are logged in (or were started before).

Step 9 additions
----------------
- Tab labels: a profile still named "Account N" shows its linked alias (note, or the part before @). A profile you
  renamed keeps your name.
- ⋯ > "Sign out (keep this tab)": erases that profile's cookies/site data only; the tab, alias link and color stay.
  The alias's 🌐 Open button is hidden until you log in again.
- Limit detection (user-requested; follows Settings > Orbit auto-start): every 10 s, while the Claude page you are
  looking at is open on a profile with a linked alias, Orbit checks the page text for a "you've reached your limit"
  line. Only that one line (max 300 chars) is looked at; nothing else is read or stored. If a reset time can be read
  ("in 2 hours 10 minutes" / "at 3:30 PM", within the next 5 h) the alias becomes Running and Ready exactly then,
  with a notification; otherwise it is marked Running from now. A chat that merely TALKS about usage limits could
  trigger it by mistake - use ↺ Reset on the card if that happens.
- Backup: Settings > Export now writes {aliases, orbit}. orbit = profiles, which alias each profile uses, colors,
  emoji, WebView keys. Import restores them too (old plain-list backups still import). Logins/cookies are NOT in
  the backup - after a reinstall you sign in again, but the links come back.

Step 10 additions
-----------------
- Alias Manager redesign: new logo/theme (Galaxy, AMOLED, Light), cards with an AI checklist, no Start/Reset buttons
  (the timer is automatic; "Start now" / "Clear timer" are inside Edit). Name/label of an alias = Orbit tab name.
- Many AIs per alias: Claude, ChatGPT, Gemini, Grok, Perplexity, DeepSeek, Le Chat, Copilot (list = AI_PROVIDERS in
  www/index.html; letter badges, no brand logos). A chip shows ✓ when Orbit finds that site's sign-in cookie NAME in the
  alias's profile (values are never read). Sites without a known cookie: long-press the chip to mark it yourself.
  Tapping a chip opens that AI in Orbit for that alias (a new isolated profile is created if the alias has none).
  The 5h timer / limit detection stay Claude-only.
- Orbit: AI chip row + "Switch AI…", long-press a tab = tab menu (rename...), recently used pages stay alive
  (Settings > Orbit speed), loading bar, file upload (Android file picker) on every site, rounded buttons.
- Deleting an alias in Alias Manager also removes its Orbit profile (tab, link, cookies/site data).

Step 11 additions (NOT build-verified, not run on a device)
-----------------------------------------------------------
- Per-AI timers (hours per AI in Alias Manager > Settings), first-chat detection for every AI, email autofill on every AI login page.
- Cookie detection: exact / "name*" rules + URL-based login for DeepSeek; Orbit > ⋯ > "Show cookie names (debug)".
- Google sign-in blocked help (no user-agent spoofing), downloads (DownloadManager + blob), camera upload (FileProvider cache).
- App lock (phone screen lock), backup via Android file screens (Google Drive), paste-many import, home-screen widget.
- native_patch.py also installs: OrbitWidgetProvider + widget resources (native/res/), FileProvider cache-path check.

STEP 12a - DOWNLOAD FOLDERS PER ACCOUNT + AI
Files downloaded inside Orbit (normal links, blob/data files, Gmail attachments) are saved in:
  Downloads/Orbit/<profile name>/<AI name>/      e.g. Downloads/Orbit/Account 1/Claude/
  Gmail attachments: Downloads/Orbit/Gmail/
The AI is taken from the website that is open when you tap download (unknown site = "Other").
If you rename a profile, new downloads go to the new folder name (old files stay where they are).
Android 9 and older: same folders, but inside the app's own Downloads folder.

STEP 12b - PROJECT FOLDERS
Orbit > ⋯ > "Download project folder…" (open an AI site first). Per account + AI you can:
  - choose "No project" (files go to Orbit/<profile>/<AI>/)
  - make a "＋ New project…" (e.g. "Website") -> files go to Orbit/<profile>/<AI>/Website/ until you change it
  - "Remove a project from the list…" (only the list; the files stay on the phone)
The folder is created by the first download. Projects are saved per profile key, so renaming a profile keeps them.
Orbit backup (Settings > Save) now also contains the project lists.

STEP 12c - DOWNLOADED FILES (simple file manager, view only)
Orbit > ⋯ > "Downloaded files (dates)…" shows Downloads/Orbit as folders: Account -> AI -> Project -> files.
Folders show file count, total size and the latest update; files show date + time and size.
Newest first. "● NEW" = changed in the last 24 hours. Tap a file for details, tap a folder to open it, "⬆ .. (up)" goes back, Refresh reloads.
Delete / rename come in the next step (12d).

STEP 12d - DELETE + RENAME (in ⋯ > Downloaded files)
  - Tap a file: Back / Rename / Delete (rename has no extension warning).
  - Long-press a folder: Rename folder / Delete folder… (shows how many files and the total size before deleting).
  - "Delete…" button in the list: tick many files/folders, then "Delete selected" (confirm first).
  - Renaming a project folder (Account/AI/Project) also updates the project list, so new downloads keep going to it.
  - Renaming an Account or AI folder does NOT rename the profile: the next download creates the original folder name again.
  - Android 10+: Orbit can only delete/rename files it created; other files give "not allowed". Empty folders may stay invisible on disk.

STEP 12e - CUSTOM DOWNLOAD FOLDER (per account + AI)
Orbit > ⋯ > "Custom download folder…" (open an AI site first). Pick any folder with Android's folder picker (phone, SD card, Google Drive folder...).
From then on that account's downloads of that AI go into the picked folder (inside a project sub-folder if a project is active).
"Use the default" goes back to Downloads/Orbit/<profile>/<AI>.
Notes:
  - Link downloads into a picked folder are done by Orbit itself (not Android's DownloadManager): no download notification, only toasts; max 500 MB.
  - If Android loses the folder permission, Orbit falls back to Downloads/Orbit and shows a message.
  - "Downloaded files (dates)" only lists Downloads/Orbit, not your custom folders.
  - Custom folders are not part of the Orbit backup (Android permissions cannot be restored); choose them again after a reinstall.
