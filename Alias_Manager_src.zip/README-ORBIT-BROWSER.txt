ORBIT MULTI-PROFILE BROWSER (ANDROID)
====================================

What this adds
--------------
- A new Orbit Browser launcher in the existing Alias Manager UI.
- A native Android browser screen that stays inside the app.
- Named profiles using AndroidX WebKit's MULTI_PROFILE feature.
- Each profile gets separate WebView cookies/site data; only one WebView is active at a time.
- Profile names and selected profile are stored locally. Chat history is not copied into Alias Manager.
- If the installed Android System WebView does not support MULTI_PROFILE, the browser refuses to load a shared-session fallback, to avoid mixing account sessions.

Build behavior
--------------
The repository creates the Android project during GitHub Actions. After `npx cap sync android`,
`native_patch.py` installs the Java plugin/activity (native/java/), adds the AndroidX WebKit dependency, registers
the plugin, and declares the Activity.

How to build
------------
1. Commit/push this ZIP's project files to your repository.
2. Run the existing Compile Android APK GitHub Actions workflow.
3. Download and install the resulting debug APK.
4. Open Alias Manager > Orbit Browser.
5. Add a profile, sign into the official Claude website, then switch profiles to test isolation.

Important compatibility notes
-----------------------------
- This is a native integration, not an HTML-only simulation.
- Multi-profile support depends on the Android System WebView provider/version on the device.
  The app checks support at runtime. Update Android System WebView from the Play Store if needed.
- Claude may restrict sign-in or some functionality in embedded WebViews. This implementation does not
  disable those protections or guarantee compatibility. If Claude refuses the embedded environment,
  use its official supported browser/app instead.
- This is for organizing separate accounts, not bypassing Claude plan limits or service restrictions.
- Inactive WebViews are destroyed on profile switch to reduce RAM; each profile's website data persists.
  The page itself reloads when you switch back, so unsaved page state may be lost.
- Profile removal/data-wipe UI is intentionally not included yet to avoid accidental deletion of login data.

Implementation used: JAVA only (native/java/). The old Kotlin copy was removed because the generated
Capacitor project is Java-only and does not compile .kt files (this caused the OrbitBrowserPlugin
"cannot find symbol" build error).
native_patch.py is idempotent and checks, before Gradle runs, that the plugin sits in the same
folder/package as MainActivity, is registered once, and that the manifest/gradle are patched once.
After the build, the workflow also checks that the APK really contains the latest index.html and the
Orbit classes.
Status: NOT build-verified (Step 11 adds downloads, camera, app lock, widget, per-AI timers). Run the workflow.

Ready notifications
-------------------
OrbitReminderReceiver.java schedules an Android alarm for when each running 5h timer ends and shows a
"Ready" notification. Needs the notification permission on Android 13+ (the app asks). Alarms are inexact
(may be a few minutes late). After a phone reboot they are re-created automatically (BOOT_COMPLETED);
reminders that finished while the phone was off are shown right after boot.
Turn off with Settings > Ready alerts.

Profile management (⋯ button in Orbit)
--------------------------------------
Rename, emoji, color, and Delete (with a confirmation dialog). Renaming only changes the label: each
profile keeps a fixed internal WebView key, so the login is kept. Delete erases that profile's cookies and
site data on this phone (not the Claude account or chats) and removes its alias link. The last profile can't
be deleted. If the data can't be erased, the profile is kept and an error is shown.

Auto-start toggle
-----------------
Alias Manager > Settings > "Orbit auto-start timer" (On/Off). When Off, Orbit still remembers chats it sees
but does not start any timer (the toolbar shows "auto-start OFF"). Use "▶ Start" manually.


Step 8 additions
- Alias list: Alias Manager keeps a saved copy for Orbit (syncAliases), so the 🔗 Alias menu always has your emails.
- ✉ button: Gmail in its own isolated profile. claude.ai links tapped in Gmail open in the active Claude profile.
  Google may refuse sign-in inside an embedded WebView; this app does not try to disguise itself.
- claude.ai/login: the linked alias is filled into the email box (you tap Continue).
- Compact toolbar; ⋯ > Hide address bar for even more room.
- Delete profile: removed at once; its data is erased with retries, or at the next Orbit start.
- Chat detected with no alias linked: asks which alias, then starts that alias timer.
- 🌐 Open only appears for aliases that are logged in (or were started before).

Step 9 additions
----------------
- Tab labels: a profile still named "Account N" shows its linked alias (note, or the part before @). A profile you
  renamed keeps your name.
- ⋯ > "Sign out (keep this tab)": erases that profile's cookies/site data only; the tab, alias link and color stay.
  The alias's 🌐 Open button is hidden until you log in again.
- Limit detection (user-requested; follows Settings > Orbit auto-start): every 10 s, while the Claude page you are
  looking at is open on a profile with a linked alias, Orbit checks the page text for a "you've reached your limit"
  line. Only that one line (max 300 chars) is looked at; nothing else is read or stored. If a reset time can be read
  ("in 2 hours 10 minutes" / "at 3:30 PM", within the next 5 h) the alias becomes Running and Ready exactly then,
  with a notification; otherwise it is marked Running from now. A chat that merely TALKS about usage limits could
  trigger it by mistake - use ↺ Reset on the card if that happens.
- Backup: Settings > Export now writes {aliases, orbit}. orbit = profiles, which alias each profile uses, colors,
  emoji, WebView keys. Import restores them too (old plain-list backups still import). Logins/cookies are NOT in
  the backup - after a reinstall you sign in again, but the links come back.

Step 10 additions
-----------------
- Alias Manager redesign: new logo/theme (Galaxy, AMOLED, Light), cards with an AI checklist, no Start/Reset buttons
  (the timer is automatic; "Start now" / "Clear timer" are inside Edit). Name/label of an alias = Orbit tab name.
- Many AIs per alias: Claude, ChatGPT, Gemini, Grok, Perplexity, DeepSeek, Le Chat (list = AI_PROVIDERS in
  www/index.html; letter badges, no brand logos). A chip shows ✓ when Orbit finds that site's sign-in cookie NAME in the
  alias's profile (values are never read). Sites without a known cookie: long-press the chip to mark it yourself.
  Tapping a chip opens that AI in Orbit for that alias (a new isolated profile is created if the alias has none).
  The 5h timer / limit detection stay Claude-only.
- Orbit: AI chip row + "Switch AI…", long-press a tab = tab menu (rename...), recently used pages stay alive
  (Settings > Orbit speed), loading bar, file upload (Android file picker) on every site, rounded buttons.
- Deleting an alias in Alias Manager also removes its Orbit profile (tab, link, cookies/site data).

Step 11 additions (NOT build-verified, not run on a device)
-----------------------------------------------------------
- Per-AI timers (hours per AI in Alias Manager > Settings), first-chat detection for every AI, email autofill on every AI login page.
- Cookie detection: exact / "name*" rules + URL-based login for DeepSeek; Orbit > ⋯ > "Show cookie names (debug)".
- Google sign-in blocked help (no user-agent spoofing), downloads (DownloadManager + blob), camera upload (FileProvider cache).
- App lock (phone screen lock), backup via Android file screens (Google Drive), paste-many import, home-screen widget.
- native_patch.py also installs: OrbitWidgetProvider + widget resources (native/res/), FileProvider cache-path check.

STEP 12a - DOWNLOAD FOLDERS PER ACCOUNT + AI
Files downloaded inside Orbit (normal links, blob/data files, Gmail attachments) are saved in:
  Downloads/Orbit/<profile name>/<AI name>/      e.g. Downloads/Orbit/Account 1/Claude/
  Gmail attachments: Downloads/Orbit/Gmail/
The AI is taken from the website that is open when you tap download (unknown site = "Other").
If you rename a profile, new downloads go to the new folder name (old files stay where they are).
Android 9 and older: same folders, but inside the app's own Downloads folder.

STEP 12b - PROJECT FOLDERS
Orbit > ⋯ > "Download project folder…" (open an AI site first). Per account + AI you can:
  - choose "No project" (files go to Orbit/<profile>/<AI>/)
  - make a "＋ New project…" (e.g. "Website") -> files go to Orbit/<profile>/<AI>/Website/ until you change it
  - "Remove a project from the list…" (only the list; the files stay on the phone)
The folder is created by the first download. Projects are saved per profile key, so renaming a profile keeps them.
Orbit backup (Settings > Save) now also contains the project lists.

STEP 12c - DOWNLOADED FILES (simple file manager, view only)
Orbit > ⋯ > "Downloaded files (dates)…" shows Downloads/Orbit as folders: Account -> AI -> Project -> files.
Folders show file count, total size and the latest update; files show date + time and size.
Newest first. "● NEW" = changed in the last 24 hours. Tap a file for details, tap a folder to open it, "⬆ .. (up)" goes back, Refresh reloads.
Delete / rename come in the next step (12d).

STEP 12d - DELETE + RENAME (in ⋯ > Downloaded files)
  - Tap a file: Back / Rename / Delete (rename has no extension warning).
  - Long-press a folder: Rename folder / Delete folder… (shows how many files and the total size before deleting).
  - "Delete…" button in the list: tick many files/folders, then "Delete selected" (confirm first).
  - Renaming a project folder (Account/AI/Project) also updates the project list, so new downloads keep going to it.
  - Renaming an Account or AI folder does NOT rename the profile: the next download creates the original folder name again.
  - Android 10+: Orbit can only delete/rename files it created; other files give "not allowed". Empty folders may stay invisible on disk.

STEP 12e - CUSTOM DOWNLOAD FOLDER (per account + AI)
Orbit > ⋯ > "Custom download folder…" (open an AI site first). Pick any folder with Android's folder picker (phone, SD card, Google Drive folder...).
From then on that account's downloads of that AI go into the picked folder (inside a project sub-folder if a project is active).
"Use the default" goes back to Downloads/Orbit/<profile>/<AI>.
Notes:
  - Link downloads into a picked folder are done by Orbit itself (not Android's DownloadManager): no download notification, only toasts; max 500 MB.
  - If Android loses the folder permission, Orbit falls back to Downloads/Orbit and shows a message.
  - "Downloaded files (dates)" only lists Downloads/Orbit, not your custom folders.
  - Custom folders are not part of the Orbit backup (Android permissions cannot be restored); choose them again after a reinstall.

ORBIT BROWSER SCREEN (Step 13c)
- Top bar (one slim row): ☰ drawer | account name + alias/timer line | ✉ Gmail | current AI icon (tap = switch AI) | ⋯ menu.
- ☰ drawer: Accounts (tap = switch, long-press = account menu, ＋ New account, 🔗 Link alias), AI services (icon + signed-in mark), Tools (Gmail, Menu, Close Orbit). Back closes the drawer first.
- ⋯ menu (bottom sheet, grouped): Switch AI · Account (rename, reset name, emoji, color, link alias, delete) · Downloads (project folder, custom folder, downloaded files) · Security (sign out, Google sign-in help) · Advanced (address bar, AI chips bar, cookie names, Close Orbit).
- The AI chips bar is hidden by default; turn it on in ⋯ > Advanced > AI chips bar.
- Dialogs use the dark violet style OrbitDialog (native/res/values/orbit_styles.xml). Colors live in ONE palette block (C_BG, C_BAR, C_SURFACE, C_TEXT, C_MUTED, C_OK, C_DANGER, C_CYAN, PURPLE) at the top of OrbitBrowserActivity.java.
- Syntax check without Android SDK: java tools/ParseJava.java native/java/*.java  (parse only, finds syntax errors, not type errors).

BACKGROUND (Step 13e)
- Picture-in-picture: ⋯ > Background > Picture-in-picture now (or the drawer). Orbit becomes a small floating window (top bar and address bar hidden). "Auto picture-in-picture when I leave" does it when you press Home (not when Orbit itself opens the file picker, camera or settings).
- Keep alive in background: ON = foreground service OrbitKeepAliveService with a notification (Stop button) + partial wake lock (max 3 h, renewed when Orbit is opened). While ON, pages of other accounts are not paused when you switch account. Turns itself off when you close Orbit (✕ / swipe away); the setting is remembered and starts again next time.
- Battery and background help popup: shows if Orbit is "unrestricted", button "Allow background use" (Android's own box, cannot be styled), shortcut to battery settings, brand Autostart screens (Xiaomi, Oppo/Realme, Vivo, Huawei, Samsung, Tecno/Infinix) with a hint text.
- Limits: some phones still close apps; nothing guarantees an AI finishes a reply if the connection drops.
- native_patch.py adds permissions FOREGROUND_SERVICE, FOREGROUND_SERVICE_SPECIAL_USE, WAKE_LOCK, REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, the <service> (specialUse), and supportsPictureInPicture + extra configChanges on the Activity.


=====================================================================
REDESIGN BATCH 1 - BRAND FOUNDATION (approved Orbit logo + design tokens)
=====================================================================
Logo: tools/brand/Orbit_Icon_Master_1536.png is the ONE approved artwork. Every icon/splash file is generated from it by
  python3 tools/make_brand_assets.py        (never cropped/stretched/recoloured; sized by the circle that encloses the mark)
  python3 tools/check_brand_assets.py       (measures: sizes, pure-black bg, mask clipping, maskable safe zone, manifest refs)
Android launcher = our own adaptive icon (native/res/mipmap-anydpi-v26/orbit_launcher.xml): pure black background layer
  (drawable/orbit_icon_bg.xml) + transparent foreground (drawable-nodpi/orbit_icon_fg.png, 648 px = 6 px/dp, mark core radius
  34 dp of the 108 dp canvas: safe zone is 33, visible circle 36). native_patch.py installs them; the manifest points to them.
PWA: www/icon-192/512.png ("any" = full artwork), www/icon-maskable-192/512.png ("maskable" = mark inside the 40% safe circle),
  www/logo-192.png (in-app header tile). sw.js cache is orbit-v3-6.
Design tokens: the first CSS block in www/index.html (colours, spacing 4px grid, radius, type, icon sizes, motion). Change values
  there, not in rules. Themes: Ink (default), body.amoled, body.light. The Java twin is the palette block at the top of
  OrbitBrowserActivity.java (C_BG, C_BAR, ..., C_ACCENT; PURPLE was renamed C_ACCENT, label "Purple" -> "Indigo").
Icons: inline SVG sprite from Orbit Icon Pack V3 (103 symbols, one colour via currentColor; class .ic-duo opts in to a cyan
  accent). Rebuild with tools/build_icon_sprite.py <pack>/SVG. Old ids (plus, search, check, gear, open, copy, star, ...) kept.
Checks: bash tools/run_all_checks.sh   (needs node, python3 + Pillow/numpy/playwright, java; no Android SDK, no network).


=====================================================================
REDESIGN BATCH 2 - MAIN DASHBOARD (www/index.html)
=====================================================================
Layout (top to bottom): brand bar (logo, "Orbit", summary line, Settings) | Orbit Browser card (Next / Open) | install banner (only when the browser
offers it) | summary tiles (Aliases / Running / Ready / Not started: TAP = same as the matching filter) | Accounts header (count, Select, Add alias)
| search (with clear) + sort | filter chips with live counts (All, Running, Ready, Pinned, Not started, Needs connect) | list.
Card: avatar + label + email (copy button) + pin mark | provider chips (connected = check icon, not connected = dimmed) | ONE status badge with icon and
word (Running + time left / Ready / Not started / Needs sign-in, plus Limit) | progress bar while running | tags | "Added ... / Last starts ..." |
actions: Open (or Sign in when no AI is connected yet) + Pin + Edit + Delete (all with names for screen readers).
Select mode: tap anywhere on a card to select it (per-card buttons are inert meanwhile); the action bar stays at the top while scrolling.
Empty states: first launch (guided, hides summary/search/filters) and no results (names the search and the filter, one Reset button).
Dashboard compact mode: Settings > "Dashboard compact mode" (key compactDash, default off). Tightens spacing only; every control stays >= 40 px.
  It is NOT the native Orbit Browser's own compact setting.
CSS: ONE dashboard layer (section 4). The old Step 13b override stack (section 12) is gone. Spacing: --d-gap / --d-pad / --d-card-gap.
Tests: python3 tools/ui_smoke.py (now 150+ checks: layout at 320/360/412/tablet/200% text, touch targets, focus ring, accessible names, bridge payloads).


=====================================================================
REDESIGN BATCH 3 - FORMS, SETTINGS AND FEEDBACK (www/index.html)
=====================================================================
ONE sheet shell for Add/Edit alias, Paste many, Timer hours, Settings, Confirm and Install help (section 10 of the CSS).
  Always open/close with openSheet(el, focusEl, closer) / closeSheet(el). That gives: focus moves into the sheet and back to the opener, Tab wraps inside it,
  Escape / the X button / a tap on the backdrop / the phone's Back button all close the top sheet, and everything behind it is inert.
  The Back button works through ONE history entry that exists only while a sheet is open (sheetsChanged()).
Add / Edit: visible labels, email keyboard, inline errors under the field (empty, not an email, already saved - also when editing), "pick at least one AI",
  no double submit, Enter = next field (last field saves), AI picker = toggle buttons with aria-pressed, colour = radio group with names.
  An old record whose address is not a valid email can still be edited (the format is checked only when the address is changed).
Paste many: live summary ("2 new - 1 already saved - 3 ignored"), the button says how many it will add.
Settings: 6 sections (Appearance, Timers & alerts, Orbit Browser, Privacy & security, Backup & restore, App & help); every control has a label and a one-line help.
Confirmations are in-app (confirmSheetAsk): single delete, bulk delete, and RESTORE (it replaces the list; skipped when the app is empty). The phone's confirm()/alert() are gone.
Toasts: toast(msg, type) type = success | error | warn | ready | (none). role=status. Errors stay at least 4.5 s. No Unicode glyph icons.
Lock screen: labelled dialog, Unlock gets focus, Tab cannot leave it, failed unlock shows an error line.
Tests: python3 tools/ui_sheets.py (100 checks) and python3 tools/ui_smoke.py (162). Full suite: bash tools/run_all_checks.sh [dir] [all|static|ui]


=====================================================================
REDESIGN BATCH 4a - NATIVE ORBIT BROWSER: ICONS, SIZES, MENUS (OrbitBrowserActivity.java + native/res)
=====================================================================
Icons: 36 vector drawables native/res/drawable/orbit_ic_*.xml (Orbit Icon Pack V3 style + 5 custom) replace the emoji/Unicode glyphs in the top bar, address row, drawer and menu rows.
  Generate: python3 tools/make_native_icons.py <pack>/SVG.  Java side: GLYPH_ICONS table + iconButton()/glyphView()/smallIcon(); a glyph that has no icon (or a missing file) keeps its text
  glyph, so no button can ever be blank. Icons are found with getIdentifier("orbit_ic_<name>"): if a RELEASE build ever turns on resource shrinking, add a res/raw keep rule for @drawable/orbit_ic_*.
Sizes: top bar 52 dp with 44 dp buttons, address row 40 dp with 44 dp buttons, drawer rows 48 dp, text >= 12 sp, section labels upper-case with letter spacing (like the dashboard).
Account menu (manageProfile): Delete profile is now alone in a "Danger zone" group at the bottom; Close Orbit has its own "Orbit" group. Same actions, same confirmations.
Java checks without the Android SDK: java tools/JavaSymbolGate.java --check tools/java_symbols.baseline native/java/*.java  (fails on any non-resolution compile error and lists every NEW unresolved
  symbol so a typo in our own names, or a first-time Android API, is reviewed). After checking new symbols by hand: --record. It CANNOT see wrong calls on Android objects.


=====================================================================
REDESIGN BATCH 4b + TEXT PASS (web + native wording, no logic changes)
=====================================================================
Terminology now used everywhere: "alias" = a saved email alias; "account" = what you switch between in Orbit Browser; "sign-in" / "sign in" (never "login" / "logged in");
"Bulk add" (was "Paste many"); "Needs sign-in" (was "Needs connect"); "Timer length per AI" (was "Timer hours per AI"); "Automatic timers" (was "AI auto timer");
"Browser performance: Balanced / Low memory / Fastest" (was "Orbit speed: Fast / Save memory / Fastest", same stored values); "Background notification" (was "keep-alive").
Native status line uses plain words and a quiet middle dot ("Claude · Ready", "· 3h 20m left", "· Automatic timer off") instead of bullet/check/stopwatch symbols. The Gmail title is just "Gmail".
Account menu wording: Rename account, Reset name to the alias, Link an alias, Sign out of this account, Downloaded files, Picture-in-picture, Keep running in background, AI shortcuts bar.
Full old -> new list: TEXT_CHANGES.txt (delivered next to the zip). Ids, option values, storage keys and plugin calls were NOT changed.


=====================================================================
REDESIGN BATCH 4c - NATIVE DOWNLOADS / FILES SCREENS (UI only; no storage logic touched)
=====================================================================
rowLine(glyph, title, subtitle, isNew, iconColor) builds a one- or two-line list row with a leading vector icon (ImageSpan) and a muted second line; "New · " is green. If an icon is missing the old
text glyph is shown. Used by: Orbit files screen (parent folder, folders in cyan, files, empty state "No files yet"), multi-select delete list, and the download-project chooser (icons, "In use", no more
check-mark/space markers). File details say "Location" and "New: downloaded in the last 24 hours"; the delete confirmation says the files are removed from the phone. The folder menu title is the plain name.
Unchanged on purpose: queryFiles, MediaStore/tree-URI/permission code, handleDownload, saveToDownloads, downloadToCustom, pickCustomDir.
tools/JavaSymbolGate.java now also keys every FULLY-QUALIFIED Android name ("uses: android.text.style.ImageSpan"), so a first-time android.x.Y is listed even when package android.x was used before.

Batch 4d / 5 notes (latest)
- File upload: Orbit shows its own picker (several files allowed; photos/videos/audio filtered, everything else unfiltered) and COPIES each picked file into cache/orbit_up/ (deleted after 12 hours) so the AI site always gets a readable file with its real name. Files over 300 MB are passed through uncopied. Reported working by the user for several files and for a zip.
- Notifications (Ready + Background) use the Orbit glyph (res/drawable/orbit_ic_notif.xml) with accent #524FFF; the widget header uses the same glyph.
- Dashboard side spacing was tightened (page margin 8 px, card side padding 12 px; Compact mode 10 px).
- build.yml now also proves orbit_ic_notif.xml and orbit_widget.xml are in the Android project. sw.js cache is orbit-v3-6.

Batch 6 notes (latest)
- Claude Incognito chats are now detected (page watcher every 2.5 s; address bar does not change in Incognito).
- Plain "Open" returns to the AI the account used last; Home button (house icon) = back to Alias Manager.
- Scheduled message (prototype, Claude only): OrbitScheduleReceiver + OrbitBrowserActivity (AUTO_JS). Manifest adds a receiver and SCHEDULE_EXACT_ALARM + SYSTEM_ALERT_WINDOW. Test page scripts with: python3 tools/test_autosend_js.py

Batch 7 notes (latest)
- Scheduled message sends in the background (OrbitSendService, hidden browser, isolated profile). Fallback: visible Orbit + notification. Manifest: service (specialUse) + receiver + SCHEDULE_EXACT_ALARM + SYSTEM_ALERT_WINDOW.
- Every AI's timer length (Claude too) is editable in Alias Manager > Settings. Default 5 hours.
- Bottom sheets close by pulling the grab bar down or tapping outside.

Batch 8: scheduled-message alarms carry their time and stale ones are ignored; "Wait if RAM is low" tile; rules tested by java tools/ScheduleMathTest.java
