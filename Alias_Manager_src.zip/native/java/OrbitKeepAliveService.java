package __PACKAGE__;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/**
 * Step 13e: while "Keep alive in background" is On, Orbit runs as a foreground service (with a notification)
 * so Android is less likely to stop the process while an AI is still writing a reply and you are in another app.
 * It also holds a partial wake lock (max 3 h, renewed every time Orbit is opened). It does NOT guarantee anything on every phone.
 */
public class OrbitKeepAliveService extends Service {
    static final String CHANNEL = "orbit_keepalive";
    static final int NOTIF_ID = 7741;
    static final String ACTION_STOP = "orbit.keepalive.STOP";
    private PowerManager.WakeLock wakeLock;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            getSharedPreferences("orbit_profiles", Context.MODE_PRIVATE).edit().putBoolean("keep_alive", false).apply();
            releaseWakeLock();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        Notification n = buildNotification();
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(NOTIF_ID, n);
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            if (wakeLock == null) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "orbit:keepalive");
                wakeLock.setReferenceCounted(false);
            }
            wakeLock.acquire(3L * 60L * 60L * 1000L);
        } catch (Exception ignored) { }
        return START_NOT_STICKY; // if the phone kills the process, the web pages are gone anyway: do not restart empty
    }

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Background running", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(this, OrbitBrowserActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, OrbitKeepAliveService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        int small = getResources().getIdentifier("orbit_ic_notif", "drawable", getPackageName());
        b.setSmallIcon(small != 0 ? small : android.R.drawable.stat_notify_sync)
            .setColor(0xFF524FFF)
            .setContentTitle("Orbit is running in the background")
            .setContentText("Tap to open Orbit. Tap Stop when you no longer need it.")
            .setContentIntent(openPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPi);
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        return b.build();
    }

    private void releaseWakeLock() {
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) { }
    }

    @Override public void onDestroy() { releaseWakeLock(); super.onDestroy(); }
}
