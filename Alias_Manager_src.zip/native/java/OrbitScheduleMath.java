package __PACKAGE__;

/**
 * Pure time rules of the scheduled message (no Android classes, so tools/ScheduleMathTest.java can run them on a computer).
 */
final class OrbitScheduleMath {
    private OrbitScheduleMath() { }

    /** The next time of day hh:mm that is not before minMs. */
    static long nextTimeOfDay(int hour, int minute, long minMs) {
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.setTimeInMillis(minMs);
        c.set(java.util.Calendar.HOUR_OF_DAY, hour); c.set(java.util.Calendar.MINUTE, minute); c.set(java.util.Calendar.SECOND, 0); c.set(java.util.Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() < minMs) c.add(java.util.Calendar.DAY_OF_YEAR, 1);
        return c.getTimeInMillis();
    }

    /**
     * Should an alarm run the message now?
     * on          = the schedule is switched on
     * armedAt     = the time the alarm was set for (0 = an alarm from an older version that did not carry it)
     * scheduledAt = the time the schedule currently says
     * An alarm that was set for another time than the schedule now says is a stale one and is ignored; so is one that fires hours late.
     */
    static boolean shouldRun(boolean on, long armedAt, long scheduledAt, long now) {
        if (!on || scheduledAt <= 0) return false;
        if (armedAt != 0 && armedAt != scheduledAt) return false;
        return now >= scheduledAt - 5000L && now - scheduledAt < 6L * 60 * 60 * 1000;
    }

    /** 0 = same calendar day as now, 1 = the next day, 2 = later. */
    static int dayOffset(long at, long now) {
        java.util.Calendar a = java.util.Calendar.getInstance(), n = java.util.Calendar.getInstance();
        a.setTimeInMillis(at); n.setTimeInMillis(now);
        a.set(java.util.Calendar.HOUR_OF_DAY, 0); a.set(java.util.Calendar.MINUTE, 0); a.set(java.util.Calendar.SECOND, 0); a.set(java.util.Calendar.MILLISECOND, 0);
        n.set(java.util.Calendar.HOUR_OF_DAY, 0); n.set(java.util.Calendar.MINUTE, 0); n.set(java.util.Calendar.SECOND, 0); n.set(java.util.Calendar.MILLISECOND, 0);
        long days = Math.round((a.getTimeInMillis() - n.getTimeInMillis()) / 86400000.0);
        return days <= 0 ? 0 : (days == 1 ? 1 : 2);
    }

    static final int MAX_RETRIES = 10;
    static final long RETRY_MS = 60000L;
    /** After this many low-memory checks, is another one allowed? (10 checks, one per minute) */
    static boolean canRetry(int attemptsDone) { return attemptsDone >= 0 && attemptsDone < MAX_RETRIES; }

    private static final java.util.regex.Pattern RESET_REL = java.util.regex.Pattern.compile("(?i)\\bin\\s+(?:(\\d+)\\s*(?:hours?|hrs?|h)\\b)?\\s*(?:and\\s*)?(?:(\\d+)\\s*(?:minutes?|mins?|m)\\b)?");
    private static final java.util.regex.Pattern RESET_CLOCK = java.util.regex.Pattern.compile("(?i)\\b(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)\\b");
    /**
     * When does the limit return? Reads "in 2 hours 10 minutes" or a clock time such as "until 6:00 PM" / "returns at 6 PM" from the AI's own message.
     * A clock time that already passed today means tomorrow. 0 = unknown, or further away than the timer length (+30 minutes).
     */
    static long parseReset(String text, long now, long windowMs) {
        try {
            long at = 0;
            java.util.regex.Matcher r = RESET_REL.matcher(text);
            while (r.find()) {
                if (r.group(1) == null && r.group(2) == null) continue;
                long h = r.group(1) == null ? 0 : Long.parseLong(r.group(1)), mi = r.group(2) == null ? 0 : Long.parseLong(r.group(2));
                at = now + (h * 60 + mi) * 60000L; break;
            }
            if (at == 0) {
                java.util.regex.Matcher c = RESET_CLOCK.matcher(text);
                if (c.find()) {
                    int hh = Integer.parseInt(c.group(1)) % 12, mm = c.group(2) == null ? 0 : Integer.parseInt(c.group(2));
                    if (c.group(3).equalsIgnoreCase("pm")) hh += 12;
                    java.util.Calendar cal = java.util.Calendar.getInstance();
                    cal.setTimeInMillis(now);
                    cal.set(java.util.Calendar.HOUR_OF_DAY, hh); cal.set(java.util.Calendar.MINUTE, mm); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0);
                    if (cal.getTimeInMillis() <= now) cal.add(java.util.Calendar.DAY_OF_YEAR, 1);
                    at = cal.getTimeInMillis();
                }
            }
            if (at <= now || at - now > windowMs + 30 * 60000L) return 0;
            return at;
        } catch (Exception e) { return 0; } // e.g. absurdly long numbers in the page text
    }

    /** Enough free memory to start the hidden browser (about 300 MB, and Android must not report low memory). */
    static boolean ramOk(long availBytes, boolean lowMemory) { return !lowMemory && availBytes >= 300L * 1024 * 1024; }
}
