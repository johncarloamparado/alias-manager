package __PACKAGE__;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.KeyguardManager;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.webkit.ValueCallback;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.Gravity;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.webkit.ProfileStore;
import androidx.webkit.WebViewCompat;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import androidx.webkit.WebViewFeature;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class OrbitBrowserActivity extends Activity {
    private android.content.SharedPreferences prefs;
    private final List<String> profileNames = new ArrayList<>();
    private String activeProfile = "Account 1";
    private WebView webView;
    private LinearLayout root, tabs;
    private FrameLayout shell; private View scrim; private LinearLayout drawerPanel, drawerBody, sheetRoot;
    private boolean drawerOpen = false, showChips = false; private int drawerW;
    private TextView titleView; private android.widget.ImageView aiBtn; private android.app.Dialog sheetDlg;
    private boolean keepAliveOn = false, pipAuto = false, inPip = false; private View topBar; private long internalLaunchAt = 0;
    private EditText address;
    private TextView status;
    private FrameLayout webHost;
    private boolean profileSupported;
    // ---- first-chat detection (URL only; page contents are never read) ----
    static final Object LOCK = new Object();
    private static final Pattern CHAT_URL = Pattern.compile("^https://claude\\.ai/chat/([0-9a-fA-F-]{36})");
    private static final Pattern NEW_CHAT_PAGE = Pattern.compile("^https://claude\\.ai(/new|/|/project/[^/?#]+)?/?([?#].*)?$");
    private final Map<String, String> lastUrls = new HashMap<>(); // profile key -> last URL (for first-chat detection)
    private boolean autoStart = true; // Alias Manager setting "Orbit auto-start timer"
    // ---- profile identity: a profile's WebView data key never changes, even when it is renamed ----
    private JSONObject keys = new JSONObject();    // displayName -> webview profile key (absent = legacy key from name)
    private JSONObject styles = new JSONObject();  // displayName -> {emoji, color}
    // ---- Orbit palette (Batch 1 brand foundation; mirrors the CSS tokens in www/index.html). Use these, not raw Color.rgb(...) ----
    // Web token -> Java constant:  --bg C_BG | --surface C_BAR | --surface2 C_FIELD/C_SURFACE | --surface3 C_SURFACE2 | --text C_TEXT | --text-muted C_MUTED
    private static final int C_BG = Color.rgb(5, 6, 11);          // window / status bar / navigation bar (#05060B)
    private static final int C_BAR = Color.rgb(13, 18, 32);       // top bar, drawer, sheets (#0D1220)
    private static final int C_BAR2 = Color.rgb(9, 14, 27);       // address row, AI chips bar (#090E1B)
    private static final int C_FIELD = Color.rgb(19, 27, 44);     // address field (#131B2C)
    private static final int C_SURFACE = Color.rgb(21, 30, 50);   // buttons, inactive chips (#151E32)
    private static final int C_SURFACE2 = Color.rgb(27, 40, 70);  // selected row (#1B2846)
    private static final int C_TEXT = Color.rgb(243, 245, 255);   // #F3F5FF
    private static final int C_MUTED = Color.rgb(154, 168, 191);  // #9AA8BF
    private static final int C_OK = Color.rgb(61, 220, 151);      // #3DDC97
    private static final int C_DANGER = Color.rgb(255, 107, 122); // #FF6B7A
    private static final int C_WARN = Color.rgb(245, 184, 75);    // #F5B84B
    private static final int C_CYAN = Color.rgb(18, 221, 244);    // brand cyan #12DDF4 (progress bar)
    private static final int C_ACCENT = Color.rgb(82, 79, 255);   // brand blue-violet #524FFF: active chip, mail button, default account color (white text = 5.3:1)
    private static final String[] COLOR_NAMES = {"Indigo", "Blue", "Green", "Orange", "Red", "Pink", "Teal", "Gray"};
    private static final int[] COLOR_VALUES = {C_ACCENT, Color.rgb(46,108,200), Color.rgb(36,140,90), Color.rgb(200,120,30),
            Color.rgb(190,60,60), Color.rgb(190,70,140), Color.rgb(30,140,150), Color.rgb(100,108,125)};
    private static final String[] EMOJIS = {"", "🟣", "🔵", "🟢", "🟠", "🔴", "⭐", "💼", "🏠", "🎮", "🧪"};
    // ---- toolbar timer: aliasId -> start time (ms). Same 5h rule as Alias Manager. ----
    private static final long FIVE_H = 5L * 60 * 60 * 1000;
    private final Map<String, Long> started = new HashMap<>();
    private String statusSuffix = "";
    private final Handler ticker = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() { @Override public void run() { refreshStatus(); ticker.postDelayed(this, 30000); } };
    // Aliases handed over by Alias Manager: {id, email}. Links are stored as profileName -> aliasId.
    private final List<String[]> aliases = new ArrayList<>();
    private JSONObject links = new JSONObject();
    // ---- Gmail view (own isolated profile, kept alive while you switch back to Claude) ----
    private static final String MAIL_KEY = "orbit_mail_inbox";
    private static final String MAIL_URL = "https://mail.google.com/";
    private static final Pattern LOGIN_URL = Pattern.compile("^https://claude\\.ai/(login|signup)");
    private WebView mailView;
    private boolean mailMode = false;
    private View mailBtn;
    private LinearLayout addressRow;
    private HorizontalScrollView tabScroll;
    private boolean compact = false;      // true = address bar + status line hidden (more room for the chat)
    private String aliasDebug = "";
    private static final Pattern LOGGED_IN_URL = Pattern.compile("^https://claude\\.ai/(new|chat/|recents|projects|settings|chats|code|artifacts)");
    private final Set<String> promptedLogin = new LinkedHashSet<>();
    private final Set<String> promptedChats = new LinkedHashSet<>();
    private final Set<String> loginSent = new LinkedHashSet<>();
    private String[] pendingChat = null; // {profile, chatId, provider}: chat seen on a profile with no alias yet
    private String[] pendingLink = null; // alias (id,email) Alias Manager asked for, with no profile linked yet
    private long lastFillAt = 0;
    private final Set<String> loginHinted = new LinkedHashSet<>();
    // ---- AI services (providers handed over by Alias Manager): {id, name, url, cookie-name prefixes (comma separated)} ----
    private final List<String[]> providers = new ArrayList<>();
    private HorizontalScrollView svcScroll;
    private LinearLayout svcRow;
    private String svcSig = "";
    private final Map<String, Set<String>> connectedByKey = new HashMap<>(); // profile key -> provider ids that have a sign-in cookie
    private final Map<String, String> servicesSent = new HashMap<>();
    private Runnable scanTask;
    private String startUrl = null;          // first page to load (e.g. ChatGPT when a chip was tapped in Alias Manager)
    private String wantService = "";
    private boolean createIfMissing = false; // chip tapped for an alias that has no profile yet: make one
    // ---- speed: recently used pages stay alive, so switching accounts does not reload them ----
    private final java.util.LinkedHashMap<String, WebView> views = new java.util.LinkedHashMap<>();
    private int keepLive = 2;
    private View progressBar;
    private ValueCallback<Uri[]> fileCb;      // file chooser (upload) callback
    private static final int REQ_FILE = 9021;
    private static final int REQ_TREE = 9023;
    private String treeKey = "", treePid = "";   // account + AI waiting for the folder picker
    private long loadedRev = 0;               // changes when Alias Manager removes aliases/profiles behind our back
    private java.io.File camFile; private Uri camUri; // photo taken for an upload
    private java.io.File lastCamFile; private Uri lastCamUri; // same photo, kept until the result is handled
    private final Set<String> googleWarned = new LinkedHashSet<>();
    // ---- app lock (Alias Manager > Settings > App lock): phone PIN / pattern / fingerprint when coming back after 30 s ----
    private static final int REQ_UNLOCK = 9022;
    private boolean locked = false, skipLockOnce = false;
    private View lockCover;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(C_BG);
        getWindow().setNavigationBarColor(C_BG);
        prefs = getSharedPreferences("orbit_profiles", Context.MODE_PRIVATE);
        profileSupported = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE);
        compact = prefs.getBoolean("compact", false);
        showChips = prefs.getBoolean("svc_chips", false);
        keepAliveOn = prefs.getBoolean("keep_alive", false); pipAuto = prefs.getBoolean("pip_auto", false);
        autoStart = getIntent().getBooleanExtra("autoStart", true);
        int kl = getIntent().getIntExtra("keepLive", 0); if (kl > 0) prefs.edit().putInt("keep_live", kl).apply();
        keepLive = Math.max(1, Math.min(3, prefs.getInt("keep_live", 2)));
        loadedRev = prefs.getLong("rev", 0);
        loadAliases(); loadProviders(); loadProfiles(); loadLinks(); loadMeta(); if (profileSupported) erasePendingNow(); applyRequestedAlias(); buildUi();
        if (profileSupported) showProfile(activeProfile); else showUnsupported();
        if (pendingLink != null) offerLink();
        checkLock();
        if (savedInstanceState == null) startAutoFromIntent();
    }
    private void loadProviders() {
        providers.clear();
        String raw = getIntent().getStringExtra("providers");
        if (raw == null || raw.length() < 3) raw = prefs.getString("providers_json", null);
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i); if (o == null) continue;
                String id = o.optString("id", "").trim(), url = o.optString("url", "").trim();
                if (id.isEmpty() || !url.startsWith("https://")) continue;
                providers.add(new String[]{id, o.optString("name", id), url, csv(o.optJSONArray("cookies")), csv(o.optJSONArray("hosts")),
                    o.optString("inPat", ""), o.optString("outPat", ""), o.optString("chat", ""), String.valueOf(o.optDouble("hours", 5)), o.optBoolean("fill", true) ? "1" : "0"});
            }
        } catch (Exception ignored) { }
        if (providers.isEmpty()) providers.add(new String[]{"claude", "Claude", "https://claude.ai/", "sessionKey", "claude.ai", "", "", "^https://claude\\.ai/chat/([0-9a-fA-F-]{36})", "5", "1"});
    }
    private static String csv(JSONArray a) {
        StringBuilder sb = new StringBuilder();
        if (a != null) for (int k = 0; k < a.length(); k++) { String v = a.optString(k, "").trim(); if (v.isEmpty()) continue; if (sb.length() > 0) sb.append(','); sb.append(v); }
        return sb.toString();
    }
    private String[] providerById(String id) { for (String[] p : providers) if (p[0].equals(id)) return p; return null; }
    private String providerName(String id) { String[] p = providerById(id); return p == null ? id : p[1]; }
    /** Timer window of an AI in ms (Claude too): Alias Manager > Settings > Timer length per AI. 5 hours when nothing was set. */
    private long windowMs(String pid) {
        String[] p = providerById(pid == null ? "claude" : pid);
        try { double h = p == null ? 5 : Double.parseDouble(p[8]); if (h > 0) return (long) (h * 3600000L); } catch (Exception ignored) { }
        return FIVE_H;
    }
    private static String timerKey(String aliasId, String pid) { return (pid == null || pid.equals("claude")) ? aliasId : aliasId + "|" + pid; }
    private String reminderLabel(String email, String pid) { return (pid == null || pid.equals("claude")) ? email : email + " · " + providerName(pid); }
    private String providerIdForUrl(String url) {
        if (url == null) return null;
        String h; try { h = Uri.parse(url).getHost(); } catch (Exception e) { return null; }
        if (h == null) return null;
        for (String[] p : providers) {
            String ph; try { ph = Uri.parse(p[2]).getHost(); } catch (Exception e) { continue; }
            if (ph == null) continue;
            if (ph.startsWith("www.")) ph = ph.substring(4);
            if (h.equals(ph) || h.endsWith("." + ph)) return p[0];
            if (!p[4].isEmpty()) for (String x : p[4].split(",")) { x = x.trim(); if (!x.isEmpty() && (h.equals(x) || h.endsWith("." + x))) return p[0]; }
        }
        return null;
    }
    private void loadProfiles() {
        String saved = prefs.getString("profiles", "Account 1");
        Set<String> unique = new LinkedHashSet<>();
        for (String s : saved.split("\\n")) if (!s.trim().isEmpty()) unique.add(s.trim());
        profileNames.clear(); profileNames.addAll(unique);
        if (profileNames.isEmpty()) profileNames.add("Account 1");
        activeProfile = prefs.getString("active", profileNames.get(0));
        if (!profileNames.contains(activeProfile)) activeProfile = profileNames.get(0);
    }
    private void loadAliases() {
        aliases.clear();
        int fromIntent = parseAliases(getIntent().getStringExtra("aliases"), aliases);
        int fromSaved = 0;
        if (fromIntent == 0) { // fall back to the copy Alias Manager keeps in sync
            fromSaved = parseAliases(prefs.getString("aliases_json", null), aliases);
        }
        aliasDebug = "(from open: " + fromIntent + ", saved copy: " + fromSaved + ")";
    }
    /** Adds valid {id,email} entries to out and returns how many. A missing id falls back to the email. */
    private int parseAliases(String raw, List<String[]> out) {
        int n = 0;
        if (raw == null) return 0;
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String email = o.optString("email", "").trim();
                String id = o.optString("id", "").trim();
                if (email.isEmpty()) continue;
                if (id.isEmpty()) id = email;
                out.add(new String[]{id, email, o.optString("note", "").trim()}); n++;
                long lu = o.optLong("lastUsed", 0);
                if (lu > 0) { Long old = started.get(id); if (old == null || lu > old) started.put(id, lu); }
                JSONObject tm = o.optJSONObject("timers"); // timers of the other AIs: {chatgpt: startMs, ...}
                if (tm != null) { java.util.Iterator<String> ti = tm.keys(); while (ti.hasNext()) { String pk = ti.next(); long tv = tm.optLong(pk, 0); if (tv <= 0) continue; String tk = timerKey(id, pk); Long old2 = started.get(tk); if (old2 == null || tv > old2) started.put(tk, tv); } }
            }
        } catch (Exception ignored) { }
        return n;
    }
    /** Re-read the saved alias list (Alias Manager updates it every time something changes). */
    private void reloadAliases() {
        List<String[]> fresh = new ArrayList<>();
        if (parseAliases(prefs.getString("aliases_json", null), fresh) > 0) { aliases.clear(); aliases.addAll(fresh); }
    }
    /** If Alias Manager asked for a specific alias, start on the profile linked to it (and on the AI it asked for). */
    private void applyRequestedAlias() {
        wantService = getIntent().getStringExtra("service"); if (wantService == null) wantService = "";
        createIfMissing = getIntent().getBooleanExtra("createIfMissing", false);
        String want = getIntent().getStringExtra("aliasId");
        if (want == null || want.isEmpty()) { setStartForService(); return; }
        String p = profileLinkedTo(want);
        if (p != null && profileNames.contains(p)) { activeProfile = p; saveProfiles(); setStartForService(); return; }
        if (createIfMissing && profileSupported) { createProfileFor(want); setStartForService(); return; }
        String email = "this alias";
        for (String[] a : aliases) if (a[0].equals(want)) email = a[1];
        pendingLink = new String[]{want, email}; // asked after the screen is built (offerLink)
    }
    private void setStartForService() {
        String want = wantService;
        if (want.isEmpty()) { // no AI was asked for (plain "Open"): go back to the AI this account used last
            String last = prefs.getString("lastpid:" + activeProfile, "");
            if (!last.isEmpty()) want = last;
        }
        if (want.isEmpty()) return;
        for (String[] pr : providers) if (pr[0].equals(want)) { startUrl = pr[2]; return; }
    }
    /** A brand-new alias gets its own isolated profile. A lone, empty, unlinked profile is reused instead of leaving it unused. */
    private void createProfileFor(String aliasId) {
        String name = null;
        if (profileNames.size() == 1 && links.optString(profileNames.get(0), "").isEmpty()) {
            List<String> con = scanConnected(keyOf(profileNames.get(0)));
            if (scanCookieOk && con.isEmpty()) name = profileNames.get(0);
        }
        if (name == null) {
            int i = 1; while (profileNames.contains("Account " + i)) i++;
            name = "Account " + i; profileNames.add(name);
            try { keys.put(name, "orbit_" + java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 10)); } catch (Exception ignored) { }
        }
        try { String other = profileLinkedTo(aliasId); if (other != null) links.remove(other); links.put(name, aliasId); } catch (Exception ignored) { }
        activeProfile = name; saveProfiles(); saveLinks(); saveMeta();
    }
    /** Alias Manager opened Orbit for an alias that has no profile yet: offer to link it to the profile on screen. */
    private void offerLink() {
        final String[] pl = pendingLink; pendingLink = null;
        if (pl == null || isFinishing()) return;
        final String profile = activeProfile;
        dlg().setTitle("Link " + pl[1] + "?")
            .setMessage("This alias is not linked to an account yet.\n\nLink it to \"" + profile + "\"? If it belongs to a different account, tap Not now, switch to that account, and choose Link alias in the menu.")
            .setPositiveButton("Link", (d, w) -> {
                try { String other = profileLinkedTo(pl[0]); if (other != null) links.remove(other); links.put(profile, pl[0]); saveLinks(); } catch (Exception ignored) { }
                refreshStatus();
                afterLink(profile);
            }).setNegativeButton("Not now", null).show();
    }
    private void manageProfile() {
        final String name = activeProfile;
        String em = emojiOf(name), mail = linkedEmail(name);
        LinearLayout b = openSheet((em.isEmpty() ? "" : em + " ") + tabLabel(name), mail != null ? mail : "No alias linked");
        b.addView(menuRow("🤖", "Switch AI…", null, false, this::openAiSheet));
        b.addView(sectionLabel("Account"));
        b.addView(menuRow("✏", "Rename account", null, false, () -> askRename(name)));
        b.addView(menuRow("↺", "Reset name to the alias", null, false, () -> resetTabName(name)));
        b.addView(menuRow("😀", "Change emoji", null, false, () -> pickEmoji(name)));
        b.addView(menuRow("🎨", "Change color", null, false, () -> pickColor(name)));
        b.addView(menuRow("🔗", "Link an alias…", null, false, this::linkAlias));
        b.addView(sectionLabel("Downloads"));
        b.addView(menuRow("📁", "Download project folder…", null, false, this::pickProject));
        b.addView(menuRow("📂", "Custom download folder…", null, false, this::pickCustomDir));
        b.addView(menuRow("🕑", "Downloaded files…", null, false, () -> openFiles("")));
        b.addView(sectionLabel("Automation"));
        b.addView(menuRow("\u23F0", "Scheduled messages\u2026", scheduleState(name), false, this::showScheduleList));
        b.addView(sectionLabel("Security"));
        b.addView(menuRow("🚪", "Sign out of this account…", null, false, () -> confirmSignOut(name)));
        b.addView(menuRow("🛡", "Google sign-in blocked? Get help", null, false, () -> showGoogleBlocked(name)));
        b.addView(sectionLabel("Background"));
        b.addView(menuRow("🪟", "Picture-in-picture", pipSupported() ? null : "Not supported", false, () -> enterPip(true)));
        if (pipSupported()) b.addView(menuRow("↗", "Auto picture-in-picture", pipAuto ? "On" : "Off", false, () -> { pipAuto = !pipAuto; prefs.edit().putBoolean("pip_auto", pipAuto).apply(); Toast.makeText(this, pipAuto ? "Orbit will use picture-in-picture when you leave it" : "Auto picture-in-picture off", Toast.LENGTH_SHORT).show(); }));
        b.addView(menuRow("🔋", "Keep running in background", keepAliveOn ? "On" : "Off", false, () -> setKeepAlive(!keepAliveOn)));
        b.addView(menuRow("⚡", "Battery and background help", batteryUnrestricted() ? "Unrestricted" : "Optimized", false, this::showBatterySheet));
        b.addView(sectionLabel("Advanced"));
        b.addView(menuRow("↕", "Address bar", compact ? "Hidden" : "Shown", false, () -> { compact = !compact; prefs.edit().putBoolean("compact", compact).apply(); applyCompact(); }));
        b.addView(menuRow("▭", "AI shortcuts bar", showChips ? "On" : "Off", false, () -> { showChips = !showChips; prefs.edit().putBoolean("svc_chips", showChips).apply(); applyCompact(); }));
        b.addView(menuRow("🍪", "Show cookie names (diagnostics)", null, false, this::showCookieNames));
        b.addView(sectionLabel("Orbit"));
        b.addView(menuRow("✕", "Close Orbit", null, false, this::finish));
        b.addView(sectionLabel("Danger zone"));
        b.addView(menuRow("🗑", "Delete profile…", null, true, () -> confirmDelete(name)));
        showSheet();
    }
    private void resetTabName(String name) {
        if (name.matches("Account \\d+")) { Toast.makeText(this, "Already using the alias name", Toast.LENGTH_SHORT).show(); return; }
        int i = 1; while (profileNames.contains("Account " + i)) i++;
        renameProfile(name, "Account " + i);
    }
    private void pickService() { openAiSheet(); }
    private void openAiSheet() {
        Set<String> con = connectedByKey.get(keyOf(activeProfile));
        String curPid = (!mailMode && webView != null) ? providerIdForUrl(webView.getUrl()) : null;
        LinearLayout b = openSheet("Open which AI?", tabLabel(activeProfile));
        for (final String[] p : providers) b.addView(aiRowFor(p, p[0].equals(curPid), con != null && con.contains(p[0]), () -> { closeSheet(); openService(p[0]); }));
        showSheet();
    }
    private void openService(String id) {
        if (mailMode) exitMail();
        if (webView == null) return;
        for (String[] p : providers) if (p[0].equals(id)) { address.setText(p[2]); webView.loadUrl(p[2]); return; }
    }
    private void pickEmoji(final String name) {
        String[] labels = new String[EMOJIS.length];
        for (int i = 0; i < EMOJIS.length; i++) labels[i] = EMOJIS[i].isEmpty() ? "— None —" : EMOJIS[i];
        dlg().setTitle("Emoji for " + name).setItems(labels, (d, w) -> setStyle(name, EMOJIS[w], null)).show();
    }
    private void pickColor(final String name) {
        dlg().setTitle("Color for " + name).setItems(COLOR_NAMES, (d, w) -> setStyle(name, null, COLOR_VALUES[w])).show();
    }
    private void askRename(final String old) {
        final EditText in = new EditText(this); in.setSingleLine(true); in.setText(old); in.setSelection(old.length());
        dlg().setTitle("Rename account").setView(in)
            .setPositiveButton("Save", (d, w) -> renameProfile(old, in.getText().toString()))
            .setNegativeButton("Cancel", null).show();
    }
    /** Renaming only changes the label; the WebView data key stays the same, so the login is kept. */
    private void renameProfile(String old, String raw) {
        String clean = raw.replace("\n", " ").trim();
        if (clean.isEmpty() || clean.length() > 24) { showMessage("Use 1 to 24 characters."); return; }
        if (clean.equals(old)) return;
        for (String n : profileNames) if (n.equalsIgnoreCase(clean)) { showMessage("A profile named \"" + n + "\" already exists."); return; }
        try {
            String k = keyOf(old);
            profileNames.set(profileNames.indexOf(old), clean);
            keys.remove(old); keys.put(clean, k);
            String l = links.optString(old, ""); links.remove(old); if (!l.isEmpty()) links.put(clean, l);
            JSONObject st = styles.optJSONObject(old); styles.remove(old); if (st != null) styles.put(clean, st);
            JSONObject seen = new JSONObject(prefs.getString("seen", "{}"));
            JSONArray ids = seen.optJSONArray(old); seen.remove(old); if (ids != null) seen.put(clean, ids);
            prefs.edit().putString("seen", seen.toString()).apply();
            if (activeProfile.equals(old)) activeProfile = clean;
            saveProfiles(); saveLinks(); saveMeta(); renderTabs(); refreshStatus();
        } catch (Exception e) { showMessage("Could not rename: " + e.getMessage()); }
    }
    // ---- Sign out: clears this profile's cookies + site data, but keeps the tab, its alias link and its style ----
    private void confirmSignOut(final String name) {
        if (!profileSupported) { showMessage("Profiles cannot be managed until Android System WebView is updated."); return; }
        dlg().setTitle("Sign out \"" + name + "\"?")
            .setMessage("This erases the sign-in (cookies and site data) for this account on this phone. The account's tab, alias link and color are kept. Your AI accounts and chats are not deleted.")
            .setPositiveButton("Sign out", (d, w) -> signOut(name))
            .setNegativeButton("Cancel", null).show();
    }
    private void signOut(String name) {
        boolean ok = false;
        try {
            Object prof = ProfileStore.getInstance().getProfile(keyOf(name));
            if (prof != null) {
                // Looked up by reflection on the public androidx.webkit.Profile interface (signature not checked at build time).
                Class<?> pc = Class.forName("androidx.webkit.Profile");
                android.webkit.CookieManager cm = (android.webkit.CookieManager) pc.getMethod("getCookieManager").invoke(prof);
                android.webkit.WebStorage ws = (android.webkit.WebStorage) pc.getMethod("getWebStorage").invoke(prof);
                cm.removeAllCookies(null); cm.flush(); ws.deleteAllData();
                ok = true;
            }
        } catch (Throwable ignored) { }
        if (!ok) { showMessage("Could not sign out of this profile because this WebView version does not allow it. Use Delete profile instead."); return; }
        saveUrlConn(keyOf(name), new LinkedHashSet<String>());
        String aliasId = links.optString(name, "");
        loginSent.remove(name + "|" + aliasId); promptedLogin.remove(name); loginHinted.remove(name);
        if (!aliasId.isEmpty()) {
            try { queueEvent(new JSONObject().put("type", "logout").put("aliasId", aliasId).put("profile", name).put("ts", System.currentTimeMillis())); } catch (Exception ignored) { }
        }
        if (name.equals(activeProfile) && webView != null) {
            webView.clearCache(true); webView.clearHistory(); lastUrls.remove(keyOf(name));
            address.setText("https://claude.ai/login"); webView.loadUrl("https://claude.ai/login");
        }
        servicesSent.remove(keyOf(name)); scheduleServiceScan(name);
        Toast.makeText(this, "Signed out: " + name, Toast.LENGTH_SHORT).show();
    }
    // ---- Limit detection (user-requested). Reads the visible text of the Claude page you are looking at, ONLY to find a
    // "you've reached your limit" message and its reset time. Only the matched line (max 300 chars) leaves the page; nothing is stored. ----
    private static final String LIMIT_JS = "(function(){try{var t=(document.body&&document.body.innerText)||'';"
        + "var m=t.match(/[^\\n]{0,80}(you(?:'|’)?ve (?:reached|hit)[^\\n]{0,60}limit|you(?:'|’)?re (?:out of|over)[^\\n]{0,30}(?:messages|usage)|usage limit reached|your limit (?:will )?resets?)[^\\n]*(?:\\n[^\\n]*){0,2}/i);"
        + "return m?m[0].slice(0,300):'';}catch(x){return '';}})()";
    private static final Pattern RESET_REL = Pattern.compile("(?i)\\bin\\s+(?:(\\d+)\\s*(?:hours?|hrs?|h)\\b)?\\s*(?:and\\s*)?(?:(\\d+)\\s*(?:minutes?|mins?|m)\\b)?");
    private static final Pattern RESET_CLOCK = Pattern.compile("(?i)\\b(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)\\b");
    private final Map<String, long[]> limitSeen = new HashMap<>(); // aliasId -> {key, when}
    // ---- Incognito chat (Claude): the address stays https://claude.ai/ , so the URL cannot show that a chat started. Watch the page instead:
    // "You're incognito" welcome screen -> a conversation = the first message was sent. Reads only two yes/no answers, no chat text leaves the page. ----
    private static final String GHOST_JS = ""
        + "(function(){try{\n"
        + "var t=(document.body&&document.body.innerText)||'';\n"
        + "var head=t.slice(0,400);\n"
        + "var inc=/incognito chat|temporary chat|private chat|incognito mode|private mode/i.test(head)||/incognito chats stay out/i.test(t)||/[?&](temporary-chat|incognito|private)=(true|1)/i.test(location.search);\n"
        + "var wel=/you(?:'|\\u2019)re incognito/i.test(t);\n"
        + "var W=window.__orbitGhost=window.__orbitGhost||{typed:'',at:0,hooked:0};\n"
        + "if(!W.hooked){W.hooked=1;document.addEventListener('input',function(e){try{var el=e.target;var v=(el.tagName==='TEXTAREA'||el.tagName==='INPUT')?el.value:(el.isContentEditable?el.innerText:'');v=(v||'').replace(/\\s+/g,' ').trim();if(v.length>0){W.typed=v.slice(0,40);W.at=Date.now();}}catch(x){}},true);}\n"
        + "var comp=document.querySelector('[data-testid=chat-input]')||document.querySelector('#prompt-textarea')||document.querySelector('div.ProseMirror[contenteditable=true]')||document.querySelector('.ql-editor[contenteditable=true]')||document.querySelector('div[contenteditable=true]')||document.querySelector('textarea');\n"
        + "var cur=comp?(((comp.tagName==='TEXTAREA'||comp.tagName==='INPUT')?comp.value:comp.innerText)||'').replace(/\\s+/g,' ').trim():'x';\n"
        + "var sent=0;\n"
        + "if(inc&&cur===''&&W.typed&&Date.now()-W.at<45000&&t.replace(/\\s+/g,' ').indexOf(W.typed)!==-1){sent=1;W.typed='';}\n"
        + "return (inc?1:0)+(wel?2:0)+(sent?4:0);\n"
        + "}catch(x){return 0;}})()\n";
    private final Map<String, Long> ghostWelcomeAt = new HashMap<>(); // profile key -> when the empty incognito screen was last seen
    private final Runnable ghostTick = new Runnable() { @Override public void run() { checkGhost(); ticker.postDelayed(this, 2500); } };
    private final Map<String, Long> ghostLastAt = new HashMap<>(); // profile key -> when an Incognito chat was last counted (the same chat is never counted twice)
    /** Works for every AI: asks the page "is this an Incognito / Temporary / Private chat?" and "was a message just sent?" (the box emptied and the text is now on the page). */
    private void checkGhost() {
        if (!autoStart || mailMode || webView == null || isFinishing() || autoProfile != null) return;
        final WebView v = webView;
        String u = v.getUrl();
        final String pid = u == null ? null : providerIdForUrl(u);
        if (pid == null) return;
        final String profile = activeProfile, key = keyOf(profile);
        v.evaluateJavascript(GHOST_JS, value -> {
            if (v != webView || value == null) return;
            int st;
            try { st = Integer.parseInt(value.replace("\"", "").trim()); } catch (Exception e) { return; }
            long now = System.currentTimeMillis();
            if ((st & 3) == 3) ghostWelcomeAt.put(key, now); // the empty Incognito screen (Claude)
            Long w = ghostWelcomeAt.get(key);
            boolean sentNow = (st & 4) != 0;                                             // a message was just sent in an Incognito chat (any AI)
            boolean moved = (st & 3) == 1 && w != null && now - w < 90000L;             // Claude: empty screen -> conversation shortly after
            if (!sentNow && !moved) return;
            Long last = ghostLastAt.get(key);
            if (last != null && now - last < 60000L) return;                             // the other check saw this same chat a moment ago
            ghostWelcomeAt.remove(key); ghostLastAt.put(key, now);
            chatStarted(profile, pid, "incognito-" + now, true);
        });
    }
    private final Runnable limitTick = new Runnable() { @Override public void run() { checkLimit(); ticker.postDelayed(this, 10000); } };
    private void checkLimit() {
        if (!autoStart || mailMode || webView == null || isFinishing()) return;
        final WebView v = webView;
        String u = v.getUrl();
        if (u == null || !u.startsWith("https://claude.ai/")) return;
        final String profile = activeProfile;
        final String aliasId = links.optString(profile, "");
        if (aliasId.isEmpty() || linkedEmail(profile) == null) return;
        v.evaluateJavascript(LIMIT_JS, value -> {
            if (v != webView || value == null) return;
            String text = "";
            try { text = new JSONArray("[" + value + "]").optString(0, ""); } catch (Exception ignored) { }
            if (!text.isEmpty()) onLimitSeen(profile, aliasId, text);
        });
    }
    /** Best effort: "resets in 2 hours 10 minutes" or "resets at 3:30 PM". 0 = unknown (or not within the next 5h). */
    private long parseReset(String text, long now) {
        try { return parseResetUnsafe(text, now); } catch (Exception e) { return 0; } // e.g. absurdly long numbers in the page text
    }
    private long parseResetUnsafe(String text, long now) {
        long at = 0;
        Matcher r = RESET_REL.matcher(text);
        while (r.find()) {
            if (r.group(1) == null && r.group(2) == null) continue;
            long h = r.group(1) == null ? 0 : Long.parseLong(r.group(1)), mi = r.group(2) == null ? 0 : Long.parseLong(r.group(2));
            at = now + (h * 60 + mi) * 60000L; break;
        }
        if (at == 0) {
            Matcher c = RESET_CLOCK.matcher(text);
            if (c.find()) {
                int hh = Integer.parseInt(c.group(1)) % 12, mm = c.group(2) == null ? 0 : Integer.parseInt(c.group(2));
                if (c.group(3).equalsIgnoreCase("pm")) hh += 12;
                java.util.Calendar cal = java.util.Calendar.getInstance();
                cal.set(java.util.Calendar.HOUR_OF_DAY, hh); cal.set(java.util.Calendar.MINUTE, mm); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0);
                if (cal.getTimeInMillis() <= now) cal.add(java.util.Calendar.DAY_OF_YEAR, 1);
                at = cal.getTimeInMillis();
            }
        }
        if (at <= now || at - now > windowMs("claude") + 30 * 60000L) return 0;
        return at;
    }
    private void onLimitSeen(String profile, String aliasId, String text) {
        long now = System.currentTimeMillis();
        long resetAt = parseReset(text, now);
        long key = resetAt > 0 ? resetAt / 600000L : -1; // same reset time (10-minute buckets) = same limit message
        long[] prev = limitSeen.get(aliasId);
        if (prev != null && prev[0] == key && now - prev[1] < 30 * 60000L) return;
        limitSeen.put(aliasId, new long[]{key, now});
        String email = linkedEmail(profile);
        if (email == null) return;
        Long st = started.get(aliasId);
        long win = windowMs("claude");
        boolean running = st != null && now - st < win;
        long readyAt;
        if (resetAt > 0) { started.put(aliasId, resetAt - win); readyAt = resetAt; }
        else if (running) { readyAt = st + win; }
        else { started.put(aliasId, now); readyAt = now + win; }
        OrbitReminderReceiver.add(this, aliasId, email, readyAt);
        try { queueEvent(new JSONObject().put("type", "limit").put("aliasId", aliasId).put("profile", profile).put("resetAt", resetAt).put("ts", now)); } catch (Exception ignored) { }
        refreshStatus();
        java.text.DateFormat df = android.text.format.DateFormat.getTimeFormat(this);
        Toast.makeText(this, "Limit reached: " + email + (resetAt > 0 ? " · resets " + df.format(new java.util.Date(resetAt)) : ""), Toast.LENGTH_LONG).show();
    }
    private void confirmDelete(final String victim) {
        if (!profileSupported) { showMessage("Profiles cannot be managed until Android System WebView is updated."); return; }
        if (profileNames.size() <= 1) { showMessage("You need at least one account. Add another before deleting this one."); return; }
        dlg().setTitle("Delete \"" + victim + "\"?")
            .setMessage("This signs out of this profile and erases its cookies and site data on this phone.\n\nYour AI accounts and chats are not deleted. The alias link is removed. This cannot be undone.")
            .setPositiveButton("Delete", (d, w) -> deleteProfile(victim))
            .setNegativeButton("Cancel", null).show();
    }
    private void deleteProfile(String victim) {
        String key = keyOf(victim);
        int i = profileNames.indexOf(victim);
        if (i < 0 || profileNames.size() <= 1) return;
        String next = profileNames.get(i == 0 ? 1 : i - 1);
        if (victim.equals(activeProfile)) { activeProfile = next; saveProfiles(); renderTabs(); showProfile(next); }
        WebView dead = views.remove(key); if (dead != null && dead != webView) destroyView(dead); // its page must be gone before the data is erased
        // Remove it from Orbit right away. Android may still count the profile as "in use" for a moment,
        // so the erase of its cookies/site data is retried, and finished at the next start if needed.
        try {
            saveUrlConn(key, new LinkedHashSet<String>());
            profileNames.remove(victim); keys.remove(victim); styles.remove(victim); links.remove(victim); dropProjects(key); dropCustomDirs(key);
            JSONObject seen = new JSONObject(prefs.getString("seen", "{}")); seen.remove(victim);
            prefs.edit().putString("seen", seen.toString()).apply();
        } catch (Exception ignored) { }
        saveProfiles(); saveLinks(); saveMeta(); renderTabs(); refreshStatus();
        Set<String> pend = pendingErase(); pend.add(key); savePendingErase(pend);
        eraseAttempt(0);
    }
    private Set<String> pendingErase() {
        Set<String> out = new LinkedHashSet<>();
        for (String k : prefs.getString("pending_erase", "").split("\\n")) if (!k.trim().isEmpty()) out.add(k.trim());
        return out;
    }
    private void savePendingErase(Set<String> set) { prefs.edit().putString("pending_erase", android.text.TextUtils.join("\n", set)).commit(); }
    /** @return true when nothing is left to erase. */
    private boolean erasePendingNow() { return erasePendingStatic(prefs); }
    /** Also used by OrbitBrowserPlugin (Alias Manager deleting an alias). Erases profile data that Android refused to erase earlier. */
    static boolean erasePendingStatic(android.content.SharedPreferences sp) {
        Set<String> pend = new LinkedHashSet<>();
        for (String k : sp.getString("pending_erase", "").split("\\n")) if (!k.trim().isEmpty()) pend.add(k.trim());
        if (pend.isEmpty()) return true;
        try {
            ProfileStore store = ProfileStore.getInstance();
            for (String k : new ArrayList<>(pend)) {
                try { if (store.deleteProfile(k) || store.getProfile(k) == null) pend.remove(k); } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
        sp.edit().putString("pending_erase", android.text.TextUtils.join("\n", pend)).commit();
        return pend.isEmpty();
    }
    private void eraseAttempt(final int attempt) {
        if (erasePendingNow()) { Toast.makeText(this, "Profile deleted and data erased", Toast.LENGTH_SHORT).show(); return; }
        if (attempt < 6) ticker.postDelayed(() -> eraseAttempt(attempt + 1), 800);
        else Toast.makeText(this, "Profile removed. Its data is erased the next time you open Orbit.", Toast.LENGTH_LONG).show();
    }
    private void loadMeta() {
        try { keys = new JSONObject(prefs.getString("keys", "{}")); } catch (Exception e) { keys = new JSONObject(); }
        try { styles = new JSONObject(prefs.getString("styles", "{}")); } catch (Exception e) { styles = new JSONObject(); }
    }
    private void saveMeta() { prefs.edit().putString("keys", keys.toString()).putString("styles", styles.toString()).apply(); }
    private String keyOf(String name) { String k = keys.optString(name, ""); return k.isEmpty() ? profileKey(name) : k; }
    private String nameOfKey(String key) { for (String n : profileNames) if (keyOf(n).equals(key)) return n; return null; }
    private int colorOf(String name) { JSONObject st = styles.optJSONObject(name); return st == null ? C_ACCENT : st.optInt("color", C_ACCENT); }
    /** Tab text: your own name if you renamed the profile; otherwise the linked alias (note or short email), else "Account N". */
    private String tabLabel(String name) {
        if (!name.matches("Account \\d+")) return name;
        String id = links.optString(name, "");
        if (id.isEmpty()) return name;
        for (String[] a : aliases) if (a[0].equals(id)) {
            String t = a.length > 2 && !a[2].isEmpty() ? a[2] : a[1].contains("@") ? a[1].substring(0, a[1].indexOf('@')) : a[1];
            return t.length() > 14 ? t.substring(0, 13) + "…" : t;
        }
        return name;
    }
    private String emojiOf(String name) { JSONObject st = styles.optJSONObject(name); return st == null ? "" : st.optString("emoji", ""); }
    private void setStyle(String name, String emoji, Integer color) {
        try {
            JSONObject st = styles.optJSONObject(name); if (st == null) st = new JSONObject();
            if (emoji != null) st.put("emoji", emoji);
            if (color != null) st.put("color", color.intValue());
            styles.put(name, st); saveMeta(); renderTabs();
        } catch (Exception ignored) { }
    }
    private void loadLinks() {
        try { links = new JSONObject(prefs.getString("links", "{}")); } catch (Exception e) { links = new JSONObject(); }
    }
    private void saveLinks() { prefs.edit().putString("links", links.toString()).apply(); }
    private String linkedEmail(String profile) {
        String id = links.optString(profile, "");
        if (id.isEmpty()) return null;
        for (String[] a : aliases) if (a[0].equals(id)) return a[1];
        return null; // alias was deleted in Alias Manager
    }
    private String timerText(String profile) {
        String id = links.optString(profile, "");
        if (id.isEmpty() || linkedEmail(profile) == null) return "";
        String pid = (!mailMode && webView != null) ? providerIdForUrl(webView.getUrl()) : null;
        if (pid == null) pid = "claude";
        Long st = started.get(timerKey(id, pid));
        if (st == null) return " · Not started";
        long left = windowMs(pid) - (System.currentTimeMillis() - st);
        if (left <= 0) return " · Ready";
        long mins = (left + 59999) / 60000;
        return " · " + (mins / 60) + "h " + (mins % 60) + "m left";
    }
    private String who() {
        String e = linkedEmail(activeProfile);
        if (mailMode) return "Gmail · Claude links open in " + tabLabel(activeProfile);
        return (e != null ? e : "No alias linked") + timerText(activeProfile) + (autoStart ? "" : " · Automatic timer off") + (keepAliveOn ? " · Running in background" : "");
    }
    private CharSequence titleText() {
        String em = emojiOf(activeProfile);
        SpannableString sp = new SpannableString("●  " + (em.isEmpty() ? "" : em + " ") + tabLabel(activeProfile));
        sp.setSpan(new ForegroundColorSpan(colorOf(activeProfile)), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return sp;
    }
    private void refreshStatus() {
        if (!tabsSignature().equals(tabsSig)) renderTabs(); // labels changed (alias linked / renamed in Alias Manager)
        renderServiceChips();
        if (status != null) status.setText(who() + (statusSuffix.isEmpty() ? "" : " · " + statusSuffix));
        if (titleView != null) titleView.setText(mailMode ? "Gmail" : titleText());
    }
    /** One tap back to the Alias Manager (the screen with all accounts). If Orbit was opened from the widget / a notification, the manager is started first. */
    private void goHome() {
        try {
            if (isTaskRoot()) {
                Intent li = getPackageManager().getLaunchIntentForPackage(getPackageName());
                if (li != null) { li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(li); }
            }
        } catch (Exception ignored) { }
        finish();
    }
    private void goBack() {
        if (mailMode) { if (mailView != null && mailView.canGoBack()) mailView.goBack(); else exitMail(); return; }
        if (webView != null && webView.canGoBack()) webView.goBack();
    }
    @Override public void onBackPressed() {
        if (drawerOpen) { closeDrawer(); return; }
        if (mailMode) { goBack(); return; }
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onResume() { super.onResume(); keepAliveOn = prefs.getBoolean("keep_alive", false); if (keepAliveOn) startKeepAlive(false); checkLock(); checkRev(); reloadAliases(); scheduleServiceScan(activeProfile); refreshStatus(); ticker.removeCallbacks(tick); ticker.post(tick); ticker.removeCallbacks(limitTick); ticker.postDelayed(limitTick, 6000); ticker.removeCallbacks(ghostTick); ticker.postDelayed(ghostTick, 3000); }
    @Override protected void onPause() { OrbitBrowserPlugin.lastActive = System.currentTimeMillis(); ticker.removeCallbacks(tick); ticker.removeCallbacks(limitTick); ticker.removeCallbacks(ghostTick); super.onPause(); }
    /** Alias Manager deleted an alias (and its profile) while Orbit was in the background: pick up the new state. */
    private void checkRev() {
        long r = prefs.getLong("rev", 0);
        if (r == loadedRev) return;
        loadedRev = r;
        loadProfiles(); loadLinks(); loadMeta();
        java.util.HashSet<String> valid = new java.util.HashSet<>();
        for (String n : profileNames) valid.add(keyOf(n));
        java.util.Iterator<Map.Entry<String, WebView>> it = views.entrySet().iterator();
        while (it.hasNext()) { Map.Entry<String, WebView> e = it.next(); if (!valid.contains(e.getKey())) { if (e.getValue() == webView) webView = null; destroyView(e.getValue()); it.remove(); } }
        erasePendingNow();
        if (profileSupported && views.get(keyOf(activeProfile)) != webView) showProfile(activeProfile);
        renderTabs(); refreshStatus();
    }
    private void linkAlias() {
        reloadAliases();
        if (aliases.isEmpty()) { showMessage("No aliases found. Add an email in Alias Manager first, then open Orbit Browser again.\n\n" + aliasDebug); return; }
        final String profile = activeProfile;
        final String[] items = new String[aliases.size() + 1];
        items[0] = "No alias";
        for (int i = 0; i < aliases.size(); i++) {
            String id = aliases.get(i)[0], email = aliases.get(i)[1];
            String other = profileLinkedTo(id);
            items[i + 1] = email + (other != null && !other.equals(profile) ? "  (currently: " + other + ")" : "");
        }
        dlg().setTitle("Alias for " + profile).setItems(items, (d, which) -> {
            try {
                if (which == 0) { links.remove(profile); }
                else {
                    String id = aliases.get(which - 1)[0];
                    String other = profileLinkedTo(id);
                    if (other != null) links.remove(other); // one alias <-> one profile
                    links.put(profile, id);
                }
                saveLinks();
            } catch (Exception ignored) { }
            refreshStatus();
            if (which > 0) afterLink(profile);
        }).setNegativeButton("Cancel", null).show();
    }
    /** Right after a profile gets an alias: fill the login email, tell Alias Manager it is logged in, start a waiting chat. */
    private void afterLink(String profile) {
        if (webView == null) return;
        String u = webView.getUrl();
        maybeFillEmail(webView, u, profile);
        if (u != null && LOGGED_IN_URL.matcher(u).find()) onLoggedInPage(profile);
        servicesSent.remove(keyOf(profile)); reportServices(profile);
        if (pendingChat != null && pendingChat[0].equals(profile)) { String[] pc = pendingChat; pendingChat = null; handleNewChat(profile, pc[2], pc[1]); }
    }
    private void queueEvent(JSONObject ev) {
        try {
            synchronized (LOCK) {
                JSONArray q = new JSONArray(prefs.getString("events", "[]"));
                q.put(ev);
                prefs.edit().putString("events", q.toString()).commit();
            }
        } catch (Exception ignored) { }
    }
    /** A logged-in claude.ai page is showing in this profile. Linked -> tell Alias Manager; not linked -> ask which alias (once). */
    private void onLoggedInPage(String forProfile) {
        String aliasId = links.optString(forProfile, "");
        if (aliasId.isEmpty() || linkedEmail(forProfile) == null) {
            if (!aliases.isEmpty() && !isFinishing() && !mailMode && forProfile.equals(activeProfile) && promptedLogin.add(forProfile)) {
                Toast.makeText(this, forProfile + " is signed in. Choose its alias.", Toast.LENGTH_LONG).show();
                linkAlias();
            }
            return;
        }
        if (!loginSent.add(forProfile + "|" + aliasId)) return;
        try { queueEvent(new JSONObject().put("type", "login").put("aliasId", aliasId).put("profile", forProfile).put("ts", System.currentTimeMillis())); } catch (Exception ignored) { }
    }
    private String profileLinkedTo(String aliasId) {
        java.util.Iterator<String> it = links.keys();
        while (it.hasNext()) { String p = it.next(); if (aliasId.equals(links.optString(p, ""))) return p; }
        return null;
    }
    /** Called for every URL change (incl. single-page navigation). A "first chat" is: home page of an AI -> its conversation page. */
    private void onUrlChanged(String forProfile, String url) {
        if (url == null) return;
        String ukey = keyOf(forProfile);
        String prev = lastUrls.get(ukey);
        if (url.equals(prev)) return;
        lastUrls.put(ukey, url);
        String seenPid = providerIdForUrl(url); // remember the AI this account is using, so the next "Open" returns to it
        if (seenPid != null && !seenPid.equals(prefs.getString("lastpid:" + forProfile, ""))) prefs.edit().putString("lastpid:" + forProfile, seenPid).apply();
        trackUrlLogin(ukey, forProfile, url);
        if (LOGGED_IN_URL.matcher(url).find()) onLoggedInPage(forProfile);
        for (String[] p : providers) {
            if (p[7].isEmpty()) continue;
            Matcher m;
            try { m = Pattern.compile(p[7]).matcher(url); } catch (Exception e) { continue; }
            if (!m.find() || m.groupCount() < 1 || m.group(1) == null) continue;
            if (prev == null) return;
            boolean prevIsHome;
            if (p[0].equals("claude")) prevIsHome = NEW_CHAT_PAGE.matcher(prev).find();
            else prevIsHome = p[0].equals(providerIdForUrl(prev)) && !chatUrlMatches(p, prev);
            if (!prevIsHome) return;
            chatStarted(forProfile, p[0], m.group(1).toLowerCase());
            return;
        }
    }
    private static boolean chatUrlMatches(String[] p, String url) {
        try { return !p[7].isEmpty() && Pattern.compile(p[7]).matcher(url).find(); } catch (Exception e) { return false; }
    }
    private void chatStarted(String forProfile, String pid, String chatId) { chatStarted(forProfile, pid, chatId, false); }
    private void chatStarted(String forProfile, String pid, String chatId, boolean ghost) {
        String sid = pid.equals("claude") ? chatId : pid + ":" + chatId;
        if (isSeen(forProfile, sid)) return; // already counted
        if (autoStart && (links.optString(forProfile, "").isEmpty() || linkedEmail(forProfile) == null)) {
            // A chat was started but this profile has no alias yet: ask now, and start the timer right after.
            pendingChat = new String[]{forProfile, chatId, pid};
            if (!aliases.isEmpty() && !isFinishing() && !mailMode && forProfile.equals(activeProfile) && promptedChats.add(forProfile + "|" + sid)) {
                Toast.makeText(this, (ghost ? "Incognito chat detected. " : "Chat detected. ") + "Choose the alias for " + forProfile + " to start its timer.", Toast.LENGTH_LONG).show();
                linkAlias();
            }
            return;
        }
        handleNewChat(forProfile, pid, chatId, ghost);
    }
    private void handleNewChat(String forProfile, String pid, String chatId) { handleNewChat(forProfile, pid, chatId, false); }
    private void handleNewChat(String forProfile, String pid, String chatId, boolean ghost) {
        String sid = pid.equals("claude") ? chatId : pid + ":" + chatId;
        if (!markSeen(forProfile, sid)) return;
        if (autoProfile != null && forProfile.equals(autoProfile)) autoDetected = true;
        if (!autoStart) { if (ghost) Toast.makeText(this, "Incognito chat detected (automatic timers are off)", Toast.LENGTH_LONG).show(); return; } // chat is remembered, but no timer is started while auto-start is off
        String aliasId = links.optString(forProfile, "");
        String email = linkedEmail(forProfile);
        if (aliasId.isEmpty() || email == null) return;
        try {
            long now = System.currentTimeMillis();
            JSONObject ev = new JSONObject().put("aliasId", aliasId).put("profile", forProfile).put("chatId", chatId).put("ts", now);
            if (!pid.equals("claude")) ev.put("service", pid);
            queueEvent(ev);
            String tk = timerKey(aliasId, pid); long win = windowMs(pid);
            Long st = started.get(tk);
            boolean fresh = st == null || now - st >= win;
            if (fresh) { started.put(tk, now); OrbitReminderReceiver.add(this, tk, reminderLabel(email, pid), now + win); } // first chat of a new window
            refreshStatus();
            // An Incognito chat ALWAYS gets its own message, even when a normal chat was already counted and the timer is running
            if (ghost) Toast.makeText(this, "Incognito chat detected: " + email + " \u00B7 " + providerName(pid) + (fresh ? "" : " (timer already running)"), Toast.LENGTH_LONG).show();
            else Toast.makeText(this, "Chat detected: " + email + (pid.equals("claude") ? "" : " · " + providerName(pid)), Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) { }
    }
    private boolean isSeen(String profile, String chatId) {
        try {
            JSONArray ids = new JSONObject(prefs.getString("seen", "{}")).optJSONArray(profile);
            if (ids != null) for (int i = 0; i < ids.length(); i++) if (chatId.equals(ids.optString(i))) return true;
        } catch (Exception ignored) { }
        return false;
    }
    /** @return true if chatId is new for this profile (and remembers it). Keeps the last 300 ids. */
    private boolean markSeen(String profile, String chatId) {
        try {
            JSONObject all = new JSONObject(prefs.getString("seen", "{}"));
            JSONArray ids = all.optJSONArray(profile);
            if (ids == null) ids = new JSONArray();
            for (int i = 0; i < ids.length(); i++) if (chatId.equals(ids.optString(i))) return false;
            ids.put(chatId);
            if (ids.length() > 300) { JSONArray t = new JSONArray(); for (int i = ids.length() - 300; i < ids.length(); i++) t.put(ids.optString(i)); ids = t; }
            all.put(profile, ids);
            prefs.edit().putString("seen", all.toString()).apply();
            return true;
        } catch (Exception e) { return false; }
    }
    private void saveProfiles() {
        prefs.edit().putString("profiles", android.text.TextUtils.join("\n", profileNames)).putString("active", activeProfile).apply();
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView label(String text, float size) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(C_TEXT); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private TextView button(String text, Runnable action) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(13); t.setGravity(Gravity.CENTER); t.setTextColor(Color.WHITE);
        t.setPadding(dp(10),dp(6),dp(10),dp(6)); t.setBackground(rounded(C_SURFACE, 10)); t.setClickable(true); t.setFocusable(true); t.setOnClickListener(v -> action.run()); return t;
    }
    // ===== Batch 4a: vector icons (res/drawable/orbit_ic_*.xml, generated by tools/make_native_icons.py). The old text glyphs stay as the fallback,
    // so a missing icon file can never leave a button or row blank. =====
    private static final String[][] GLYPH_ICONS = {
        {"\u2630", "menu"},
        {"\u2302", "home"},
        {"\u23F0", "clock"},
        {"\u25A3", "chip"},
        {"\u2709", "mail"},
        {"\u22EF", "more"},
        {"\u25C0", "back"},
        {"\u21BB", "refresh"},
        {"\uFF0B", "plus"},
        {"\uD83D\uDD17", "link"},
        {"\uD83E\uDE9F", "browser"},
        {"\uD83D\uDD0B", "battery"},
        {"\u2715", "close"},
        {"\uD83E\uDD16", "spark"},
        {"\u270F", "edit"},
        {"\u21BA", "reset"},
        {"\uD83D\uDE00", "smile"},
        {"\uD83C\uDFA8", "palette"},
        {"\uD83D\uDDD1", "trash"},
        {"\uD83D\uDCC1", "folder"},
        {"\uD83D\uDCC2", "folder"},
        {"\uD83D\uDD51", "history"},
        {"\uD83D\uDEAA", "signout"},
        {"\uD83D\uDEE1", "shield"},
        {"\u2197", "external"},
        {"\u26A1", "help"},
        {"\u2195", "sort"},
        {"\u25AD", "list"},
        {"\uD83C\uDF6A", "cookie"},
        {"\u2713", "ok"},
        {"\u26A0", "warn"},
        {"\u2139", "info"},
        {"\uD83D\uDE80", "up"},
        {"\uD83D\uDD14", "bell"},
        {"\u2B06", "up"},
        {"\u2B07", "download"},
        {"\uD83D\uDCC4", "file"},
    };
    private String iconNameFor(String glyph) {
        if (glyph == null) return null;
        String g = glyph.replace("\uFE0F", "").trim();
        for (String[] e : GLYPH_ICONS) if (e[0].equals(g)) return e[1];
        return null;
    }
    private android.graphics.drawable.Drawable iconDrawable(String glyph, int color) {
        String n = iconNameFor(glyph); if (n == null) return null;
        try {
            int id = getResources().getIdentifier("orbit_ic_" + n, "drawable", getPackageName());
            if (id == 0) return null;
            android.graphics.drawable.Drawable d = getDrawable(id);
            if (d == null) return null;
            d = d.mutate(); d.setTint(color); return d;
        } catch (Exception e) { return null; }
    }
    /** Leading icon of a list row (30 dp wide column). Falls back to the text glyph. */
    private View glyphView(String glyph, int color) {
        android.graphics.drawable.Drawable d = iconDrawable(glyph, color);
        if (d != null) {
            android.widget.ImageView iv = new android.widget.ImageView(this); iv.setImageDrawable(d); iv.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
            iv.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO); iv.setLayoutParams(new LinearLayout.LayoutParams(dp(30), dp(22))); return iv;
        }
        TextView g = rowText(glyph, 16, color, false); g.setGravity(Gravity.CENTER); g.setLayoutParams(new LinearLayout.LayoutParams(dp(30), -2)); return g;
    }
    /** Small inline icon (status marks). Falls back to the text glyph. */
    private View smallIcon(String glyph, int color, int sizeDp) {
        android.graphics.drawable.Drawable d = iconDrawable(glyph, color);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)); lp.setMargins(dp(4), 0, dp(4), 0);
        if (d != null) {
            android.widget.ImageView iv = new android.widget.ImageView(this); iv.setImageDrawable(d); iv.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
            iv.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO); iv.setLayoutParams(lp); return iv;
        }
        TextView g = rowText(glyph, 14, color, true); g.setGravity(Gravity.CENTER); g.setLayoutParams(lp); return g;
    }
    /** Square icon button (44 dp in the bars). Content description = what a screen reader says. */
    private View iconButton(String glyph, String desc, Runnable action) {
        android.graphics.drawable.Drawable d = iconDrawable(glyph, C_TEXT);
        if (d == null) { TextView t = button(glyph, action); t.setTextSize(16); t.setPadding(0, 0, 0, 0); t.setContentDescription(desc); return t; }
        android.widget.ImageView iv = new android.widget.ImageView(this); iv.setImageDrawable(d); iv.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        iv.setPadding(dp(11), dp(11), dp(11), dp(11)); iv.setBackground(rounded(C_SURFACE, 10)); iv.setClickable(true); iv.setFocusable(true);
        iv.setContentDescription(desc); iv.setOnClickListener(v -> action.run()); return iv;
    }
    // ---- Which AIs is this profile signed in to? Looks only at cookie NAMES (never values) of the profile's own sign-in cookies. ----
    private boolean scanCookieOk = true; // false when this WebView version could not be asked for cookies
    /** @return provider ids the profile is signed in to: sign-in cookie seen (names only) or a logged-in page was seen (providers without a known cookie). */
    private List<String> scanConnected(String key) {
        List<String> out = new ArrayList<>(); scanCookieOk = false;
        try {
            Object prof = ProfileStore.getInstance().getProfile(key);
            if (prof == null) scanCookieOk = true; // no data yet
            else {
                Class<?> pc = Class.forName("androidx.webkit.Profile");
                android.webkit.CookieManager cm = (android.webkit.CookieManager) pc.getMethod("getCookieManager").invoke(prof);
                if (cm != null) {
                    for (String[] p : providers) {
                        if (p[3].isEmpty()) continue;
                        String header = cm.getCookie(p[2]);
                        if (header != null && hasCookieNamed(header, p[3])) out.add(p[0]);
                    }
                    scanCookieOk = true;
                }
            }
        } catch (Throwable t) { scanCookieOk = false; }
        for (String id : urlConnSet(key)) if (!out.contains(id)) out.add(id);
        return out;
    }
    /** Cookie name rules: "name" = exact match, "name*" = starts with (e.g. chunked session cookies .0 .1). */
    private static boolean hasCookieNamed(String header, String rulesCsv) {
        String[] rules = rulesCsv.split(",");
        for (String part : header.split(";")) {
            String nm = part.trim(); int eq = nm.indexOf('='); if (eq > 0) nm = nm.substring(0, eq);
            for (String r : rules) {
                if (r.isEmpty()) continue;
                if (r.endsWith("*") ? nm.startsWith(r.substring(0, r.length() - 1)) : nm.equals(r)) return true;
            }
        }
        return false;
    }
    // ---- AIs with no known sign-in cookie (DeepSeek ...): a logged-in page URL marks it connected, its login page clears it ----
    private Set<String> urlConnSet(String key) {
        Set<String> out = new LinkedHashSet<>();
        try { JSONArray a = new JSONObject(prefs.getString("url_conn", "{}")).optJSONArray(key); if (a != null) for (int i = 0; i < a.length(); i++) out.add(a.optString(i)); } catch (Exception ignored) { }
        return out;
    }
    private void saveUrlConn(String key, Set<String> set) {
        try {
            JSONObject all = new JSONObject(prefs.getString("url_conn", "{}"));
            if (set.isEmpty()) all.remove(key); else all.put(key, new JSONArray(set));
            prefs.edit().putString("url_conn", all.toString()).apply();
        } catch (Exception ignored) { }
    }
    private void trackUrlLogin(String key, String name, String url) {
        if (url == null) return;
        for (String[] p : providers) {
            if (p[5].isEmpty()) continue;
            boolean in, out = false;
            try { in = Pattern.compile(p[5]).matcher(url).find(); if (!p[6].isEmpty()) out = Pattern.compile(p[6]).matcher(url).find(); } catch (Exception e) { continue; }
            if (!in && !out) continue;
            Set<String> set = urlConnSet(key);
            boolean changed = out ? set.remove(p[0]) : set.add(p[0]);
            if (changed) { saveUrlConn(key, set); scheduleServiceScan(name); }
        }
    }
    /** Cookie header of a page in one profile (used for downloads and the cookie-name debug list). */
    private String cookieFor(String key, String url) {
        try {
            Object prof = ProfileStore.getInstance().getProfile(key);
            if (prof == null) return null;
            Class<?> pc = Class.forName("androidx.webkit.Profile");
            android.webkit.CookieManager cm = (android.webkit.CookieManager) pc.getMethod("getCookieManager").invoke(prof);
            return cm == null ? null : cm.getCookie(url);
        } catch (Throwable t) { return null; }
    }
    private void showCookieNames() {
        WebView c = cur(); String url = c == null ? null : c.getUrl();
        if (url == null) { showMessage("No page is open."); return; }
        String header = cookieFor(mailMode ? MAIL_KEY : keyOf(activeProfile), url);
        StringBuilder sb = new StringBuilder();
        if (header != null) for (String part : header.split(";")) { String nm = part.trim(); int eq = nm.indexOf('='); if (eq > 0) nm = nm.substring(0, eq); if (!nm.isEmpty()) { if (sb.length() > 0) sb.append(", "); sb.append(nm); } }
        String host = ""; try { host = Uri.parse(url).getHost(); } catch (Exception ignored) { }
        showMessage("Cookie names for " + host + ":\n\n" + (sb.length() == 0 ? "(none)" : sb.toString()) + "\n\nValues are never shown. If an AI is never marked as signed in after you sign in, send this list so its detection can be fixed.");
    }
    private void scheduleServiceScan(final String name) {
        if (name == null) return;
        if (scanTask != null) ticker.removeCallbacks(scanTask);
        scanTask = () -> reportServices(name);
        ticker.postDelayed(scanTask, 1500);
    }
    private void reportServices(String name) {
        if (name == null || isFinishing() || !profileNames.contains(name)) return;
        String key = keyOf(name);
        List<String> con = scanConnected(key);
        connectedByKey.put(key, new LinkedHashSet<>(con));
        renderServiceChips();
        String aliasId = links.optString(name, "");
        if (aliasId.isEmpty() || linkedEmail(name) == null) {
            if (!con.isEmpty() && !aliases.isEmpty() && !mailMode && name.equals(activeProfile) && promptedLogin.add(name)) {
                Toast.makeText(this, name + " is signed in. Choose its alias.", Toast.LENGTH_LONG).show();
                linkAlias();
            }
            return;
        }
        JSONArray checked = new JSONArray(), conn = new JSONArray();
        for (String[] p : providers) if ((!p[3].isEmpty() && scanCookieOk) || !p[5].isEmpty()) checked.put(p[0]);
        for (String id : con) conn.put(id);
        String sig = aliasId + "|" + conn.toString();
        if (sig.equals(servicesSent.get(key))) return;
        servicesSent.put(key, sig);
        try { queueEvent(new JSONObject().put("type", "services").put("aliasId", aliasId).put("checked", checked).put("connected", conn).put("ts", System.currentTimeMillis())); } catch (Exception ignored) { }
    }
    private void renderServiceChips() {
        if (svcRow == null) return;
        String cur = providerIdForUrl(webView == null ? null : webView.getUrl()); if (cur == null) cur = "";
        if (aiBtn != null) { android.graphics.Bitmap ib = cur.isEmpty() ? logoBitmap() : aiIcon(cur); if (ib == null) ib = logoBitmap(); aiBtn.setImageBitmap(ib); }
        String key = keyOf(activeProfile);
        Set<String> con = connectedByKey.get(key);
        StringBuilder sig = new StringBuilder(key).append('#').append(cur);
        for (String[] p : providers) sig.append('|').append(p[0]).append(con != null && con.contains(p[0]) ? '1' : '0');
        if (sig.toString().equals(svcSig)) return;
        svcSig = sig.toString();
        svcRow.removeAllViews();
        for (final String[] p : providers) {
            boolean on = p[0].equals(cur), ok = con != null && con.contains(p[0]);
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL); chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setPadding(dp(5), 0, dp(11), 0); chip.setBackground(rounded(on ? C_ACCENT : C_SURFACE, 14));
            android.graphics.Bitmap bmp = aiIcon(p[0]);
            if (bmp != null) {
                android.widget.ImageView iv = new android.widget.ImageView(this);
                iv.setImageBitmap(bmp); iv.setAlpha(on || ok ? 1f : 0.7f);
                LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(18), dp(18)); ip.setMargins(0, 0, dp(6), 0);
                chip.addView(iv, ip);
            }
            TextView t = new TextView(this);
            t.setText((ok ? "\u2713 " : "") + p[1]); t.setTextSize(12); t.setGravity(Gravity.CENTER); t.setSingleLine(true);
            t.setTextColor(on ? Color.WHITE : (ok ? C_OK : C_MUTED));
            chip.addView(t, new LinearLayout.LayoutParams(-2, -2));
            chip.setOnClickListener(v -> openService(p[0]));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(32)); lp.setMargins(dp(2), 0, dp(2), 0);
            svcRow.addView(chip, lp);
        }
    }
    // AI logos shipped with the web app (www/ai/<id>.png -> assets/public/ai/<id>.png); null = no icon for that id
    private final Map<String, android.graphics.Bitmap> aiIcons = new HashMap<>();
    private android.graphics.Bitmap logoBitmap() {
        if (aiIcons.containsKey("_logo")) return aiIcons.get("_logo");
        android.graphics.Bitmap b = null;
        try (java.io.InputStream in = getAssets().open("public/logo-192.png")) { b = android.graphics.BitmapFactory.decodeStream(in); } catch (Exception ignored) { }
        aiIcons.put("_logo", b); return b;
    }
    private android.graphics.Bitmap aiIcon(String id) {
        if (aiIcons.containsKey(id)) return aiIcons.get(id);
        android.graphics.Bitmap b = null;
        try (java.io.InputStream in = getAssets().open("public/ai/" + id + ".png")) { b = android.graphics.BitmapFactory.decodeStream(in); } catch (Exception ignored) { }
        aiIcons.put(id, b); return b;
    }
    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radiusDp)); return g;
    }
    private void setLoadProgress(int p) {
        if (progressBar == null || webHost == null) return;
        if (p >= 100) { progressBar.setVisibility(View.GONE); return; }
        progressBar.setVisibility(View.VISIBLE);
        android.view.ViewGroup.LayoutParams lp = progressBar.getLayoutParams();
        lp.width = Math.max(dp(8), webHost.getWidth() * p / 100); progressBar.setLayoutParams(lp);
    }
    /** Shared by every page: loading bar + file chooser, so Upload / Choose file buttons open Android's file picker. */
    private WebChromeClient newChromeClient() {
        return new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) { if (v == webView || v == mailView) setLoadProgress(p); }
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb; camFile = null; camUri = null;
                try {
                    Intent launch = pickerIntent(params);
                    String[] acc = params.getAcceptTypes();
                    boolean any = acc == null || acc.length == 0, img = any;
                    if (!any) { boolean allEmpty = true; for (String a : acc) { if (a != null && !a.trim().isEmpty()) { allEmpty = false; if (a.contains("image") || a.contains("*/*")) img = true; } } if (allEmpty) img = true; }
                    Intent cam = img ? cameraIntent() : null;
                    if (cam != null) {
                        if (params.isCaptureEnabled()) launch = cam;
                        else { Intent ch = Intent.createChooser(launch, "Choose a file or take a photo"); ch.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam}); launch = ch; }
                    }
                    skipLockOnce = true;
                    startActivityForResult(launch, REQ_FILE);
                } catch (Exception e) { fileCb = null; cb.onReceiveValue(null); Toast.makeText(OrbitBrowserActivity.this, "No file picker available", Toast.LENGTH_SHORT).show(); return false; }
                return true;
            }
        };
    }
    /** Our own file-picker intent. Android's params.createIntent() never allows several files and only looks at the FIRST accept type, so 2+ files could not be picked. */
    private Intent pickerIntent(WebChromeClient.FileChooserParams params) {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        java.util.ArrayList<String> mimes = new java.util.ArrayList<>();
        boolean open = false; // true when an accept entry is not a plain MIME type or a known extension
        String[] acc = params.getAcceptTypes();
        if (acc != null) {
            for (String raw : acc) {
                if (raw == null) continue;
                for (String part : raw.split(",")) {
                    String t = part.trim().toLowerCase(java.util.Locale.US);
                    if (t.isEmpty()) continue;
                    if (t.startsWith(".")) {
                        String m = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(t.substring(1));
                        if (m == null) open = true; else if (!mimes.contains(m)) mimes.add(m);
                    } else if (t.contains("/")) { if (!mimes.contains(t)) mimes.add(t); }
                    else open = true;
                }
            }
        }
        // Filter the picker only for photos / videos / audio. For documents, zips and everything else show all files and let the website decide (a zip can carry several MIME types).
        boolean mediaOnly = !mimes.isEmpty() && !open;
        for (String m : mimes) { if (!(m.startsWith("image/") || m.startsWith("video/") || m.startsWith("audio/"))) mediaOnly = false; }
        if (mediaOnly && mimes.size() == 1) i.setType(mimes.get(0));
        else if (mediaOnly) { i.setType("*/*"); i.putExtra(Intent.EXTRA_MIME_TYPES, mimes.toArray(new String[0])); }
        else i.setType("*/*");
        if (params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        return i;
    }
    /** Copies the picked files into cache/orbit_up/<stamp>_<n>/<original name> and returns Orbit-owned FileProvider URIs. A file that cannot be copied keeps its original URI. Runs off the UI thread. */
    private Uri[] copyPicked(Uri[] in) {
        Uri[] out = new Uri[in.length];
        java.io.File root = new java.io.File(getCacheDir(), "orbit_up");
        root.mkdirs();
        long cutoff = System.currentTimeMillis() - 12L * 3600 * 1000; // tidy up copies older than 12 hours
        java.io.File[] old = root.listFiles();
        if (old != null) for (java.io.File d : old) { if (d.lastModified() < cutoff) deleteTree(d); }
        long stamp = System.currentTimeMillis();
        for (int n = 0; n < in.length; n++) {
            out[n] = in[n];
            try {
                String name = null; long size = -1;
                try (android.database.Cursor c = getContentResolver().query(in[n], new String[]{android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE}, null, null, null)) {
                    if (c != null && c.moveToFirst()) {
                        int i1 = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME), i2 = c.getColumnIndex(android.provider.OpenableColumns.SIZE);
                        if (i1 >= 0 && !c.isNull(i1)) name = c.getString(i1);
                        if (i2 >= 0 && !c.isNull(i2)) size = c.getLong(i2);
                    }
                } catch (Exception ignored) { }
                if (size > 300L * 1024 * 1024) continue; // very large: pass the original through, do not fill the phone
                if (name == null || name.trim().isEmpty()) { String last = in[n].getLastPathSegment(); name = last == null ? "file" : last; }
                name = name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_");
                if (name.length() > 120) name = name.substring(name.length() - 120);
                java.io.File dir = new java.io.File(root, stamp + "_" + n); dir.mkdirs();
                java.io.File f = new java.io.File(dir, name);
                try (java.io.InputStream is = getContentResolver().openInputStream(in[n]); java.io.OutputStream os = new java.io.FileOutputStream(f)) {
                    if (is == null) { deleteTree(dir); continue; }
                    byte[] buf = new byte[65536]; int r;
                    while ((r = is.read(buf)) > 0) os.write(buf, 0, r);
                }
                if (f.length() == 0 && size > 0) { deleteTree(dir); continue; } // copy came out empty: keep the original
                out[n] = androidx.core.content.FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            } catch (Throwable t) { out[n] = in[n]; }
        }
        return out;
    }
    private static void deleteTree(java.io.File f) {
        java.io.File[] k = f.listFiles();
        if (k != null) for (java.io.File c : k) deleteTree(c);
        f.delete();
    }
    /** Camera app intent that writes into our cache folder through the app's FileProvider; null if that is not possible (the picker still works). */
    private Intent cameraIntent() {
        try {
            java.io.File dir = new java.io.File(getCacheDir(), "orbit_cam"); dir.mkdirs();
            java.io.File f = new java.io.File(dir, "photo_" + System.currentTimeMillis() + ".jpg");
            Uri u = androidx.core.content.FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            Intent c = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            c.putExtra(MediaStore.EXTRA_OUTPUT, u);
            c.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            camFile = f; camUri = u; lastCamFile = f; lastCamUri = u;
            return c;
        } catch (Throwable t) { camFile = null; camUri = null; return null; }
    }
    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE) {
            final ValueCallback<Uri[]> cb = fileCb; fileCb = null;
            final boolean fromCamera = camUri != null;
            camFile = null; camUri = null;
            if (cb == null) return;
            Uri[] result = null;
            if (res == RESULT_OK) {
                result = WebChromeClient.FileChooserParams.parseResult(res, data);
                if (result == null && data != null) { // some pickers answer in a way parseResult does not read: read it ourselves
                    android.content.ClipData cd = data.getClipData();
                    if (cd != null && cd.getItemCount() > 0) {
                        java.util.ArrayList<Uri> l = new java.util.ArrayList<>();
                        for (int k = 0; k < cd.getItemCount(); k++) { Uri u = cd.getItemAt(k).getUri(); if (u != null) l.add(u); }
                        if (!l.isEmpty()) result = l.toArray(new Uri[0]);
                    } else if (data.getData() != null) result = new Uri[]{data.getData()};
                }
                if (result == null && fromCamera && lastCamFile != null && lastCamFile.length() > 0) result = new Uri[]{lastCamUri}; // photo from the camera
            }
            if (result == null || result.length == 0) { cb.onReceiveValue(null); return; }
            if (fromCamera && result.length == 1 && result[0].equals(lastCamUri)) { cb.onReceiveValue(result); return; } // our own camera file: nothing to copy
            // Copy every picked file into Orbit's own cache and hand the page Orbit-owned URIs. Pickers on some phones give the page
            // URIs it cannot read (blank tile, endless loading, 2+ files lost); our own copy is always readable.
            final Uri[] picked = result;
            Toast.makeText(this, picked.length == 1 ? "Adding file…" : "Adding " + picked.length + " files…", Toast.LENGTH_SHORT).show();
            new Thread(() -> {
                final Uri[] out = copyPicked(picked);
                runOnUiThread(() -> cb.onReceiveValue(out));
            }).start();
            return;
        }
        if (req == REQ_UNLOCK) {
            if (res == RESULT_OK) unlocked(); else finish();
            return;
        }
        if (req == REQ_TREE) {
            if (res == RESULT_OK && data != null && data.getData() != null) setCustomDir(treeKey, treePid, data.getData());
            return;
        }
        super.onActivityResult(req, res, data);
    }
    // ---- App lock ----
    private void checkLock() {
        if (skipLockOnce) { skipLockOnce = false; return; }
        if (locked || !prefs.getBoolean("app_lock", false)) return;
        long last = OrbitBrowserPlugin.lastActive;
        if (last != 0 && System.currentTimeMillis() - last < 30000) return;
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        Intent i = (km != null && km.isDeviceSecure()) ? km.createConfirmDeviceCredentialIntent("Orbit Browser", "Unlock to continue") : null;
        if (i == null) return; // the phone has no screen lock: nothing to ask for
        locked = true;
        lockCover = new View(this); lockCover.setBackgroundColor(Color.BLACK);
        addContentView(lockCover, new android.view.ViewGroup.LayoutParams(-1, -1));
        try { startActivityForResult(i, REQ_UNLOCK); } catch (Exception e) { unlocked(); }
    }
    private void unlocked() {
        locked = false; OrbitBrowserPlugin.lastActive = System.currentTimeMillis();
        if (lockCover != null && lockCover.getParent() instanceof android.view.ViewGroup) ((android.view.ViewGroup) lockCover.getParent()).removeView(lockCover);
        lockCover = null;
    }
    // ---- Google blocks sign-in inside in-app browsers. Orbit does not disguise itself to get around that; it explains and offers a way out. ----
    private void checkGoogleBlock(String url, String forProfile) {
        if (url == null || forProfile == null || !url.contains("accounts.google.com")) return;
        String low = url.toLowerCase();
        if (!(low.contains("disallowed_useragent") || low.contains("/signin/rejected") || low.contains("deniedsigninrejected") || low.contains("/signin/oauth/error"))) return;
        if (!googleWarned.add(forProfile)) return;
        showGoogleBlocked(forProfile);
    }
    private void showGoogleBlocked(final String profile) {
        if (isFinishing()) return;
        final String pid = "gemini";
        final String aliasId = links.optString(profile, "");
        LinearLayout b = openSheet("Google sign-in", "Gemini and \"Sign in with Google\"");
        b.addView(infoCard("\u26A0", "Google may refuse sign-in here", "Google does not allow sign-in inside in-app browsers like this one. Orbit does not hide itself to get around that.", C_WARN));
        b.addView(sectionLabel("What works"));
        b.addView(stepCard(1, "Sign in with email and password, or an email code, on sites that offer it."));
        b.addView(stepCard(2, "For Gemini: sign in with Chrome first."));
        b.addView(stepCard(3, aliasId.isEmpty() ? "Then mark Gemini as signed in yourself: long-press its chip in the Orbit dashboard." : "Then tap \"Mark Gemini as signed in\" below."));
        b.addView(primaryButton("Open Gemini in Chrome", () -> { try { Intent v = new Intent(Intent.ACTION_VIEW, Uri.parse("https://gemini.google.com/app")); v.addCategory(Intent.CATEGORY_BROWSABLE); startActivity(v); } catch (Exception e) { Toast.makeText(this, "No browser found", Toast.LENGTH_SHORT).show(); } }));
        if (!aliasId.isEmpty()) b.addView(menuRow("\u2713", "Mark Gemini as signed in", null, false, () -> {
            try { queueEvent(new JSONObject().put("type", "mark").put("aliasId", aliasId).put("service", pid).put("ts", System.currentTimeMillis())); Toast.makeText(this, "Gemini marked as signed in for " + linkedEmail(profile), Toast.LENGTH_SHORT).show(); } catch (Exception ignored) { }
        }));
        showSheet();
    }
    // ---- Downloads: normal links through Android's DownloadManager (with this profile's cookies), blob:/data: files through a small bridge ----
    public final class DlBridge {
        volatile boolean allowed = false; volatile String blobUrl = "", cd = "", sub = "Orbit", proj = ""; volatile Uri tree; java.io.File tmp; long total = 0;
        @JavascriptInterface public void chunk(int i, int n, String b64) {
            if (!allowed) return;
            try {
                if (i == 0) { tmp = new java.io.File(getCacheDir(), "orbit_dl.tmp"); total = 0; if (tmp.exists()) tmp.delete(); }
                if (tmp == null) return;
                byte[] bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
                total += bytes.length;
                if (total > 80L * 1024 * 1024) { tmp.delete(); tmp = null; toastUi("File is too large (max 80 MB)"); return; }
                try (java.io.FileOutputStream fo = new java.io.FileOutputStream(tmp, true)) { fo.write(bytes); }
            } catch (Exception e) { tmp = null; }
        }
        @JavascriptInterface public void done(String mime) {
            if (!allowed || tmp == null) return;
            java.io.File f = tmp; tmp = null;
            String mt = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
            saveToDownloads(f, URLUtil.guessFileName(blobUrl, cd, mt), mt, sub, tree, proj);
        }
        @JavascriptInterface public void fail(String msg) { toastUi("Download failed"); }
    }
    private void toastUi(final String msg) { runOnUiThread(() -> Toast.makeText(OrbitBrowserActivity.this, msg, Toast.LENGTH_LONG).show()); }
    private boolean trustedHost(String url) {
        if (url == null) return false;
        if (providerIdForUrl(url) != null) return true;
        try { String h = Uri.parse(url).getHost(); return h != null && (h.equals("mail.google.com") || h.endsWith(".googleusercontent.com")); } catch (Exception e) { return false; }
    }
    // ---- Step 12c: simple file manager for Downloads/Orbit (list, date/time, size, NEW badge, newest first). Delete/rename = 12d. ----
    private static final class FRow { String rel = "", name = ""; long size, modMs, id; java.io.File file; }
    private AlertDialog filesDlg;
    private static final long DAY_MS = 24L * 3600L * 1000L;
    private static String fmtSize(long b) {
        if (b < 1024) return b + " B";
        double k = b / 1024.0; if (k < 1024) return String.format(java.util.Locale.US, "%.0f KB", k);
        double m = k / 1024.0; if (m < 1024) return String.format(java.util.Locale.US, "%.1f MB", m);
        return String.format(java.util.Locale.US, "%.2f GB", m / 1024.0);
    }
    private static String fmtDate(long ms) {
        return ms <= 0 ? "?" : new java.text.SimpleDateFormat("MMM d, yyyy h:mm a", java.util.Locale.getDefault()).format(new java.util.Date(ms));
    }
    /** Batch 4c: one or two lines of text with an optional leading icon (ImageSpan). The second line is small and muted; "New · " is green.
     *  If the icon is missing the old text glyph is shown instead, so a row is never blank. */
    private CharSequence rowLine(String glyph, String a, String b, boolean isNew, int iconColor) {
        android.graphics.drawable.Drawable d = glyph == null ? null : iconDrawable(glyph, iconColor);
        String lead = d != null ? "\uFFFC  " : (glyph != null ? glyph + "  " : "");
        String second = (b == null || b.isEmpty()) ? "" : (isNew ? "New · " : "") + b;
        android.text.SpannableString ss = new android.text.SpannableString(lead + a + (second.isEmpty() ? "" : "\n" + second));
        if (d != null) {
            d.setBounds(0, 0, dp(20), dp(20));
            ss.setSpan(new android.text.style.ImageSpan(d, android.text.style.ImageSpan.ALIGN_BASELINE), 0, 1, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        if (!second.isEmpty()) {
            int st = lead.length() + a.length() + 1;
            ss.setSpan(new android.text.style.RelativeSizeSpan(0.8f), st, ss.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            ss.setSpan(new android.text.style.ForegroundColorSpan(C_MUTED), st, ss.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (isNew) ss.setSpan(new android.text.style.ForegroundColorSpan(C_OK), st, st + 5, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        return ss;
    }
    private CharSequence twoLine(String a, String b, boolean isNew) { return rowLine(null, a, b, isNew, C_MUTED); }
    /** Every file under Downloads/Orbit that this app can see (Android 10+: MediaStore; older: the app's own Downloads/Orbit folder). Run off the UI thread. */
    private List<FRow> queryFiles() {
        List<FRow> out = new ArrayList<>();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                String[] proj = { MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.RELATIVE_PATH, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_MODIFIED, MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns._ID };
                String base = Environment.DIRECTORY_DOWNLOADS + "/Orbit/";
                try (android.database.Cursor c = getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, proj, MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?", new String[]{ base + "%" }, null)) {
                    if (c != null) while (c.moveToNext()) {
                        String nm = c.getString(0), rp = c.getString(1);
                        if (nm == null || rp == null || !rp.startsWith(base)) continue;
                        FRow r = new FRow(); r.name = nm; r.rel = rp.substring(base.length()); r.size = c.getLong(2);
                        long m = c.getLong(3), a = c.getLong(4); r.modMs = (m > 0 ? m : a) * 1000L; r.id = c.getLong(5);
                        out.add(r);
                    }
                }
            } else {
                java.io.File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (dir != null) walkLegacy(new java.io.File(dir, "Orbit"), "", out);
            }
        } catch (Exception e) { toastUi("Could not list files: " + e.getMessage()); }
        return out;
    }
    private void walkLegacy(java.io.File d, String rel, List<FRow> out) {
        java.io.File[] ls = d.listFiles(); if (ls == null) return;
        for (java.io.File f : ls) {
            if (f.isDirectory()) walkLegacy(f, rel + f.getName() + "/", out);
            else { FRow r = new FRow(); r.name = f.getName(); r.rel = rel; r.size = f.length(); r.modMs = f.lastModified(); r.file = f; out.add(r); }
        }
    }
    private void openFiles(final String cur) {
        Toast.makeText(this, "Loading files…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            final List<FRow> rows = queryFiles();
            runOnUiThread(() -> { if (!isFinishing()) showFiles(rows, cur); });
        }).start();
    }
    private void showFiles(final List<FRow> rows, final String cur) {
        if (filesDlg != null) { try { filesDlg.dismiss(); } catch (Exception ignored) { } filesDlg = null; }
        final long now = System.currentTimeMillis();
        final Map<String, long[]> folders = new HashMap<>();   // folder name -> {file count, latest modified, total size}
        final List<FRow> files = new ArrayList<>();
        for (FRow r : rows) {
            if (!r.rel.startsWith(cur)) continue;
            if (r.rel.length() == cur.length()) { files.add(r); continue; }
            String rest = r.rel.substring(cur.length());
            int sl = rest.indexOf('/'); String seg = sl < 0 ? rest : rest.substring(0, sl);
            if (seg.isEmpty()) continue;
            long[] f = folders.get(seg); if (f == null) { f = new long[3]; folders.put(seg, f); }
            f[0]++; f[1] = Math.max(f[1], r.modMs); f[2] += r.size;
        }
        final List<String> fnames = new ArrayList<>(folders.keySet());
        java.util.Collections.sort(fnames, (a, b) -> Long.compare(folders.get(b)[1], folders.get(a)[1]));
        java.util.Collections.sort(files, (a, b) -> Long.compare(b.modMs, a.modMs));
        final List<CharSequence> items = new ArrayList<>();
        final List<Object> targets = new ArrayList<>();   // Boolean.TRUE = up, Boolean.FALSE = empty note, String = folder name, FRow = file
        if (!cur.isEmpty()) { items.add(rowLine("\u2B06", "Parent folder", null, false, C_MUTED)); targets.add(Boolean.TRUE); }
        for (String fn : fnames) {
            long[] f = folders.get(fn);
            items.add(rowLine("\uD83D\uDCC1", fn, f[0] + (f[0] == 1 ? " file" : " files") + " · " + fmtSize(f[2]) + " · updated " + fmtDate(f[1]), now - f[1] < DAY_MS, C_CYAN));
            targets.add(fn);
        }
        for (FRow r : files) {
            items.add(rowLine("\uD83D\uDCC4", r.name, fmtDate(r.modMs) + " · " + fmtSize(r.size), now - r.modMs < DAY_MS, C_MUTED));
            targets.add(r);
        }
        if (fnames.isEmpty() && files.isEmpty()) { items.add(rowLine("\uD83D\uDCC2", "No files yet", "Files you download in Orbit will appear here.", false, C_MUTED)); targets.add(Boolean.FALSE); }
        String where = cur.isEmpty() ? "" : " / " + cur.substring(0, cur.length() - 1).replace("/", " / ");
        filesDlg = dlg().setTitle("Orbit files" + where)
            .setItems(items.toArray(new CharSequence[0]), (d, w) -> {
                Object t = targets.get(w);
                if (t instanceof FRow) { showFileInfo(rows, cur, (FRow) t); }
                else if (t instanceof String) { showFiles(rows, cur + (String) t + "/"); }
                else if (Boolean.TRUE.equals(t)) {
                    String up = cur.substring(0, cur.length() - 1); int i = up.lastIndexOf('/');
                    showFiles(rows, i < 0 ? "" : up.substring(0, i + 1));
                } else showFiles(rows, cur);
            })
            .setPositiveButton("Delete…", (d, w) -> showMultiDelete(rows, cur, fnames, files))
            .setNeutralButton("Refresh", (d, w) -> openFiles(cur))
            .setNegativeButton("Close", null).create();
        filesDlg.show();
        try {
            filesDlg.getListView().setOnItemLongClickListener((parent, itemView, pos, rowId) -> {
                if (pos >= 0 && pos < targets.size() && targets.get(pos) instanceof String) { showFolderMenu(rows, cur, (String) targets.get(pos)); return true; }
                return false;
            });
        } catch (Exception ignored) { }
    }
    private void showFileInfo(final List<FRow> rows, final String cur, final FRow r) {
        String msg = r.name + "\n\nLocation: Downloads/Orbit/" + r.rel + "\nUpdated: " + fmtDate(r.modMs) + "\nSize: " + fmtSize(r.size)
            + (System.currentTimeMillis() - r.modMs < DAY_MS ? "\n\nNew: downloaded in the last 24 hours" : "");
        dlg().setTitle("File").setMessage(msg)
            .setPositiveButton("Back", (d, w) -> showFiles(rows, cur))
            .setNeutralButton("Rename", (d, w) -> askRenameFile(rows, cur, r))
            .setNegativeButton("Delete", (d, w) -> confirmDeleteFiles(rows, cur, new ArrayList<String>(), java.util.Collections.singletonList(r)))
            .setOnCancelListener(d -> showFiles(rows, cur)).show();
    }
    // ---- Step 12d: delete (one / many / whole folder) and rename (file / folder). Rename has NO extension warning (user's choice). ----
    private static String safeFileName(String s) {
        String r = (s == null ? "" : s).replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (r.length() > 120) r = r.substring(0, 120).trim();
        return r.isEmpty() ? "file" : r;
    }
    private Uri rowUri(FRow r) { return android.content.ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, r.id); }
    /** null = deleted, otherwise the reason. */
    private String deleteRow(FRow r) {
        try {
            if (r.file != null) return r.file.delete() ? null : "could not delete";
            return getContentResolver().delete(rowUri(r), null, null) > 0 ? null : "not found";
        } catch (SecurityException e) { return "not allowed (file was not created by Orbit)"; }
        catch (Exception e) { return String.valueOf(e.getMessage()); }
    }
    /** null = renamed, otherwise the reason. */
    private String renameRow(FRow r, String newName) {
        try {
            if (r.file != null) return r.file.renameTo(new java.io.File(r.file.getParentFile(), newName)) ? null : "could not rename";
            android.content.ContentValues cv = new android.content.ContentValues(); cv.put(MediaStore.MediaColumns.DISPLAY_NAME, newName);
            return getContentResolver().update(rowUri(r), cv, null, null) > 0 ? null : "not found";
        } catch (SecurityException e) { return "not allowed (file was not created by Orbit)"; }
        catch (Exception e) { return String.valueOf(e.getMessage()); }
    }
    private String moveRow(FRow r, String newRel) {
        try {
            android.content.ContentValues cv = new android.content.ContentValues();
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Orbit/" + newRel);
            return getContentResolver().update(rowUri(r), cv, null, null) > 0 ? null : "not found";
        } catch (SecurityException e) { return "not allowed (file was not created by Orbit)"; }
        catch (Exception e) { return String.valueOf(e.getMessage()); }
    }
    private void askRenameFile(final List<FRow> rows, final String cur, final FRow r) {
        final EditText in = new EditText(this); in.setSingleLine(true); in.setText(r.name);
        int dot = r.name.lastIndexOf('.'); in.setSelection(0, dot > 0 ? dot : r.name.length());
        dlg().setTitle("Rename file").setView(in)
            .setPositiveButton("Rename", (d, w) -> {
                final String nn = safeFileName(in.getText().toString());
                if (nn.equals(r.name)) { showFiles(rows, cur); return; }
                for (FRow x : rows) if (x != r && x.rel.equals(r.rel) && x.name.equalsIgnoreCase(nn)) { toastUi("A file named \"" + nn + "\" already exists here"); showFiles(rows, cur); return; }
                new Thread(() -> { String err = renameRow(r, nn); toastUi(err == null ? "Renamed" : "Could not rename: " + err); runOnUiThread(() -> openFiles(cur)); }).start();
            })
            .setNegativeButton("Cancel", (d, w) -> showFiles(rows, cur))
            .setOnCancelListener(d -> showFiles(rows, cur)).show();
    }
    private void showFolderMenu(final List<FRow> rows, final String cur, final String name) {
        String[] items = { "Rename folder", "Delete folder…" };
        dlg().setTitle(name).setItems(items, (d, w) -> {
            if (w == 0) askRenameFolder(rows, cur, name);
            else confirmDeleteFiles(rows, cur, java.util.Collections.singletonList(name), new ArrayList<FRow>());
        }).setNegativeButton("Cancel", null).show();
    }
    private void askRenameFolder(final List<FRow> rows, final String cur, final String name) {
        final EditText in = new EditText(this); in.setSingleLine(true); in.setText(name); in.setSelection(name.length());
        AlertDialog.Builder b = dlg().setTitle("Rename folder").setView(in);
        if (cur.split("/").length < 2) b.setMessage("Note: new downloads still use the profile / AI name, so this folder name will be created again by the next download.");
        b.setPositiveButton("Rename", (d, w) -> {
            final String nn = safeDirName(in.getText().toString());
            if (nn.equals(name)) { showFiles(rows, cur); return; }
            final String oldPre = cur + name + "/", newPre = cur + nn + "/";
            if (!nn.equalsIgnoreCase(name)) for (FRow x : rows) if (x.rel.toLowerCase().startsWith(newPre.toLowerCase())) { toastUi("A folder named \"" + nn + "\" already exists here"); showFiles(rows, cur); return; }
            new Thread(() -> {
                int ok = 0, bad = 0; String why = "";
                if (Build.VERSION.SDK_INT < 29) {
                    java.io.File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    java.io.File from = new java.io.File(new java.io.File(dir, "Orbit"), oldPre), to = new java.io.File(new java.io.File(dir, "Orbit"), newPre);
                    if (from.renameTo(to)) ok = 1; else { bad = 1; why = "could not rename"; }
                } else {
                    for (FRow x : rows) if (x.rel.startsWith(oldPre)) {
                        String err = moveRow(x, newPre + x.rel.substring(oldPre.length()));
                        if (err == null) ok++; else { bad++; why = err; }
                    }
                }
                if (ok > 0) renameProjectInPrefs(cur, name, nn);
                toastUi(bad == 0 ? "Folder renamed" : "Renamed " + ok + ", failed " + bad + ": " + why);
                runOnUiThread(() -> openFiles(cur));
            }).start();
        });
        b.setNegativeButton("Cancel", (d, w) -> showFiles(rows, cur)).setOnCancelListener(d -> showFiles(rows, cur)).show();
    }
    /** If the renamed folder is a project folder (Account/AI/Project), keep the project list in step so downloads keep going there. */
    private void renameProjectInPrefs(String cur, String oldName, String newName) {
        try {
            String[] seg = cur.split("/"); if (seg.length != 2) return;
            String key = null, pid = null;
            for (String n : profileNames) if (safeDirName(n).equals(seg[0])) key = keyOf(n);
            for (String[] p : providers) if (safeDirName(p[1]).equals(seg[1])) pid = p[0];
            if (key == null || pid == null) return;
            List<String> list = projectList(key, pid); String act = activeProject(key, pid); boolean changed = false;
            for (int i = 0; i < list.size(); i++) if (list.get(i).equals(oldName)) { list.set(i, newName); changed = true; }
            if (changed) saveProject(key, pid, list, act.equals(oldName) ? newName : act);
        } catch (Exception ignored) { }
    }
    private void showMultiDelete(final List<FRow> rows, final String cur, final List<String> fnames, final List<FRow> files) {
        final int nf = fnames.size(), total = nf + files.size();
        if (total == 0) { showFiles(rows, cur); return; }
        final CharSequence[] labels = new CharSequence[total];
        for (int i = 0; i < total; i++) labels[i] = i < nf ? rowLine("\uD83D\uDCC1", fnames.get(i), "Folder and everything in it", false, C_CYAN) : rowLine("\uD83D\uDCC4", files.get(i - nf).name, fmtSize(files.get(i - nf).size), false, C_MUTED);
        final boolean[] chk = new boolean[total];
        dlg().setTitle("Select what to delete")
            .setMultiChoiceItems(labels, chk, (d, w, on) -> chk[w] = on)
            .setPositiveButton("Delete selected", (d, w) -> {
                List<String> fs = new ArrayList<>(); List<FRow> fl = new ArrayList<>();
                for (int i = 0; i < total; i++) if (chk[i]) { if (i < nf) fs.add(fnames.get(i)); else fl.add(files.get(i - nf)); }
                if (fs.isEmpty() && fl.isEmpty()) { showFiles(rows, cur); return; }
                confirmDeleteFiles(rows, cur, fs, fl);
            })
            .setNegativeButton("Cancel", (d, w) -> showFiles(rows, cur))
            .setOnCancelListener(d -> showFiles(rows, cur)).show();
    }
    private void confirmDeleteFiles(final List<FRow> rows, final String cur, final List<String> folderNames, final List<FRow> fileRows) {
        final List<FRow> targets = new ArrayList<>(fileRows);
        for (String fn : folderNames) { String pre = cur + fn + "/"; for (FRow x : rows) if (x.rel.startsWith(pre)) targets.add(x); }
        long size = 0; for (FRow x : targets) size += x.size;
        String what = (folderNames.isEmpty() ? "" : folderNames.size() + (folderNames.size() == 1 ? " folder" : " folders") + (fileRows.isEmpty() ? "" : " + "))
            + (fileRows.isEmpty() ? "" : fileRows.size() + (fileRows.size() == 1 ? " file" : " files"));
        String msg = "Delete " + what + "?\n\n" + targets.size() + (targets.size() == 1 ? " file" : " files in total") + " · " + fmtSize(size)
            + (targets.size() == 1 ? "\n" + targets.get(0).name : "") + "\n\nThis cannot be undone. The files are removed from your phone.";
        dlg().setTitle("Delete").setMessage(msg)
            .setPositiveButton("Delete", (d, w) -> new Thread(() -> {
                int ok = 0, bad = 0; String why = "";
                for (FRow x : targets) { String err = deleteRow(x); if (err == null) ok++; else { bad++; why = err; } }
                toastUi(bad == 0 ? "Deleted " + ok + (ok == 1 ? " file" : " files") : "Deleted " + ok + ", failed " + bad + ": " + why);
                runOnUiThread(() -> openFiles(cur));
            }).start())
            .setNegativeButton("Cancel", (d, w) -> showFiles(rows, cur))
            .setOnCancelListener(d -> showFiles(rows, cur)).show();
    }
    // ---- Step 12e: custom download folder per account + AI (Android folder picker / SAF). prefs "custom_dirs" = {"<profileKey>|<aiId>": "<tree uri>"} ----
    private JSONObject loadCustomDirs() { try { return new JSONObject(prefs.getString("custom_dirs", "{}")); } catch (Exception e) { return new JSONObject(); } }
    private Uri customTree(String key, String pid) {
        if (key == null || pid == null) return null;
        String u = loadCustomDirs().optString(key + "|" + pid, "");
        if (u.isEmpty()) return null;
        try {
            Uri t = Uri.parse(u);
            for (android.content.UriPermission up : getContentResolver().getPersistedUriPermissions()) if (up.getUri().equals(t) && up.isWritePermission()) return t;
        } catch (Exception ignored) { }
        return null;   // permission lost -> default folder
    }
    private Uri customTreeFor(WebView v, String key) {
        try {
            if (MAIL_KEY.equals(key)) return null;
            return customTree(key, providerIdForUrl(v == null ? null : v.getUrl()));
        } catch (Exception e) { return null; }
    }
    private String projectFor(WebView v, String key) {
        try {
            String pid = providerIdForUrl(v == null ? null : v.getUrl());
            if (pid == null) return "";
            String p = activeProject(key, pid);
            return p.isEmpty() ? "" : safeDirName(p);
        } catch (Exception e) { return ""; }
    }
    private String treeLabel(Uri tree) {
        try { String id = android.provider.DocumentsContract.getTreeDocumentId(tree); int c = id.indexOf(':'); String r = c >= 0 ? id.substring(c + 1) : id; return r.isEmpty() ? "Internal storage" : r; }
        catch (Exception e) { return "your folder"; }
    }
    private void dropCustomDirs(String key) {
        try {
            JSONObject all = loadCustomDirs(); List<String> rm = new ArrayList<>();
            java.util.Iterator<String> it = all.keys();
            while (it.hasNext()) { String k = it.next(); if (k.startsWith(key + "|")) rm.add(k); }
            for (String k : rm) { try { getContentResolver().releasePersistableUriPermission(Uri.parse(all.optString(k, "")), Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); } catch (Exception ignored) { } all.remove(k); }
            prefs.edit().putString("custom_dirs", all.toString()).apply();
        } catch (Exception ignored) { }
    }
    private void pickCustomDir() {
        final String key = keyOf(activeProfile);
        final String pid = (!mailMode && webView != null) ? providerIdForUrl(webView.getUrl()) : null;
        if (pid == null) { showMessage("Open an AI site first (Claude, ChatGPT, Gemini…). A custom folder belongs to one account and one AI."); return; }
        final Uri cur = customTree(key, pid);
        final String[] items = cur == null ? new String[]{ "Choose a folder…" } : new String[]{ "Choose a different folder…", "Use the default (Downloads/Orbit)" };
        final String now = cur == null ? "default (Downloads/Orbit/" + safeDirName(activeProfile) + "/" + safeDirName(providerName(pid)) + ")" : treeLabel(cur) + " (projects are made inside it)";
        dlg().setTitle(activeProfile + " · " + providerName(pid) + "\nNow: " + now)
            .setItems(items, (d, w) -> {
                if (w == 0) {
                    treeKey = key; treePid = pid;
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                    skipLockOnce = true;
                    try { startActivityForResult(i, REQ_TREE); } catch (Exception e) { skipLockOnce = false; toastUi("No folder picker found on this phone"); }
                } else clearCustomDir(key, pid);
            }).setNegativeButton("Close", null).show();
    }
    private void setCustomDir(String key, String pid, Uri tree) {
        if (key == null || key.isEmpty() || pid == null || pid.isEmpty()) return;
        try {
            getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            JSONObject all = loadCustomDirs();
            String old = all.optString(key + "|" + pid, "");
            all.put(key + "|" + pid, tree.toString());
            prefs.edit().putString("custom_dirs", all.toString()).apply();
            if (!old.isEmpty() && !old.equals(tree.toString())) { try { getContentResolver().releasePersistableUriPermission(Uri.parse(old), Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); } catch (Exception ignored) { } }
            toastUi("Downloads of " + providerName(pid) + " → " + treeLabel(tree));
        } catch (Exception e) { toastUi("Could not use that folder: " + e.getMessage()); }
    }
    private void clearCustomDir(String key, String pid) {
        try {
            JSONObject all = loadCustomDirs(); String old = all.optString(key + "|" + pid, "");
            all.remove(key + "|" + pid);
            prefs.edit().putString("custom_dirs", all.toString()).apply();
            if (!old.isEmpty()) { try { getContentResolver().releasePersistableUriPermission(Uri.parse(old), Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); } catch (Exception ignored) { } }
            toastUi("Back to Downloads/Orbit");
        } catch (Exception ignored) { }
    }
    /** Child folder of a picked tree (existing one is reused). */
    private Uri childDir(Uri tree, Uri parent, String dirName) throws Exception {
        Uri kids = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, android.provider.DocumentsContract.getDocumentId(parent));
        String[] proj = { android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID, android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME, android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE };
        try (android.database.Cursor c = getContentResolver().query(kids, proj, null, null, null)) {
            if (c != null) while (c.moveToNext())
                if (dirName.equals(c.getString(1)) && android.provider.DocumentsContract.Document.MIME_TYPE_DIR.equals(c.getString(2)))
                    return android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0));
        }
        Uri d = android.provider.DocumentsContract.createDocument(getContentResolver(), parent, android.provider.DocumentsContract.Document.MIME_TYPE_DIR, dirName);
        if (d == null) throw new java.io.IOException("cannot create the project folder");
        return d;
    }
    /** Copies a finished temp file into the picked folder (inside the project sub-folder if one is active). Deletes the temp file on success. */
    private void saveToTree(java.io.File f, String name, Uri tree, String proj) throws Exception {
        Uri parent = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, android.provider.DocumentsContract.getTreeDocumentId(tree));
        if (proj != null && !proj.isEmpty()) parent = childDir(tree, parent, proj);
        Uri doc = android.provider.DocumentsContract.createDocument(getContentResolver(), parent, "application/octet-stream", name);
        if (doc == null) throw new java.io.IOException("cannot create the file there");
        try (java.io.InputStream in = new java.io.FileInputStream(f); java.io.OutputStream o = getContentResolver().openOutputStream(doc)) {
            if (o == null) throw new java.io.IOException("cannot write there");
            byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        }
        f.delete();
    }
    /** Normal link download into a picked folder: DownloadManager cannot write there, so Orbit downloads it itself (with the profile's cookies). */
    private void downloadToCustom(final String url, final String ua, final String cookie, final String name, final String mime, final String sub, final Uri tree, final String proj) {
        toastUi("Downloading " + name + " …");
        new Thread(() -> {
            java.io.File tmp = new java.io.File(getCacheDir(), "orbit_dl_" + System.currentTimeMillis() + ".tmp");
            java.net.HttpURLConnection con = null;
            try {
                con = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                con.setConnectTimeout(20000); con.setReadTimeout(60000); con.setInstanceFollowRedirects(true);
                if (cookie != null && !cookie.isEmpty()) con.setRequestProperty("Cookie", cookie);
                if (ua != null && !ua.isEmpty()) con.setRequestProperty("User-Agent", ua);
                int code = con.getResponseCode();
                if (code < 200 || code >= 300) throw new java.io.IOException("HTTP " + code);
                long total = 0;
                try (java.io.InputStream in = con.getInputStream(); java.io.FileOutputStream fo = new java.io.FileOutputStream(tmp)) {
                    byte[] buf = new byte[65536]; int n;
                    while ((n = in.read(buf)) > 0) { total += n; if (total > 500L * 1024 * 1024) throw new java.io.IOException("file is larger than 500 MB"); fo.write(buf, 0, n); }
                }
                saveToDownloads(tmp, name, (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime, sub, tree, proj);
            } catch (Exception e) { tmp.delete(); toastUi("Could not download: " + e.getMessage()); }
            finally { if (con != null) con.disconnect(); }
        }).start();
    }
    // ---- Step 12b: project folders. Saved per profile KEY + AI id (so renaming a profile keeps them). prefs "projects" = {"<key>|<aiId>": {"list":[names], "active":"name"}} ----
    private JSONObject loadProjects() { try { return new JSONObject(prefs.getString("projects", "{}")); } catch (Exception e) { return new JSONObject(); } }
    private String activeProject(String key, String pid) {
        if (key == null || pid == null) return "";
        JSONObject o = loadProjects().optJSONObject(key + "|" + pid);
        return o == null ? "" : o.optString("active", "");
    }
    private List<String> projectList(String key, String pid) {
        List<String> out = new ArrayList<>();
        JSONObject o = loadProjects().optJSONObject(key + "|" + pid);
        JSONArray a = o == null ? null : o.optJSONArray("list");
        if (a != null) for (int i = 0; i < a.length(); i++) { String n = a.optString(i, "").trim(); if (!n.isEmpty()) out.add(n); }
        return out;
    }
    private void saveProject(String key, String pid, List<String> list, String active) {
        try {
            JSONObject all = loadProjects(), o = new JSONObject();
            JSONArray a = new JSONArray(); for (String n : list) a.put(n);
            o.put("list", a); o.put("active", active == null ? "" : active);
            all.put(key + "|" + pid, o);
            prefs.edit().putString("projects", all.toString()).apply();
        } catch (Exception ignored) { }
    }
    private void dropProjects(String key) {
        try {
            JSONObject all = loadProjects(); List<String> rm = new ArrayList<>();
            java.util.Iterator<String> it = all.keys();
            while (it.hasNext()) { String k = it.next(); if (k.startsWith(key + "|")) rm.add(k); }
            for (String k : rm) all.remove(k);
            prefs.edit().putString("projects", all.toString()).apply();
        } catch (Exception ignored) { }
    }
    /** Menu: choose where this account's downloads of the AI on screen go (AI folder itself, or a project folder inside it). */
    private void pickProject() {
        final String key = keyOf(activeProfile);
        final String pid = (!mailMode && webView != null) ? providerIdForUrl(webView.getUrl()) : null;
        if (pid == null) { showMessage("Open an AI site first (Claude, ChatGPT, Gemini…). A project belongs to one account and one AI."); return; }
        final List<String> list = projectList(key, pid);
        final String active = activeProject(key, pid);
        final int n = list.size();
        final CharSequence[] labels = new CharSequence[n + 2 + (n > 0 ? 1 : 0)];
        labels[0] = rowLine("\u2B07", "No project", (active.isEmpty() ? "In use · " : "") + providerName(pid) + " folder", false, active.isEmpty() ? C_CYAN : C_MUTED);
        for (int i = 0; i < n; i++) labels[i + 1] = rowLine("\uD83D\uDCC1", list.get(i), list.get(i).equals(active) ? "In use" : null, false, list.get(i).equals(active) ? C_CYAN : C_MUTED);
        labels[n + 1] = rowLine("\uFF0B", "New project…", null, false, C_TEXT);
        if (n > 0) labels[n + 2] = rowLine("\u2715", "Remove a project from the list…", "The files stay on your phone", false, C_MUTED);
        dlg().setTitle(activeProfile + " · " + providerName(pid) + " downloads").setItems(labels, (d, w) -> {
            if (w == 0) { saveProject(key, pid, list, ""); toastUi("Downloads → " + providerName(pid) + " folder"); }
            else if (w <= n) { saveProject(key, pid, list, list.get(w - 1)); toastUi("Downloads → " + list.get(w - 1)); }
            else if (w == n + 1) askNewProject(key, pid);
            else askRemoveProject(key, pid);
        }).setNegativeButton("Close", null).show();
    }
    private void askNewProject(final String key, final String pid) {
        final EditText in = new EditText(this); in.setSingleLine(true); in.setHint("Project name");
        dlg().setTitle("New project folder").setView(in)
            .setPositiveButton("Create", (d, w) -> {
                String clean = in.getText().toString().replace("\n", " ").trim();
                if (clean.isEmpty() || clean.length() > 40) { showMessage("Use 1 to 40 characters."); return; }
                clean = safeDirName(clean);
                List<String> list = projectList(key, pid);
                String found = null; for (String x : list) if (x.equalsIgnoreCase(clean)) found = x;
                if (found == null) { list.add(clean); found = clean; }
                saveProject(key, pid, list, found);
                toastUi("Downloads → " + found + " (folder is created with the first download)");
            }).setNegativeButton("Cancel", null).show();
    }
    private void askRemoveProject(final String key, final String pid) {
        final List<String> list = projectList(key, pid);
        if (list.isEmpty()) return;
        final String[] labels = list.toArray(new String[0]);
        dlg().setTitle("Remove from the list (files stay on the phone)").setItems(labels, (d, w) -> {
            String gone = list.get(w); String act = activeProject(key, pid);
            list.remove(w);
            saveProject(key, pid, list, gone.equals(act) ? "" : act);
            toastUi("Removed \"" + gone + "\" from the list");
        }).setNegativeButton("Cancel", null).show();
    }
    /** Folder inside Downloads for a file: Orbit/<profile name>/<AI name> (Gmail attachments: Orbit/Gmail). Step 12a. Call on the UI thread. */
    private String orbitSubPath(WebView v, String key) {
        try {
            if (MAIL_KEY.equals(key)) return "Orbit/Gmail";
            String who = nameOfKey(key);
            String pid = providerIdForUrl(v == null ? null : v.getUrl());
            String proj = (pid == null) ? "" : activeProject(key, pid);
            return "Orbit/" + safeDirName(who == null ? "Account" : who) + "/" + safeDirName(pid == null ? "Other" : providerName(pid)) + (proj.isEmpty() ? "" : "/" + safeDirName(proj));
        } catch (Exception e) { return "Orbit"; }
    }
    private static String safeDirName(String s) {
        String r = (s == null ? "" : s).replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim().replaceAll("^\\.+", "");
        if (r.length() > 60) r = r.substring(0, 60).trim();
        return r.isEmpty() ? "Other" : r;
    }
    private void handleDownload(WebView v, DlBridge br, String key, String url, String ua, String cd, String mime) {
        if (url == null) return;
        final String sub = orbitSubPath(v, key);
        final Uri tree = customTreeFor(v, key);
        final String proj = tree == null ? "" : projectFor(v, key);
        if (url.startsWith("blob:")) {
            br.blobUrl = url; br.cd = cd == null ? "" : cd; br.sub = sub; br.tree = tree; br.proj = proj;
            String js = "(function(u){fetch(u).then(function(r){return r.blob();}).then(function(b){var rd=new FileReader();rd.onloadend=function(){var s=String(rd.result);var d=s.substring(s.indexOf(',')+1);var N=262144;var n=Math.max(1,Math.ceil(d.length/N));for(var k=0;k<n;k++){OrbitDl.chunk(k,n,d.substring(k*N,(k+1)*N));}OrbitDl.done(b.type||'');};rd.readAsDataURL(b);}).catch(function(e){OrbitDl.fail(String(e));});})(" + JSONObject.quote(url) + ")";
            v.evaluateJavascript(js, null);
            Toast.makeText(this, "Saving file…", Toast.LENGTH_SHORT).show();
            return;
        }
        if (url.startsWith("data:")) {
            try {
                int comma = url.indexOf(','); String head = url.substring(5, comma); String body = url.substring(comma + 1);
                byte[] bytes = head.contains(";base64") ? android.util.Base64.decode(body, android.util.Base64.DEFAULT) : Uri.decode(body).getBytes("UTF-8");
                String mt = head.contains(";") ? head.substring(0, head.indexOf(';')) : head; if (mt.isEmpty()) mt = "application/octet-stream";
                java.io.File f = new java.io.File(getCacheDir(), "orbit_dl.tmp");
                try (java.io.FileOutputStream fo = new java.io.FileOutputStream(f)) { fo.write(bytes); }
                saveToDownloads(f, URLUtil.guessFileName(url, cd, mt), mt, sub, tree, proj);
            } catch (Exception e) { toastUi("Download failed"); }
            return;
        }
        if (!url.startsWith("http://") && !url.startsWith("https://")) return;
        if (tree != null) { downloadToCustom(url, ua, cookieFor(key, url), URLUtil.guessFileName(url, cd, mime), mime, sub, tree, proj); return; }
        try {
            String name = URLUtil.guessFileName(url, cd, mime);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            String ck = cookieFor(key, url);
            if (ck != null && !ck.isEmpty()) r.addRequestHeader("Cookie", ck);
            if (ua != null && !ua.isEmpty()) r.addRequestHeader("User-Agent", ua);
            if (mime != null && !mime.isEmpty()) r.setMimeType(mime);
            r.setTitle(name).setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            if (Build.VERSION.SDK_INT >= 29) r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, sub + "/" + name);
            else r.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, sub + "/" + name);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null) { Toast.makeText(this, "Downloads are not available", Toast.LENGTH_SHORT).show(); return; }
            dm.enqueue(r);
            Toast.makeText(this, "Downloading " + name + (Build.VERSION.SDK_INT >= 29 ? " → Downloads/" + sub : ""), Toast.LENGTH_SHORT).show();
        } catch (Exception e) { Toast.makeText(this, "Could not download: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    /** Copies a finished temp file into the public Downloads folder (Android 10+) or the app's Downloads folder (older). */
    private void saveToDownloads(java.io.File f, String name, String mime, String sub, Uri tree, String proj) {
        if (tree != null) {
            try { saveToTree(f, name, tree, proj); toastUi("Saved: " + name + " (" + treeLabel(tree) + (proj == null || proj.isEmpty() ? "" : "/" + proj) + ")"); return; }
            catch (Exception e) { toastUi("Custom folder failed (" + e.getMessage() + "). Saving to Downloads/" + sub); }
        }
        try {
            java.io.OutputStream out; String where;
            if (Build.VERSION.SDK_INT >= 29) {
                android.content.ContentValues cv = new android.content.ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name); cv.put(MediaStore.MediaColumns.MIME_TYPE, mime); cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + sub);
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (u == null) throw new java.io.IOException("cannot create file");
                out = getContentResolver().openOutputStream(u); where = "Downloads/" + sub;
            } else {
                java.io.File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS); if (dir == null) dir = getFilesDir();
                dir = new java.io.File(dir, sub); dir.mkdirs(); out = new java.io.FileOutputStream(new java.io.File(dir, name)); where = dir.getAbsolutePath();
            }
            try (java.io.InputStream in = new java.io.FileInputStream(f); java.io.OutputStream o = out) {
                byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            }
            f.delete();
            toastUi("Saved: " + name + " (" + where + ")");
        } catch (Exception e) { toastUi("Could not save the file: " + e.getMessage()); }
    }
    private void destroyView(WebView v) {
        try { webHost.removeView(v); v.stopLoading(); v.loadUrl("about:blank"); v.destroy(); } catch (Exception ignored) { }
    }
    /** Keep only the most recently used pages alive (Alias Manager > Settings > Orbit speed). */
    private void trimViews() {
        java.util.Iterator<Map.Entry<String, WebView>> it = views.entrySet().iterator();
        while (views.size() > keepLive && it.hasNext()) {
            Map.Entry<String, WebView> e = it.next();
            if (e.getValue() == webView) continue;
            destroyView(e.getValue()); it.remove();
        }
    }
    private void buildUi() {
        shell = new FrameLayout(this); shell.setBackgroundColor(C_BG);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(C_BG);
        shell.addView(root, new FrameLayout.LayoutParams(-1, -1));
        // Keep everything clear of the status bar / navigation bar / keyboard (Android 15 draws edge-to-edge).
        shell.setOnApplyWindowInsetsListener((v, insets) -> {
            int l, t, r, b;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                l = i.left; t = i.top; r = i.right; b = i.bottom;
            } else {
                l = insets.getSystemWindowInsetLeft(); t = insets.getSystemWindowInsetTop(); r = insets.getSystemWindowInsetRight(); b = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(l, t, r, b);
            return insets;
        });
        // Top bar (one slim row):  ☰ drawer | account name + status | ✉ Gmail | current AI (tap = switch) | ⋯ menu
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setBackgroundColor(C_BAR); top.setPadding(dp(6), 0, dp(6), 0);
        top.addView(iconButton("\u2302", "Back to Alias Manager", this::goHome), new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout.LayoutParams menuLp = new LinearLayout.LayoutParams(dp(44), dp(44)); menuLp.setMargins(dp(2), 0, 0, 0);
        top.addView(iconButton("☰", "Open menu", this::openDrawer), menuLp);
        LinearLayout titleBox = new LinearLayout(this); titleBox.setOrientation(LinearLayout.VERTICAL); titleBox.setGravity(Gravity.CENTER_VERTICAL); titleBox.setPadding(dp(10), 0, dp(6), 0);
        titleView = label("", 15f); titleView.setTypeface(null, android.graphics.Typeface.BOLD); titleView.setSingleLine(true); titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        status = label("", 12f); status.setSingleLine(true); status.setEllipsize(android.text.TextUtils.TruncateAt.END); status.setTextColor(C_MUTED);
        titleBox.addView(titleView, new LinearLayout.LayoutParams(-1, -2)); titleBox.addView(status, new LinearLayout.LayoutParams(-1, -2));
        titleBox.setOnClickListener(v -> openDrawer());
        top.addView(titleBox, new LinearLayout.LayoutParams(0, -1, 1));
        mailBtn = iconButton("✉", "Gmail", this::toggleMail);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(dp(44), dp(44)); mlp.setMargins(dp(2), 0, dp(2), 0); top.addView(mailBtn, mlp);
        aiBtn = new android.widget.ImageView(this); aiBtn.setPadding(dp(7), dp(7), dp(7), dp(7)); aiBtn.setContentDescription("Switch AI"); aiBtn.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        aiBtn.setBackground(rounded(C_SURFACE, 10)); aiBtn.setClickable(true); aiBtn.setOnClickListener(v -> openAiSheet());
        LinearLayout.LayoutParams alp0 = new LinearLayout.LayoutParams(dp(44), dp(44)); alp0.setMargins(dp(2), 0, dp(2), 0); top.addView(aiBtn, alp0);
        top.addView(iconButton("⋯", "More options", this::manageProfile), new LinearLayout.LayoutParams(dp(44), dp(44)));
        topBar = top; root.addView(top, new LinearLayout.LayoutParams(-1, dp(52)));
        // AI chips bar: hidden by default (the AI list is in the drawer); ⋯ > Advanced > AI chips bar brings it back.
        svcScroll = new HorizontalScrollView(this); svcScroll.setHorizontalScrollBarEnabled(false); svcScroll.setBackgroundColor(C_BAR2);
        svcRow = new LinearLayout(this); svcRow.setGravity(Gravity.CENTER_VERTICAL); svcRow.setPadding(dp(6), dp(4), dp(6), dp(4)); svcScroll.addView(svcRow);
        root.addView(svcScroll, new LinearLayout.LayoutParams(-1, dp(40)));
        // Row 2: back / address / go / reload (can be hidden from ⋯)
        addressRow = new LinearLayout(this); addressRow.setGravity(Gravity.CENTER_VERTICAL); addressRow.setPadding(dp(8),dp(4),dp(8),dp(4)); addressRow.setBackgroundColor(C_BAR2);
        address = new EditText(this); address.setSingleLine(true); address.setTextSize(14); address.setTextColor(C_TEXT); address.setHintTextColor(C_MUTED); address.setContentDescription("Address"); address.setHint("https://claude.ai/"); address.setText("https://claude.ai/"); address.setMinHeight(0); address.setMinimumHeight(0); address.setPadding(dp(12),0,dp(12),0); address.setBackground(rounded(C_FIELD, 10)); address.setImeOptions(EditorInfo.IME_ACTION_GO);
        address.setOnEditorActionListener((v,id,event)-> { if (id == EditorInfo.IME_ACTION_GO) { navigate(address.getText().toString()); return true; } return false; });
        addressRow.addView(iconButton("◀","Back",this::goBack),new LinearLayout.LayoutParams(dp(44),dp(40))); LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(0,dp(40),1); alp.setMargins(dp(3),0,dp(3),0); addressRow.addView(address,alp); addressRow.addView(button("Go",()->navigate(address.getText().toString())),new LinearLayout.LayoutParams(dp(48),dp(40))); LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(dp(44),dp(40)); rlp.setMargins(dp(3),0,0,0); addressRow.addView(iconButton("↻","Reload",()->{ WebView c=cur(); if(c!=null)c.reload(); }),rlp); root.addView(addressRow);
        webHost = new FrameLayout(this); webHost.setBackgroundColor(C_BG); root.addView(webHost,new LinearLayout.LayoutParams(-1,0,1));
        progressBar = new View(this); progressBar.setBackgroundColor(C_CYAN); progressBar.setVisibility(View.GONE);
        FrameLayout.LayoutParams ppl = new FrameLayout.LayoutParams(0, dp(2)); ppl.gravity = Gravity.TOP; webHost.addView(progressBar, ppl);
        // Drawer (left): accounts, AI list, tools. Own simple implementation (no extra library).
        scrim = new View(this); scrim.setBackgroundColor(Color.argb(150, 0, 0, 0)); scrim.setVisibility(View.GONE); scrim.setOnClickListener(v -> closeDrawer());
        shell.addView(scrim, new FrameLayout.LayoutParams(-1, -1));
        drawerW = Math.min(dp(310), (int) (getResources().getDisplayMetrics().widthPixels * 0.84f));
        drawerPanel = new LinearLayout(this); drawerPanel.setOrientation(LinearLayout.VERTICAL); drawerPanel.setBackgroundColor(C_BAR); drawerPanel.setClickable(true); drawerPanel.setVisibility(View.GONE);
        android.widget.ScrollView dsv = new android.widget.ScrollView(this); dsv.setVerticalScrollBarEnabled(false);
        drawerBody = new LinearLayout(this); drawerBody.setOrientation(LinearLayout.VERTICAL); drawerBody.setPadding(dp(10), dp(14), dp(10), dp(18)); dsv.addView(drawerBody);
        drawerPanel.addView(dsv, new LinearLayout.LayoutParams(-1, -1));
        shell.addView(drawerPanel, new FrameLayout.LayoutParams(drawerW, -1, Gravity.START));
        setContentView(shell); renderTabs(); applyCompact(); shell.requestApplyInsets();
    }
    // ===== Step 13c: drawer, bottom sheets, themed dialogs =====
    private AlertDialog.Builder dlg() {
        int th = getResources().getIdentifier("OrbitDialog", "style", getPackageName());
        return th != 0 ? new AlertDialog.Builder(this, th) : new AlertDialog.Builder(this);
    }
    private void openDrawer() {
        if (drawerPanel == null || drawerOpen) return;
        fillDrawer(); drawerOpen = true;
        scrim.setVisibility(View.VISIBLE); scrim.setAlpha(0f); scrim.animate().alpha(1f).setDuration(160).start();
        drawerPanel.setVisibility(View.VISIBLE); drawerPanel.setTranslationX(-drawerW); drawerPanel.animate().translationX(0).setDuration(190).start();
    }
    /** Push the top of the side menu to the left to close it (past about 60 dp), or let go and it springs back. */
    private View.OnTouchListener drawerSwipe() {
        return new View.OnTouchListener() {
            float downX;
            @Override public boolean onTouch(View v, android.view.MotionEvent e) {
                if (!drawerOpen || drawerPanel == null) return false;
                switch (e.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN: downX = e.getRawX(); return true;
                    case android.view.MotionEvent.ACTION_MOVE: drawerPanel.setTranslationX(Math.min(0f, e.getRawX() - downX)); return true;
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        if (e.getRawX() - downX < -dp(60)) closeDrawer(); else drawerPanel.animate().translationX(0).setDuration(120).start();
                        return true;
                    default: return false;
                }
            }
        };
    }
    private void closeDrawer() {
        if (!drawerOpen) return;
        drawerOpen = false;
        scrim.animate().alpha(0f).setDuration(140).withEndAction(() -> { if (!drawerOpen) scrim.setVisibility(View.GONE); }).start();
        drawerPanel.animate().translationX(-drawerW).setDuration(170).withEndAction(() -> { if (!drawerOpen) drawerPanel.setVisibility(View.GONE); }).start();
    }
    private void fillDrawer() {
        LinearLayout b = drawerBody; b.removeAllViews();
        LinearLayout head = new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL); head.setPadding(dp(6), 0, dp(6), dp(8)); head.setOnTouchListener(drawerSwipe());
        android.graphics.Bitmap lg = logoBitmap();
        if (lg != null) { android.widget.ImageView iv = new android.widget.ImageView(this); iv.setImageBitmap(lg); head.addView(iv, new LinearLayout.LayoutParams(dp(42), dp(42))); }
        LinearLayout ht = new LinearLayout(this); ht.setOrientation(LinearLayout.VERTICAL); ht.setPadding(dp(12), 0, 0, 0);
        TextView h1 = new TextView(this); h1.setText("Orbit"); h1.setTextSize(20); h1.setTextColor(C_TEXT); h1.setTypeface(null, android.graphics.Typeface.BOLD);
        TextView h2 = new TextView(this); h2.setText("Accounts and AI"); h2.setTextSize(12f); h2.setTextColor(C_MUTED);
        ht.addView(h1); ht.addView(h2); head.addView(ht);
        b.addView(head);
        b.addView(sectionLabel("Accounts"));
        for (final String name : profileNames) b.addView(accountRow(name));
        b.addView(simpleRow("＋", "New account", null, false, () -> { closeDrawer(); addProfile(); }));
        b.addView(simpleRow("🔗", "Link alias to this account", null, false, () -> { closeDrawer(); linkAlias(); }));
        b.addView(sectionLabel("AI services"));
        Set<String> con = connectedByKey.get(keyOf(activeProfile));
        String curPid = (!mailMode && webView != null) ? providerIdForUrl(webView.getUrl()) : null;
        for (final String[] p : providers) b.addView(aiRowFor(p, p[0].equals(curPid), con != null && con.contains(p[0]), () -> { closeDrawer(); openService(p[0]); }));
        b.addView(sectionLabel("Tools"));
        b.addView(simpleRow("✉", mailMode ? "Back to chat" : "Gmail (verification emails)", null, mailMode, () -> { closeDrawer(); toggleMail(); }));
        b.addView(simpleRow("\u23F0", "Scheduled messages", scheduleState(activeProfile), false, () -> { closeDrawer(); showScheduleList(); }));
        b.addView(simpleRow("🪟", "Picture-in-picture", null, false, () -> { closeDrawer(); enterPip(true); }));
        b.addView(simpleRow("🔋", "Keep running in background", keepAliveOn ? "On" : "Off", keepAliveOn, () -> { closeDrawer(); setKeepAlive(!keepAliveOn); }));
        b.addView(simpleRow("⋯", "Menu: account, downloads, security…", null, false, () -> { closeDrawer(); manageProfile(); }));
        b.addView(simpleRow("✕", "Close Orbit", null, false, this::finish));
    }
    private TextView sectionLabel(String t) {
        TextView v = new TextView(this); v.setText(t.toUpperCase(java.util.Locale.ROOT)); v.setTextSize(12f); v.setTextColor(C_MUTED); v.setTypeface(null, android.graphics.Typeface.BOLD);
        v.setLetterSpacing(0.06f); v.setPadding(dp(8), dp(16), dp(8), dp(6)); return v;
    }
    private LinearLayout rowBase(boolean active, final Runnable action) {
        LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), dp(7), dp(10), dp(7)); r.setMinimumHeight(dp(48));
        r.setBackground(rounded(active ? C_SURFACE2 : Color.TRANSPARENT, 12)); r.setClickable(true); r.setFocusable(true);
        r.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(1), 0, dp(1)); r.setLayoutParams(lp);
        return r;
    }
    private TextView rowText(String t, float size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(t); v.setTextSize(size); v.setTextColor(color); v.setSingleLine(true); v.setEllipsize(android.text.TextUtils.TruncateAt.END);
        if (bold) v.setTypeface(null, android.graphics.Typeface.BOLD); return v;
    }
    /** emoji/glyph + text + optional right-hand text */
    private LinearLayout simpleRow(String glyph, String text, String right, boolean active, Runnable action) {
        LinearLayout r = rowBase(active, action);
        r.addView(glyphView(glyph, active ? C_CYAN : C_TEXT));
        TextView t = rowText(text, 15, C_TEXT, false); LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1); tl.setMargins(dp(8), 0, dp(8), 0); r.addView(t, tl);
        if (right != null) r.addView(rowText(right, 12, C_MUTED, false));
        return r;
    }
    private LinearLayout menuRow(String glyph, String text, String right, boolean danger, final Runnable action) {
        LinearLayout r = rowBase(false, () -> { closeSheet(); action.run(); });
        r.addView(glyphView(glyph, danger ? C_DANGER : C_TEXT));
        TextView t = rowText(text, 15, danger ? C_DANGER : C_TEXT, false); LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1); tl.setMargins(dp(8), 0, dp(8), 0); r.addView(t, tl);
        if (right != null) r.addView(rowText(right, 12, C_MUTED, false));
        return r;
    }
    private LinearLayout aiRowFor(String[] p, boolean on, boolean ok, Runnable action) {
        LinearLayout r = rowBase(on, action);
        android.graphics.Bitmap bmp = aiIcon(p[0]);
        if (bmp != null) { android.widget.ImageView iv = new android.widget.ImageView(this); iv.setImageBitmap(bmp); iv.setAlpha(ok || on ? 1f : 0.75f); r.addView(iv, new LinearLayout.LayoutParams(dp(30), dp(30))); }
        else { TextView g = rowText(p[1].substring(0, 1), 15, C_TEXT, true); g.setGravity(Gravity.CENTER); r.addView(g, new LinearLayout.LayoutParams(dp(30), dp(30))); }
        TextView t = rowText(p[1], 15, C_TEXT, on); LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1); tl.setMargins(dp(12), 0, dp(8), 0); r.addView(t, tl);
        if (ok) { r.addView(smallIcon("\u2713", C_OK, 16)); r.addView(rowText("Signed in", 12, C_OK, false)); }
        return r;
    }
    private LinearLayout accountRow(final String name) {
        boolean on = name.equals(activeProfile);
        LinearLayout r = rowBase(on, () -> { closeDrawer(); switchProfile(name); });
        TextView dot = rowText("●", 15, colorOf(name), false); dot.setGravity(Gravity.CENTER); r.addView(dot, new LinearLayout.LayoutParams(dp(30), -2));
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1); cl.setMargins(dp(8), 0, dp(4), 0);
        String em = emojiOf(name), mail = linkedEmail(name);
        col.addView(rowText((em.isEmpty() ? "" : em + " ") + tabLabel(name), 15, C_TEXT, on));
        col.addView(rowText(mail != null ? mail : "No alias linked", 12, C_MUTED, false));
        r.addView(col, cl);
        if (on) r.addView(smallIcon("\u2713", C_OK, 20));
        r.setOnLongClickListener(v -> { closeDrawer(); if (!on) switchProfile(name); manageProfile(); return true; });
        return r;
    }
    /** Bottom sheet: openSheet(...) -> add rows -> showSheet(). */
    private LinearLayout openSheet(String title, String sub) {
        closeSheet();
        final android.app.Dialog d = new android.app.Dialog(this);
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        d.setCancelable(true); d.setCanceledOnTouchOutside(true); // tap outside the sheet closes it
        d.setOnDismissListener(x -> { if (sheetDlg == d) sheetDlg = null; });
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable(); bg.setColor(C_BAR); float rad = dp(20); bg.setCornerRadii(new float[]{rad, rad, rad, rad, 0, 0, 0, 0}); col.setBackground(bg);
        final View.OnTouchListener drag = sheetDrag();
        FrameLayout hdr = new FrameLayout(this); hdr.setOnTouchListener(drag); // the grab bar: pull it down to close the sheet
        View handle = new View(this); handle.setBackground(rounded(C_SURFACE2, 3));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(dp(38), dp(4)); hp.gravity = Gravity.CENTER_HORIZONTAL | Gravity.TOP; hp.setMargins(0, dp(9), 0, 0); hdr.addView(handle, hp);
        col.addView(hdr, new LinearLayout.LayoutParams(-1, dp(24)));
        TextView t = new TextView(this); t.setText(title); t.setTextSize(16.5f); t.setTextColor(C_TEXT); t.setTypeface(null, android.graphics.Typeface.BOLD); t.setSingleLine(true); t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setPadding(dp(18), dp(2), dp(18), 0); t.setOnTouchListener(drag); col.addView(t);
        if (sub != null && !sub.isEmpty()) { TextView st = new TextView(this); st.setText(sub); st.setTextSize(12); st.setTextColor(C_MUTED); st.setSingleLine(true); st.setEllipsize(android.text.TextUtils.TruncateAt.END); st.setPadding(dp(18), 0, dp(18), dp(4)); col.addView(st); }
        android.widget.ScrollView sv = new android.widget.ScrollView(this); sv.setVerticalScrollBarEnabled(false);
        LinearLayout body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(10), dp(2), dp(10), dp(22)); sv.addView(body);
        col.addView(sv, new LinearLayout.LayoutParams(-1, -2));
        d.setContentView(col);
        sheetDlg = d; sheetRoot = col;
        return body;
    }
    /** Drag the top of a sheet down to close it (past about 70 dp, or let go and it springs back). */
    private View.OnTouchListener sheetDrag() {
        return new View.OnTouchListener() {
            float downY;
            @Override public boolean onTouch(View v, android.view.MotionEvent e) {
                final View root = sheetRoot;
                if (root == null) return false;
                switch (e.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN: downY = e.getRawY(); return true;
                    case android.view.MotionEvent.ACTION_MOVE: root.setTranslationY(Math.max(0f, e.getRawY() - downY)); return true;
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        if (e.getRawY() - downY > dp(70)) root.animate().translationY(root.getHeight()).setDuration(150).withEndAction(new Runnable() { @Override public void run() { closeSheet(); } }).start();
                        else root.animate().translationY(0f).setDuration(120).start();
                        return true;
                    default: return false;
                }
            }
        };
    }
    private void showSheet() {
        final android.app.Dialog d = sheetDlg; if (d == null || sheetRoot == null || isFinishing()) return;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        sheetRoot.measure(View.MeasureSpec.makeMeasureSpec(dm.widthPixels, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int h = Math.min(sheetRoot.getMeasuredHeight(), (int) (dm.heightPixels * 0.86f));
        android.view.Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            w.setGravity(Gravity.BOTTOM); w.setLayout(-1, h); w.getAttributes().windowAnimations = android.R.style.Animation_InputMethod;
        }
        d.show();
    }
    private void closeSheet() {
        if (sheetDlg != null) { try { sheetDlg.dismiss(); } catch (Exception ignored) { } sheetDlg = null; }
    }
    // ===== Step 13e: keep-alive service, picture-in-picture, battery / background help =====
    private void startKeepAlive(boolean askNotificationPermission) {
        try {
            if (askNotificationPermission && Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7732);
            Intent i = new Intent(this, OrbitKeepAliveService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception e) { Toast.makeText(this, "Could not start the background notification: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    private void stopKeepAlive() { try { stopService(new Intent(this, OrbitKeepAliveService.class)); } catch (Exception ignored) { } }
    private void setKeepAlive(boolean on) {
        keepAliveOn = on; prefs.edit().putBoolean("keep_alive", on).apply();
        if (on) { startKeepAlive(true); if (!batteryUnrestricted()) showBatterySheet(); else Toast.makeText(this, "Background notification is on", Toast.LENGTH_SHORT).show(); }
        else { stopKeepAlive(); Toast.makeText(this, "Background notification is off", Toast.LENGTH_SHORT).show(); }
        refreshStatus();
    }
    private boolean pipSupported() { return Build.VERSION.SDK_INT >= 26 && getPackageManager().hasSystemFeature(android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE); }
    private boolean enterPip(boolean fromUser) {
        if (!pipSupported()) { if (fromUser) Toast.makeText(this, "Picture-in-picture is not supported on this phone", Toast.LENGTH_LONG).show(); return false; }
        try {
            closeDrawer(); closeSheet();
            android.app.PictureInPictureParams.Builder pb = new android.app.PictureInPictureParams.Builder().setAspectRatio(new android.util.Rational(9, 16));
            return enterPictureInPictureMode(pb.build());
        } catch (Exception e) { if (fromUser) Toast.makeText(this, "Could not float Orbit: " + e.getMessage(), Toast.LENGTH_LONG).show(); return false; }
    }
    /** Home / recents pressed. Not when Orbit itself opened the file picker, camera, settings... (internalLaunchAt). */
    @Override protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (pipAuto && !locked && !isFinishing() && System.currentTimeMillis() - internalLaunchAt > 3000) enterPip(false);
    }
    @Override public void startActivityForResult(Intent intent, int requestCode, Bundle options) { internalLaunchAt = System.currentTimeMillis(); super.startActivityForResult(intent, requestCode, options); }
    @Override public void onPictureInPictureModeChanged(boolean isInPip, android.content.res.Configuration cfg) {
        super.onPictureInPictureModeChanged(isInPip, cfg);
        inPip = isInPip;
        if (topBar != null) topBar.setVisibility(isInPip ? View.GONE : View.VISIBLE);
        if (isInPip) { closeDrawer(); closeSheet(); if (addressRow != null) addressRow.setVisibility(View.GONE); if (svcScroll != null) svcScroll.setVisibility(View.GONE); }
        else applyCompact();
    }
    private boolean batteryUnrestricted() {
        try { android.os.PowerManager pm = (android.os.PowerManager) getSystemService(Context.POWER_SERVICE); return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName()); } catch (Exception e) { return false; }
    }
    private String brandKey() {
        String m = (Build.MANUFACTURER == null ? "" : Build.MANUFACTURER).toLowerCase(java.util.Locale.ROOT);
        if (m.contains("xiaomi") || m.contains("redmi") || m.contains("poco")) return "xiaomi";
        if (m.contains("oppo") || m.contains("realme") || m.contains("oneplus")) return "oppo";
        if (m.contains("vivo") || m.contains("iqoo")) return "vivo";
        if (m.contains("huawei") || m.contains("honor")) return "huawei";
        if (m.contains("samsung")) return "samsung";
        if (m.contains("tecno") || m.contains("infinix") || m.contains("itel")) return "transsion";
        return "other";
    }
    /** {phone brand, step 1, step 2, ...} for the "keep running in background" help. */
    private String[] brandSteps() {
        switch (brandKey()) {
            case "xiaomi": return new String[]{"Xiaomi / Redmi / Poco", "Security app \u203A Permissions \u203A Autostart: turn Orbit on.", "Settings \u203A Apps \u203A Orbit \u203A Battery saver: choose No restrictions."};
            case "oppo": return new String[]{"Oppo / Realme / OnePlus", "Settings \u203A Apps \u203A Orbit \u203A Battery usage: allow background activity.", "Turn on Auto launch (Startup manager)."};
            case "vivo": return new String[]{"Vivo / iQOO", "iManager \u203A App manager \u203A Autostart: allow Orbit.", "Settings \u203A Battery \u203A Background power consumption: allow Orbit."};
            case "huawei": return new String[]{"Huawei / Honor", "Settings \u203A Battery \u203A App launch \u203A Orbit \u203A Manage manually.", "Turn on Auto-launch, Secondary launch and Run in background."};
            case "samsung": return new String[]{"Samsung", "Settings \u203A Battery \u203A Background usage limits.", "Take Orbit out of Sleeping apps and add it to Never sleeping apps."};
            case "transsion": return new String[]{"Tecno / Infinix / itel", "Phone Master (or Settings \u203A Battery) \u203A Autostart / Background app management: allow Orbit."};
            default: return new String[]{"Your phone", "Settings \u203A Apps \u203A Orbit \u203A Battery: choose Unrestricted.", "Look for Autostart or Background activity and allow Orbit."};
        }
    }
    private void requestIgnoreBattery() {
        try { Intent i = new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS); i.setData(Uri.parse("package:" + getPackageName())); startActivity(i); }
        catch (Exception e) { openBatterySettings(); }
    }
    private void openBatterySettings() {
        try { startActivity(new Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
        catch (Exception e) { openAppDetails(); }
    }
    private void openAppDetails() {
        try { Intent i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS); i.setData(Uri.parse("package:" + getPackageName())); startActivity(i); } catch (Exception ignored) { }
    }
    private void openAutostart() {
        String[][] c;
        switch (brandKey()) {
            case "xiaomi": c = new String[][]{{"com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"}}; break;
            case "oppo": c = new String[][]{{"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"}, {"com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"}, {"com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"}}; break;
            case "vivo": c = new String[][]{{"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"}, {"com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"}}; break;
            case "huawei": c = new String[][]{{"com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"}, {"com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"}}; break;
            case "samsung": c = new String[][]{{"com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity"}}; break;
            case "transsion": c = new String[][]{{"com.transsion.phonemaster", "com.cyin.himgr.autostart.AutoStartActivity"}}; break;
            default: c = new String[0][];
        }
        for (String[] cn : c) {
            try { Intent i = new Intent(); i.setComponent(new android.content.ComponentName(cn[0], cn[1])); startActivity(i); return; } catch (Exception ignored) { }
        }
        Toast.makeText(this, "Opening Orbit app settings: choose Battery > Unrestricted", Toast.LENGTH_LONG).show();
        openAppDetails();
    }
    private TextView primaryButton(String text, final Runnable action) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(14.5f); t.setTextColor(Color.WHITE); t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setGravity(Gravity.CENTER); t.setBackground(rounded(C_ACCENT, 14)); t.setClickable(true);
        t.setOnClickListener(v -> { closeSheet(); action.run(); });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48)); lp.setMargins(dp(4), dp(8), dp(4), dp(6)); t.setLayoutParams(lp);
        return t;
    }
    private TextView paragraph(String text, int color, float size, boolean bold) {
        TextView t = rowText(text, size, color, bold); t.setSingleLine(false); t.setEllipsize(null); t.setPadding(dp(10), dp(6), dp(10), dp(6)); t.setLineSpacing(0, 1.12f); return t;
    }
    /** Rounded info card for the help sheets: icon + bold title + short text. tone = C_OK / C_WARN / C_MUTED / C_ACCENT. */
    private View infoCard(String glyph, String title, String text, int tone) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(Gravity.TOP);
        card.setPadding(dp(12), dp(12), dp(14), dp(12)); card.setBackground(rounded(C_SURFACE, 14));
        card.addView(smallIcon(glyph, tone, 22));
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL);
        TextView t = rowText(title, 14.5f, tone, true); t.setSingleLine(false); t.setEllipsize(null);
        TextView d = rowText(text, 12.5f, C_MUTED, false); d.setSingleLine(false); d.setEllipsize(null); d.setLineSpacing(0, 1.12f); d.setPadding(0, dp(3), 0, 0);
        col.addView(t); col.addView(d);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1); cl.setMargins(dp(6), 0, 0, 0); card.addView(col, cl);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(dp(4), dp(6), dp(4), dp(6)); card.setLayoutParams(lp);
        return card;
    }
    /** One numbered step of a help sheet. */
    private View stepCard(int n, String text) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(10), dp(14), dp(10)); row.setBackground(rounded(C_SURFACE, 12));
        TextView num = new TextView(this); num.setText(String.valueOf(n)); num.setTextSize(12.5f); num.setTextColor(C_CYAN); num.setTypeface(null, android.graphics.Typeface.BOLD);
        num.setGravity(Gravity.CENTER); num.setBackground(rounded(C_SURFACE2, 12));
        row.addView(num, new LinearLayout.LayoutParams(dp(24), dp(24)));
        TextView t = rowText(text, 13f, C_TEXT, false); t.setSingleLine(false); t.setEllipsize(null); t.setLineSpacing(0, 1.12f);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1); tl.setMargins(dp(10), 0, 0, 0); row.addView(t, tl);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(dp(4), dp(3), dp(4), dp(3)); row.setLayoutParams(lp);
        return row;
    }
    /** Small grey note at the bottom of a help sheet. */
    private TextView noteText(String text) {
        TextView t = rowText(text, 11.5f, C_MUTED, false); t.setSingleLine(false); t.setEllipsize(null); t.setLineSpacing(0, 1.12f); t.setPadding(dp(14), dp(12), dp(14), dp(4)); return t;
    }
    /** Help sheet: status card, one-line reason, the main button, three settings rows, steps for this phone brand, one small note. */
    private void showBatterySheet() {
        boolean ok = batteryUnrestricted();
        LinearLayout b = openSheet("Keep Orbit running", "So long replies can finish with the screen off");
        b.addView(infoCard(ok ? "\u2713" : "\u26A0", ok ? "Battery is unrestricted" : "Battery is optimized", ok ? "Android will not put Orbit to sleep." : "Android may stop Orbit when the screen is off.", ok ? C_OK : C_WARN));
        b.addView(paragraph("Orbit keeps your AI chats open while you use other apps. Allow background use and keep the background notification on.", C_MUTED, 12.5f, false));
        if (!ok) b.addView(primaryButton("Allow background use", this::requestIgnoreBattery));
        b.addView(sectionLabel("Settings"));
        b.addView(menuRow("🔋", "Battery settings", null, false, this::openBatterySettings));
        b.addView(menuRow("🚀", "Autostart and background", null, false, this::openAutostart));
        b.addView(menuRow("🔔", "Background notification", keepAliveOn ? "On" : "Off", false, () -> { keepAliveOn = !keepAliveOn; prefs.edit().putBoolean("keep_alive", keepAliveOn).apply(); if (keepAliveOn) startKeepAlive(true); else stopKeepAlive(); refreshStatus(); }));
        String[] bs = brandSteps();
        b.addView(sectionLabel("On your phone: " + bs[0]));
        for (int k = 1; k < bs.length; k++) b.addView(stepCard(k, bs[k]));
        b.addView(noteText("Android shows its own confirmation box and it cannot be styled. Some phones still close apps; if that happens, follow the steps above. A reply may not finish if the connection drops."));
        showSheet();
    }
    // ===== Scheduled message (PROTOTYPE): at a chosen time Orbit types a message into Claude and presses Send =====
    private String autoProfile = null;               // account being sent for (alarm, or "Send test now")
    private String autoSid = null, autoPid = "claude";  // which schedule, which AI
    private JSONObject autoSched = null;
    private boolean autoUnattended = false, autoDone = false, autoDetected = false, autoTest = false;
    private long autoBeganAt = 0; private String autoLast = "";
    private FrameLayout autoCover; private TextView autoCoverText;
    private static final String AUTO_NEW = "https://claude.ai/new";
    static final String AUTO_JS = ""
        + "function(TEXT,INC){try{\n"
        + "var S=window.__orbitAuto=window.__orbitAuto||{typed:0,sent:0,sentAt:0,ghostAt:0,noBtn:0,tries:0};\n"
        + "var body=(document.body&&document.body.innerText)||'';\n"
        + "var flat=body.replace(/\\s+/g,' ');\n"
        + "var want=TEXT.replace(/\\s+/g,' ').trim();\n"
        + "var probe=want.slice(0,60);\n"
        + "if(/\\/login|\\/signup/.test(location.pathname))return 'login';\n"
        + "if(!S.sent&&/(you(?:'|\\u2019)ve (?:reached|hit)[^.]{0,60}limit|usage limit reached)/i.test(body))return 'limit';\n"
        + "var incOn=/incognito chats stay out|you(?:'|\\u2019)re incognito|incognito chat|temporary chat/i.test(body)||/[?&]temporary-chat=true/.test(location.search);\n"
        + "if(INC&&!incOn&&!S.sent){\n"
        + "if(Date.now()-S.ghostAt>4000){\n"
        + "var els=document.querySelectorAll('button,a,[role=button]');\n"
        + "for(var i=0;i<els.length;i++){var l=(els[i].getAttribute('aria-label')||'')+' '+(els[i].getAttribute('title')||'')+' '+(els[i].getAttribute('data-testid')||'');\n"
        + "if(/incognito|temporary chat/i.test(l)){els[i].click();S.ghostAt=Date.now();return 'ghost-click';}}\n"
        + "}\n"
        + "return 'wait-ghost';\n"
        + "}\n"
        + "var comp=document.querySelector('[data-testid=chat-input]')||document.querySelector('#prompt-textarea')||document.querySelector('div.ProseMirror[contenteditable=true]')||document.querySelector('.ql-editor[contenteditable=true]')||document.querySelector('div[contenteditable=true]')||document.querySelector('textarea');\n"
        + "if(!comp)return 'wait-composer';\n"
        + "var isTa=(comp.tagName==='TEXTAREA'||comp.tagName==='INPUT');\n"
        + "var cur=((isTa?comp.value:comp.innerText)||'').replace(/\\s+/g,' ').trim();\n"
        + "if(S.sent){\n"
        + "if(cur===''&&flat.indexOf(probe)!==-1)return 'done';\n"
        + "if(Date.now()-S.sentAt>15000&&cur!==''){S.sent=0;S.typed=0;S.noBtn=0;S.tries++;if(S.tries>2)return 'failed-send';}\n"
        + "return 'wait-sent';\n"
        + "}\n"
        + "if(cur!==want){\n"
        + "if(S.typed>=3)return 'failed-type';\n"
        + "comp.focus();\n"
        + "if(isTa){var d=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(comp),'value');d.set.call(comp,TEXT);comp.dispatchEvent(new Event('input',{bubbles:true}));}\n"
        + "else{var sel=window.getSelection();var r=document.createRange();r.selectNodeContents(comp);sel.removeAllRanges();sel.addRange(r);document.execCommand('insertText',false,TEXT);}\n"
        + "S.typed++;return 'typed';\n"
        + "}\n"
        + "var bs=document.querySelectorAll('button,[role=button]');var sb=null;\n"
        + "for(var j=0;j<bs.length;j++){var b=bs[j];var bl=(b.getAttribute('aria-label')||'')+' '+(b.getAttribute('data-testid')||'');\n"
        + "if(/send|submit/i.test(bl)&&!b.disabled&&b.getAttribute('aria-disabled')!=='true'){sb=b;break;}}\n"
        + "if(sb){sb.click();S.sent=1;S.sentAt=Date.now();return 'sent-click';}\n"
        + "if(++S.noBtn<4)return 'wait-send';\n"
        + "['keydown','keypress','keyup'].forEach(function(t){comp.dispatchEvent(new KeyboardEvent(t,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true}));});\n"
        + "S.sent=1;S.sentAt=Date.now();return 'sent-enter';\n"
        + "}catch(x){return 'error:'+(x&&x.message?x.message:x);}}\n";
    private final Runnable autoStep = new Runnable() { @Override public void run() { doAutoStep(); } };
    private static void jput(JSONObject o, String k, Object v) { try { o.put(k, v); } catch (Exception ignored) { } }
    private String clockText(int h, int m) {
        java.util.Calendar c = java.util.Calendar.getInstance(); c.set(java.util.Calendar.HOUR_OF_DAY, h); c.set(java.util.Calendar.MINUTE, m);
        return java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(c.getTime());
    }
    private String clockAt(long ms) { return java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(new java.util.Date(ms)); }
    private String whenText(JSONObject s) {
        long at = s.optLong("at", 0), now = System.currentTimeMillis();
        String day = "";
        if (at > now) { int d = OrbitScheduleMath.dayOffset(at, now); day = d == 0 ? "today" : d == 1 ? "tomorrow" : new java.text.SimpleDateFormat("MMM d", java.util.Locale.getDefault()).format(new java.util.Date(at)); }
        if ("reset".equals(s.optString("mode", "time"))) return "when the timer ends" + (at > now ? ", next " + day + " " + clockAt(at) : "");
        return "next " + (at > now ? day + " " + clockAt(at) : "at " + clockText(s.optInt("hour", 9), s.optInt("minute", 0))) + ("daily".equals(s.optString("repeat", "once")) ? ", then every day" : ", once");
    }
    /** When this account's current timer of this AI ends (+1 minute), or 0 if no timer is running. */
    private long resetEndFor(String profile, String pid) {
        String aliasId = links.optString(profile, ""); if (aliasId.isEmpty()) return 0;
        Long st = started.get(timerKey(aliasId, pid));
        return st == null ? 0 : st + windowMs(pid) + 60000L;
    }
    // ---- small building blocks for compact sheets (Batch 7) ----
    private TextView segCell(String t, boolean on, final Runnable r) {
        TextView v = new TextView(this); v.setText(t); v.setGravity(Gravity.CENTER); v.setTextSize(13f); v.setSingleLine(true); v.setEllipsize(android.text.TextUtils.TruncateAt.END);
        v.setTextColor(on ? C_TEXT : C_MUTED); v.setTypeface(null, on ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        if (on) v.setBackground(rounded(C_SURFACE2, 10));
        v.setOnClickListener(x -> r.run());
        return v;
    }
    /** Two-option switch, e.g. "At a set time" | "When the timer ends". */
    private View segmented(String a, String b, boolean firstOn, Runnable onFirst, Runnable onSecond) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(dp(3), dp(3), dp(3), dp(3)); row.setBackground(rounded(C_SURFACE, 13));
        row.addView(segCell(a, firstOn, onFirst), new LinearLayout.LayoutParams(0, dp(36), 1));
        row.addView(segCell(b, !firstOn, onSecond), new LinearLayout.LayoutParams(0, dp(36), 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(dp(4), dp(2), dp(4), dp(4)); row.setLayoutParams(lp);
        return row;
    }
    /** Small on/off tile: icon, label, state. */
    private View toggleTile(String glyph, String label, String state, boolean on, final Runnable r) {
        LinearLayout t = new LinearLayout(this); t.setOrientation(LinearLayout.HORIZONTAL); t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding(dp(10), dp(6), dp(8), dp(6)); t.setBackground(rounded(on ? C_SURFACE2 : C_SURFACE, 12));
        t.setMinimumHeight(dp(44)); t.setClickable(true); t.setOnClickListener(x -> r.run());
        t.addView(smallIcon(glyph, on ? C_CYAN : C_MUTED, 18));
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL);
        col.addView(rowText(label, 12.5f, C_TEXT, true)); col.addView(rowText(state, 11f, on ? C_CYAN : C_MUTED, false));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1); cl.setMargins(dp(8), 0, 0, 0); t.addView(col, cl);
        return t;
    }
    /** Small status tile with a coloured dot: green = fine, amber = needs a look. */
    private View statusTile(String label, boolean ok, final Runnable r) {
        LinearLayout t = new LinearLayout(this); t.setOrientation(LinearLayout.HORIZONTAL); t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding(dp(10), dp(8), dp(8), dp(8)); t.setBackground(rounded(C_SURFACE, 12));
        t.setMinimumHeight(dp(40)); t.setClickable(true); t.setOnClickListener(x -> r.run());
        View dot = new View(this); dot.setBackground(rounded(ok ? C_OK : C_WARN, 4));
        t.addView(dot, new LinearLayout.LayoutParams(dp(8), dp(8)));
        TextView tv = rowText(label, 11.5f, C_TEXT, false); tv.setSingleLine(false); tv.setEllipsize(null);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1); tl.setMargins(dp(8), 0, 0, 0); t.addView(tv, tl);
        return t;
    }
    /** Compact button (40 dp). primary = brand colour, otherwise a plain surface. */
    private TextView smallButton(String label, boolean primary, final Runnable r) {
        TextView v = new TextView(this); v.setText(label); v.setGravity(Gravity.CENTER); v.setTextSize(13.5f); v.setSingleLine(true); v.setEllipsize(android.text.TextUtils.TruncateAt.END);
        v.setTextColor(primary ? Color.WHITE : C_TEXT); v.setTypeface(null, android.graphics.Typeface.BOLD); v.setBackground(rounded(primary ? C_ACCENT : C_SURFACE, 12));
        v.setPadding(dp(10), 0, dp(10), 0); v.setClickable(true); v.setOnClickListener(x -> r.run());
        return v;
    }
    /** Puts views side by side with equal gaps; weights[i] = share of the width. */
    private View sideBySide(float[] weights, View... views) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < views.length; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, views[i] instanceof TextView && !(views[i] instanceof LinearLayout) ? dp(40) : -2, weights[i]);
            lp.setMargins(i == 0 ? 0 : dp(6), 0, 0, 0); row.addView(views[i], lp);
        }
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2); rl.setMargins(dp(4), dp(3), dp(4), dp(3)); row.setLayoutParams(rl);
        return row;
    }
    /** The saved message, shown as a card; tapping it edits the text. */
    private View messageCard(String txt, final Runnable edit) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.HORIZONTAL); c.setGravity(Gravity.CENTER_VERTICAL); c.setPadding(dp(12), dp(10), dp(12), dp(10)); c.setBackground(rounded(C_SURFACE, 12));
        c.setClickable(true); c.setOnClickListener(x -> edit.run());
        TextView t = rowText(txt.isEmpty() ? "Write the message to send" : txt.replace('\n', ' '), 13.5f, txt.isEmpty() ? C_MUTED : C_TEXT, false); t.setSingleLine(false); t.setMaxLines(2); t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        c.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        c.addView(smallIcon("\u270F", C_MUTED, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(dp(4), dp(2), dp(4), dp(4)); c.setLayoutParams(lp);
        return c;
    }
    private String scheduleState(String profile) {
        int on = 0, n = 0;
        for (String sid : OrbitScheduleReceiver.sidsFor(this, profile)) { n++; JSONObject s = OrbitScheduleReceiver.get(this, sid); if (s != null && s.optBoolean("on", false)) on++; }
        return n == 0 ? "None" : (on == 0 ? n + " off" : on + " on");
    }
    /** Small row of AI names to choose from (scrolls sideways). */
    private interface PickCb { void pick(String id); } // own interface: java.util.function needs API 24, Orbit supports 23
    private View aiChips(String selected, final PickCb onPick) {
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(dp(4), dp(2), dp(4), dp(4));
        for (final String[] p : providers) {
            boolean on = p[0].equals(selected);
            TextView c = new TextView(this); c.setText(p[1]); c.setTextSize(12.5f); c.setSingleLine(true); c.setGravity(Gravity.CENTER); c.setPadding(dp(12), 0, dp(12), 0);
            c.setTextColor(on ? C_TEXT : C_MUTED); c.setTypeface(null, on ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL); c.setBackground(rounded(on ? C_SURFACE2 : C_SURFACE, 15));
            c.setClickable(true); c.setOnClickListener(x -> onPick.pick(p[0]));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(30)); lp.setMargins(0, 0, dp(6), 0); row.addView(c, lp);
        }
        hs.addView(row);
        return hs;
    }
    /** "claude.ai  /chat/1a2b3c4d" : a short, readable form of a chat address. */
    private static String shortChatUrl(String url) {
        try { Uri u = Uri.parse(url); String path = u.getPath() == null ? "" : u.getPath(); if (path.length() > 28) path = path.substring(0, 14) + "\u2026" + path.substring(path.length() - 10); return u.getHost() + path; }
        catch (Exception e) { return url; }
    }
    /** List of this account's scheduled messages (any AI, new chat or a specific chat). */
    private void showScheduleList() {
        final String p = activeProfile;
        String mail = linkedEmail(p);
        LinearLayout b = openSheet("Scheduled messages", mail != null ? mail : tabLabel(p));
        java.util.List<String> sids = OrbitScheduleReceiver.sidsFor(this, p);
        if (sids.isEmpty()) b.addView(infoCard("\u23F0", "No scheduled messages yet", "Add one: choose the AI, a new chat or a specific chat, the message and when.", C_MUTED));
        for (final String sid : sids) {
            JSONObject s = OrbitScheduleReceiver.get(this, sid); if (s == null) continue;
            String txt = s.optString("text", "").replace('\n', ' ');
            String title = OrbitScheduleReceiver.providerName(this, OrbitScheduleReceiver.pidOf(s)) + " \u00B7 " + ("chat".equals(s.optString("target", "new")) ? "specific chat" : "new chat");
            b.addView(simpleRow("\u23F0", title, s.optBoolean("on", false) ? "On" : "Off", s.optBoolean("on", false), () -> { closeSheet(); showScheduleSheet(sid); }));
            TextView sub = noteText((txt.isEmpty() ? "No message yet" : "\u201C" + (txt.length() > 40 ? txt.substring(0, 40) + "\u2026" : txt) + "\u201D") + (s.optBoolean("on", false) ? " \u00B7 " + whenText(s) : ""));
            sub.setPadding(dp(56), 0, dp(14), dp(6)); b.addView(sub);
        }
        b.addView(sideBySide(new float[]{1}, smallButton("Add a scheduled message", true, () -> {
            closeSheet();
            String lastPid = prefs.getString("lastpid:" + p, "claude");
            showScheduleSheet(OrbitScheduleReceiver.newSid(), lastPid);
        })));
        b.addView(noteText("Each one has its own AI, chat, message and time. Prototype: test every new one with \u201CTest now (watch)\u201D first."));
        showSheet();
    }
    private void showScheduleSheet(String sid) {
        JSONObject s0 = OrbitScheduleReceiver.get(this, sid);
        showScheduleSheet(sid, s0 == null ? "claude" : OrbitScheduleReceiver.pidOf(s0));
    }
    private void showScheduleSheet(final String sid, String newPid) {
        JSONObject s0 = OrbitScheduleReceiver.get(this, sid);
        final String p = s0 != null ? s0.optString("profile", activeProfile) : activeProfile;
        final JSONObject s = s0 != null ? s0 : OrbitScheduleReceiver.blank(p, newPid);
        final String pid = OrbitScheduleReceiver.pidOf(s);
        final boolean on = s.optBoolean("on", false), reset = "reset".equals(s.optString("mode", "time")), incog = s.optBoolean("incognito", false), bg = s.optBoolean("background", true);
        final boolean specific = "chat".equals(s.optString("target", "new"));
        final String rep = s.optString("repeat", "once");
        String mail = linkedEmail(p);
        LinearLayout b = openSheet("Scheduled message", (mail != null ? mail : tabLabel(p)) + " \u00B7 " + OrbitScheduleReceiver.providerName(this, pid));
        // status
        LinearLayout st = new LinearLayout(this); st.setOrientation(LinearLayout.VERTICAL); st.setPadding(dp(8), dp(2), dp(8), dp(6));
        final int retry = s.optInt("retry", 0);
        TextView s1 = rowText(retry > 0 ? "\u25D0  Waiting for free memory \u00B7 try " + retry + " of 10" : (on ? "\u25CF  On \u00B7 " + whenText(s) : "\u25CB  Off"), 14.5f, retry > 0 ? C_WARN : (on ? C_OK : C_MUTED), true); s1.setSingleLine(false); s1.setEllipsize(null); st.addView(s1);
        String last = s.optString("lastResult", "");
        if (!last.isEmpty()) { TextView s2 = rowText("Last run: " + (s.optLong("lastRun", 0) > 0 ? fmtDate(s.optLong("lastRun")) + " \u00B7 " : "") + last, 11.5f, C_MUTED, false); s2.setSingleLine(false); s2.setEllipsize(null); st.addView(s2); }
        b.addView(st);
        // which AI + which chat
        b.addView(sectionLabel("AI"));
        b.addView(aiChips(pid, id -> { if (!id.equals(pid)) { jput(s, "pid", id); jput(s, "target", "new"); jput(s, "url", ""); if ((!"claude".equals(id) && !"chatgpt".equals(id))) jput(s, "incognito", false); commitSchedule(sid, s); } showScheduleSheet(sid, id); }));
        b.addView(sectionLabel("Chat"));
        b.addView(segmented("New chat", "Specific chat", !specific,
            () -> { if (specific) { jput(s, "target", "new"); commitSchedule(sid, s); showScheduleSheet(sid, pid); } },
            () -> { if (!specific) { jput(s, "target", "chat"); jput(s, "incognito", false); commitSchedule(sid, s); showScheduleSheet(sid, pid); } }));
        if (specific) {
            String cu = s.optString("url", "");
            TextView ct = noteText(cu.isEmpty() ? "No chat chosen. Open the chat in the Orbit Browser, then tap \u201CUse the chat open now\u201D." : shortChatUrl(cu));
            ct.setPadding(dp(14), dp(2), dp(14), dp(4)); b.addView(ct);
            b.addView(sideBySide(new float[]{2, 1}, smallButton("Use the chat open now", false, () -> { closeSheet(); useOpenChat(sid, s); }),
                smallButton("Clear", false, () -> { jput(s, "url", ""); commitSchedule(sid, s); showScheduleSheet(sid, pid); })));
        }
        // message
        b.addView(sectionLabel("Message"));
        b.addView(messageCard(s.optString("text", ""), () -> { closeSheet(); askScheduleText(sid, s); }));
        // when
        b.addView(sectionLabel("When"));
        b.addView(segmented("At a set time", "When timer ends", !reset,
            () -> { if (reset) { jput(s, "mode", "time"); if ("reset".equals(rep)) jput(s, "repeat", "daily"); commitSchedule(sid, s); showScheduleSheet(sid, pid); } },
            () -> { if (!reset) { jput(s, "mode", "reset"); if ("daily".equals(rep)) jput(s, "repeat", "reset"); commitSchedule(sid, s); showScheduleSheet(sid, pid); } }));
        if (!reset) {
            b.addView(simpleRow("\u23F0", "Send at", clockText(s.optInt("hour", 9), s.optInt("minute", 0)), false, () -> { closeSheet(); pickScheduleTime(sid, s); }));
        } else {
            long end = resetEndFor(p, pid);
            TextView nt = noteText(end > System.currentTimeMillis() ? "Sends right after this account's " + OrbitScheduleReceiver.providerName(this, pid) + " timer ends (" + clockAt(end) + ")." : "No " + OrbitScheduleReceiver.providerName(this, pid) + " timer is running for this account yet. Start a chat first, or use a set time.");
            nt.setPadding(dp(14), dp(2), dp(14), dp(2)); b.addView(nt);
        }
        // options
        b.addView(sectionLabel("Options"));
        boolean canIncog = !specific && ("claude".equals(pid) || "chatgpt".equals(pid));
        View repeatTile = toggleTile("\u21BB", reset ? "Repeat each reset" : "Repeat daily", "once".equals(rep) ? "Off" : "On", !"once".equals(rep), () -> {
            jput(s, "repeat", "once".equals(rep) ? (reset ? "reset" : "daily") : "once"); commitSchedule(sid, s); showScheduleSheet(sid, pid);
        });
        if (canIncog) b.addView(sideBySide(new float[]{1, 1},
            toggleTile("\uD83D\uDEE1", "Incognito chat", incog ? "On" : "Off", incog, () -> { jput(s, "incognito", !incog); commitSchedule(sid, s); showScheduleSheet(sid, pid); }), repeatTile));
        else b.addView(sideBySide(new float[]{1}, repeatTile));
        final boolean ramw = s.optBoolean("ramwait", true);
        b.addView(sideBySide(new float[]{1, 1},
            toggleTile("\u26A1", "No screen needed", bg ? "On: works when locked" : "Off: opens Orbit", bg, () -> { jput(s, "background", !bg); commitSchedule(sid, s); showScheduleSheet(sid, pid); }),
            toggleTile("\u25A3", "Wait if RAM is low", ramw ? "On: up to 10 min" : "Off", ramw, () -> { jput(s, "ramwait", !ramw); commitSchedule(sid, s); showScheduleSheet(sid, pid); })));
        final boolean nok = s.optBoolean("notifyok", true);
        b.addView(sideBySide(new float[]{1},
            toggleTile("🔔", "Notify when sent", nok ? "On: quiet note, no popup or sound" : "Off: no note when it sends", nok, () -> { jput(s, "notifyok", !nok); commitSchedule(sid, s); showScheduleSheet(sid, pid); })));
        // actions
        b.addView(sectionLabel("Actions"));
        if (on) b.addView(sideBySide(new float[]{2, 1}, smallButton("Save changes", true, () -> { saveSchedule(sid, s); showScheduleSheet(sid, pid); }),
            smallButton("Turn off", false, () -> { jput(s, "on", false); commitSchedule(sid, s); OrbitScheduleReceiver.cancelRetry(this, sid); showScheduleSheet(sid, pid); })));
        else b.addView(sideBySide(retry > 0 ? new float[]{2, 1} : new float[]{1}, retry > 0
            ? new View[]{smallButton("Turn on", true, () -> { saveSchedule(sid, s); showScheduleSheet(sid, pid); }), smallButton("Cancel retries", false, () -> { OrbitScheduleReceiver.cancelRetry(this, sid); showScheduleSheet(sid, pid); })}
            : new View[]{smallButton("Turn on", true, () -> { saveSchedule(sid, s); showScheduleSheet(sid, pid); })}));
        b.addView(sideBySide(new float[]{1, 1}, smallButton("Test now (watch)", false, () -> { closeSheet(); startAutoSend(sid, s, false, true); }),
            smallButton("Test in background", false, () -> { closeSheet(); testInBackground(sid, s); })));
        b.addView(sideBySide(new float[]{1, 1}, smallButton("All schedules", false, () -> { closeSheet(); showScheduleList(); }),
            smallButton("Delete", false, () -> { OrbitScheduleReceiver.disarm(this, sid); OrbitScheduleReceiver.cancelRetry(this, sid); OrbitScheduleReceiver.remove(this, sid); closeSheet(); showScheduleList(); })));
        // reliability
        b.addView(sectionLabel("Keep it reliable"));
        b.addView(sideBySide(new float[]{1, 1, 1},
            statusTile("Exact alarm", OrbitScheduleReceiver.canExact(this), () -> { closeSheet(); openExactAlarmSettings(); }),
            statusTile("Display over apps", android.provider.Settings.canDrawOverlays(this), () -> { closeSheet(); openOverlaySettings(); }),
            statusTile("Battery", batteryUnrestricted(), () -> { closeSheet(); showBatterySheet(); })));
        b.addView(noteText("Prototype. A test sends the real message, so it counts as a chat. The phone must be on and online. In the background it uses about 100 to 200 MB for roughly 20 seconds and nothing opens over a game. Only Claude has been tried on the real site; the other AIs use the same method and may need fixing. Automatic messages may go against an AI's terms: use your own accounts."));
        showSheet();
    }
    /** Takes the chat that is open in the Orbit Browser right now as the target of this schedule. */
    private void useOpenChat(String sid, JSONObject s) {
        String u = webView == null || mailMode ? null : webView.getUrl();
        String found = u == null ? null : providerIdForUrl(u);
        String[] pr = found == null ? null : providerById(found);
        if (pr == null || !chatUrlMatches(pr, u)) { Toast.makeText(this, "Open the chat you want in the Orbit Browser first, then try again.", Toast.LENGTH_LONG).show(); showScheduleSheet(sid, OrbitScheduleReceiver.pidOf(s)); return; }
        jput(s, "pid", found); jput(s, "target", "chat"); jput(s, "url", u); jput(s, "incognito", false);
        commitSchedule(sid, s);
        Toast.makeText(this, "Chat chosen: " + providerName(found), Toast.LENGTH_SHORT).show();
        showScheduleSheet(sid, found);
    }
    /** Sends the message in the hidden browser right now (the same thing the alarm does). */
    private void testInBackground(String sid, JSONObject s) {
        if (s.optString("text", "").trim().isEmpty()) { Toast.makeText(this, "Write the message first", Toast.LENGTH_SHORT).show(); showScheduleSheet(sid, OrbitScheduleReceiver.pidOf(s)); return; }
        if ("chat".equals(s.optString("target", "new")) && s.optString("url", "").isEmpty()) { Toast.makeText(this, "Choose the chat first", Toast.LENGTH_SHORT).show(); showScheduleSheet(sid, OrbitScheduleReceiver.pidOf(s)); return; }
        OrbitScheduleReceiver.put(this, sid, s);
        try { OrbitSendService.start(this, sid, true); Toast.makeText(this, "Sending in the background. A notification will tell you the result.", Toast.LENGTH_LONG).show(); }
        catch (Throwable t) { Toast.makeText(this, "Android did not allow the background run: " + t.getClass().getSimpleName(), Toast.LENGTH_LONG).show(); }
    }
    private void askScheduleText(final String sid, final JSONObject s) {
        final EditText in = new EditText(this);
        in.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        in.setMinLines(3); in.setGravity(Gravity.TOP | Gravity.START); in.setText(s.optString("text", "")); in.setSelection(in.getText().length());
        dlg().setTitle("Message to send").setView(in)
            .setPositiveButton("Save", (d, w) -> { jput(s, "text", in.getText().toString().trim()); commitSchedule(sid, s); showScheduleSheet(sid, OrbitScheduleReceiver.pidOf(s)); })
            .setNegativeButton("Cancel", (d, w) -> showScheduleSheet(sid, OrbitScheduleReceiver.pidOf(s))).show();
    }
    private void pickScheduleTime(final String sid, final JSONObject s) {
        int th = getResources().getIdentifier("OrbitDialog", "style", getPackageName());
        new android.app.TimePickerDialog(this, th, (view, h, m) -> {
            jput(s, "mode", "time"); jput(s, "hour", h); jput(s, "minute", m);
            if ("reset".equals(s.optString("repeat", "once"))) jput(s, "repeat", "daily");
            commitSchedule(sid, s); showScheduleSheet(sid, OrbitScheduleReceiver.pidOf(s));
        }, s.optInt("hour", 9), s.optInt("minute", 0), android.text.format.DateFormat.is24HourFormat(this)).show();
    }
    /** Saves the schedule exactly as the sheet shows it: recomputes the next time and sets (or cancels) the alarm. */
    private void commitSchedule(String sid, JSONObject s) {
        long now = System.currentTimeMillis();
        if (s.optBoolean("on", false)) {
            if ("reset".equals(s.optString("mode", "time"))) {
                long at = resetEndFor(s.optString("profile", activeProfile), OrbitScheduleReceiver.pidOf(s));
                if (at > now) jput(s, "at", at); else jput(s, "on", false);
            } else jput(s, "at", OrbitScheduleReceiver.nextTimeOfDay(s.optInt("hour", 9), s.optInt("minute", 0), now + 30000L));
        }
        OrbitScheduleReceiver.put(this, sid, s);
        if (s.optBoolean("on", false)) OrbitScheduleReceiver.arm(this, sid); else OrbitScheduleReceiver.disarm(this, sid);
    }
    /** Turns the schedule on. Says clearly WHEN it will send (a time that already passed today means tomorrow). */
    private void saveSchedule(String sid, JSONObject s) {
        String profile = s.optString("profile", activeProfile);
        if (s.optString("text", "").trim().isEmpty()) { Toast.makeText(this, "Write the message first", Toast.LENGTH_SHORT).show(); return; }
        if ("chat".equals(s.optString("target", "new")) && s.optString("url", "").isEmpty()) { Toast.makeText(this, "Choose the chat first: open it in the Orbit Browser, then tap \u201CUse the chat open now\u201D.", Toast.LENGTH_LONG).show(); return; }
        if ("reset".equals(s.optString("mode", "time")) && resetEndFor(profile, OrbitScheduleReceiver.pidOf(s)) <= System.currentTimeMillis()) { Toast.makeText(this, "No timer is running for this account and AI. Start a chat first, or choose a set time.", Toast.LENGTH_LONG).show(); return; }
        jput(s, "on", true); commitSchedule(sid, s);
        Toast.makeText(this, "Will send " + whenText(s).replace("next ", ""), Toast.LENGTH_LONG).show();
    }
    private void openExactAlarmSettings() {
        try {
            if (Build.VERSION.SDK_INT >= 31) { Intent i = new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM); i.setData(Uri.parse("package:" + getPackageName())); startActivity(i); }
            else Toast.makeText(this, "Exact alarms are already allowed on this Android version", Toast.LENGTH_LONG).show();
        } catch (Exception e) { openAppDetails(); }
    }
    private void openOverlaySettings() {
        try { Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION); i.setData(Uri.parse("package:" + getPackageName())); startActivity(i); }
        catch (Exception e) { openAppDetails(); }
    }
    /** Alarm or test: open a new chat (or the chosen chat) of the schedule's AI in this account's own profile, type the text, press Send, then count the chat like any other. */
    private void startAutoFromIntent() {
        String sid = getIntent().getStringExtra("autoSendProfile");
        if (sid == null || !profileSupported) return;
        JSONObject s = OrbitScheduleReceiver.get(this, sid);
        String profile = s == null ? null : s.optString("profile", sid);
        if (s == null || !profileNames.contains(profile)) { finish(); return; }
        boolean unattended = getIntent().getBooleanExtra("unattended", true);
        if (unattended) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        startAutoSend(sid, s, unattended, getIntent().getBooleanExtra("test", false));
    }
    private void startAutoSend(String sid, JSONObject s, boolean unattended, boolean test) {
        if (s.optString("text", "").trim().isEmpty()) { Toast.makeText(this, "Write the message first", Toast.LENGTH_SHORT).show(); return; }
        if (!profileSupported || webView == null) { Toast.makeText(this, "Orbit Browser is not ready", Toast.LENGTH_SHORT).show(); return; }
        String p = s.optString("profile", activeProfile), pid = OrbitScheduleReceiver.pidOf(s);
        autoSid = sid; autoPid = pid; autoProfile = p; autoSched = s; autoUnattended = unattended; autoTest = test; autoDone = false; autoDetected = false; autoLast = "start"; autoBeganAt = System.currentTimeMillis();
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        OrbitScheduleReceiver.cancelNotice(this, sid);
        if (unattended) addAutoCover(); else Toast.makeText(this, "Sending the test message\u2026", Toast.LENGTH_SHORT).show();
        if (mailMode) exitMail();
        if (!p.equals(activeProfile)) { activeProfile = p; saveProfiles(); showProfile(p); }
        boolean chat = "chat".equals(s.optString("target", "new")) && !s.optString("url", "").isEmpty();
        String url = chat ? s.optString("url", "") : OrbitScheduleReceiver.newChatUrl(this, pid, s.optBoolean("incognito", false));
        if (webView != null) { address.setText(url); webView.loadUrl(url); }
        ticker.removeCallbacks(autoStep); ticker.postDelayed(autoStep, 3000);
    }
    private void doAutoStep() {
        if (autoProfile == null || autoDone || isFinishing()) return;
        long now = System.currentTimeMillis();
        if (locked) { autoBeganAt = Math.max(autoBeganAt, now - 20000L); ticker.postDelayed(autoStep, 1000); return; } // app lock: wait for the unlock
        if (now - autoBeganAt > 60000L) { autoFinish(false, autoFailText(autoLast)); return; }
        final WebView v = webView; String u = v == null ? null : v.getUrl();
        if (v == null || u == null || !OrbitScheduleReceiver.onAiSite(this, autoPid, u)) { ticker.postDelayed(autoStep, 900); return; }
        final String text = autoSched == null ? "" : autoSched.optString("text", "");
        final boolean inc = autoSched != null && autoSched.optBoolean("incognito", false) && !"chat".equals(autoSched.optString("target", "new"));
        v.evaluateJavascript("(" + AUTO_JS + ")(" + JSONObject.quote(text) + "," + (inc ? "true" : "false") + ")", value -> {
            if (v != webView || autoDone || autoProfile == null) return;
            String r = value == null ? "" : value;
            if (r.length() >= 2 && r.startsWith("\"")) r = r.substring(1, r.length() - 1);
            autoLast = r;
            if (r.equals("done")) autoFinish(true, "");
            else if (r.equals("limit") || r.equals("login") || r.startsWith("failed")) autoFinish(false, autoFailText(r));
            else ticker.postDelayed(autoStep, 800);
        });
    }
    static String autoFailText(String last) {
        if (last.equals("limit")) return "The AI says the usage limit is reached.";
        if (last.equals("login")) return "This account is signed out.";
        if (last.startsWith("wait-ghost") || last.startsWith("ghost")) return "Could not switch to an Incognito chat.";
        if (last.startsWith("wait-composer")) return "Could not find the message box. The account may be signed out, the chat may be gone, or the page changed.";
        if (last.startsWith("wait-send")) return "Could not find the Send button.";
        if (last.startsWith("failed-type") || last.startsWith("typed")) return "Could not type the message.";
        return "The message was not confirmed as sent (" + last + ").";
    }
    private void autoFinish(boolean ok, String msg) {
        if (autoDone) return;
        autoDone = true; ticker.removeCallbacks(autoStep);
        final String p = autoProfile, sid = autoSid, pid = autoPid; JSONObject s = autoSched;
        if (p == null || s == null || sid == null) return;
        long now = System.currentTimeMillis();
        if (ok && autoStart && !autoDetected && !links.optString(p, "").isEmpty() && linkedEmail(p) != null) // the address bar did not show a NEW chat (Incognito, or an older chat): count it here
            chatStarted(p, pid, (s.optBoolean("incognito", false) ? "incognito-" : "sched-") + now, s.optBoolean("incognito", false));
        OrbitScheduleReceiver.finished(this, sid, ok, msg, resetEndFor(p, pid), autoTest);
        getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (autoCoverText != null) autoCoverText.setText(ok ? "Message sent." : msg);
        if (autoUnattended) { ticker.postDelayed(() -> { autoProfile = null; finish(); }, ok ? 2500 : 7000); }
        else { autoProfile = null; Toast.makeText(this, ok ? "Test message sent" : msg, Toast.LENGTH_LONG).show(); }
    }
    private void addAutoCover() {
        if (autoCover != null || shell == null) return;
        autoCover = new FrameLayout(this); autoCover.setBackgroundColor(C_BG); autoCover.setClickable(true);
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setGravity(Gravity.CENTER); col.setPadding(dp(32), 0, dp(32), 0);
        TextView t1 = label("Sending your scheduled message", 18f); t1.setTypeface(null, android.graphics.Typeface.BOLD); t1.setGravity(Gravity.CENTER);
        autoCoverText = label("Please wait\u2026", 14f); autoCoverText.setTextColor(C_MUTED); autoCoverText.setGravity(Gravity.CENTER); autoCoverText.setPadding(0, dp(8), 0, 0);
        col.addView(t1, new LinearLayout.LayoutParams(-1, -2)); col.addView(autoCoverText, new LinearLayout.LayoutParams(-1, -2));
        autoCover.addView(col, new FrameLayout.LayoutParams(-1, -1));
        shell.addView(autoCover, new FrameLayout.LayoutParams(-1, -1));
    }
    private void applyCompact() {
        if (addressRow != null) addressRow.setVisibility(compact ? View.GONE : View.VISIBLE);
        if (svcScroll != null) svcScroll.setVisibility(!compact && showChips ? View.VISIBLE : View.GONE);
    }
    private WebView cur() { return mailMode && mailView != null ? mailView : webView; }
    private String tabsSig = "";
    private String tabsSignature() {
        StringBuilder sb = new StringBuilder(activeProfile);
        for (String n : profileNames) sb.append('|').append(n).append('=').append(tabLabel(n)).append(colorOf(n)).append(emojiOf(n));
        return sb.toString();
    }
    private void renderTabs() {            // the account tabs are gone: the title in the top bar + the drawer list show the accounts
        tabsSig = tabsSignature();
        if (titleView != null) titleView.setText(mailMode ? "Gmail" : titleText());
        if (drawerOpen) fillDrawer();
    }
    // ---- Gmail: see verification emails inside the app. claude.ai links tapped there open in the ACTIVE Claude profile. ----
    private void toggleMail() {
        if (mailMode) { exitMail(); return; }
        if (!profileSupported) { showMessage("Gmail view needs an updated Android System WebView (isolated profiles)."); return; }
        try {
            if (mailView == null) createMailView();
            mailMode = true;
            if (webView != null) webView.setVisibility(View.GONE);
            mailView.setVisibility(View.VISIBLE);
            mailBtn.setBackground(rounded(C_ACCENT, 10));
            String u = mailView.getUrl(); address.setText(u == null ? MAIL_URL : u);
            refreshStatus();
        } catch (Exception e) { mailMode = false; showMessage("Could not open Gmail: " + e.getMessage()); }
    }
    private void exitMail() {
        mailMode = false;
        if (mailView != null) mailView.setVisibility(View.GONE);
        if (webView != null) { webView.setVisibility(View.VISIBLE); String u = webView.getUrl(); if (u != null) address.setText(u); }
        if (mailBtn != null) mailBtn.setBackground(rounded(C_SURFACE, 10));
        refreshStatus();
    }
    private void createMailView() {
        WebView view = new WebView(this);
        WebViewCompat.setProfile(view, MAIL_KEY);
        view.getSettings().setJavaScriptEnabled(true); view.getSettings().setDomStorageEnabled(true);
        view.getSettings().setJavaScriptCanOpenWindowsAutomatically(false); view.getSettings().setSupportMultipleWindows(false);
        try { android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(view, true); } catch (Exception ignored) { }
        view.setWebChromeClient(newChromeClient());
        final DlBridge mailBr = new DlBridge(); view.addJavascriptInterface(mailBr, "OrbitDl");
        view.setDownloadListener((u, ua, cd, mime, len) -> handleDownload(view, mailBr, MAIL_KEY, u, ua, cd, mime));
        view.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                Uri u = req.getUrl(); String scheme = u.getScheme();
                if (!"http".equals(scheme) && !"https".equals(scheme)) return true;
                if (!req.isForMainFrame()) return false;
                Uri target = unwrapRedirect(u);
                String host = target.getHost();
                if (host != null && (host.equals("claude.ai") || host.endsWith(".claude.ai"))) { openInClaude(target.toString()); return true; }
                return false;
            }
            @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) { super.onPageStarted(v, url, icon); mailBr.allowed = trustedHost(url); if (mailMode && url != null) address.setText(url); }
        });
        webHost.addView(view, new FrameLayout.LayoutParams(-1,-1));
        mailView = view;
        view.loadUrl(MAIL_URL);
    }
    /** Gmail wraps links as google.com/url?q=<real link>. Return the real link. */
    private Uri unwrapRedirect(Uri u) {
        try {
            String h = u.getHost();
            if (h != null && h.endsWith("google.com") && "/url".equals(u.getPath())) {
                String q = u.getQueryParameter("q"); if (q == null) q = u.getQueryParameter("url");
                if (q != null && q.startsWith("http")) return Uri.parse(q);
            }
        } catch (Exception ignored) { }
        return u;
    }
    private void openInClaude(String url) {
        exitMail();
        if (webView == null) return;
        String e = linkedEmail(activeProfile);
        address.setText(url); webView.loadUrl(url);
        Toast.makeText(this, "Opening in " + activeProfile + (e != null ? " → " + e : ""), Toast.LENGTH_SHORT).show();
    }
    private static final Pattern LOGINISH = Pattern.compile("(?i)(log-?in|sign-?in|sign-?up|/auth|auth\\.|accounts\\.|login\\.|identifier|oauth)");
    /** On an AI's login page, put this profile's linked alias in the email box (you still tap Continue yourself). Claude: also offers the alias picker. */
    private void maybeFillEmail(final WebView v, String url, String forProfile) {
        if (url == null || forProfile == null) return;
        boolean claudeLogin = LOGIN_URL.matcher(url).find();
        if (!claudeLogin) {
            String pid = providerIdForUrl(url);
            if (pid == null || pid.equals("claude")) return;
            String[] pr = providerById(pid);
            if (pr == null || !"1".equals(pr[9]) || !LOGINISH.matcher(url).find()) return;
        }
        String email = linkedEmail(forProfile);
        if (email == null) {
            if (claudeLogin && !aliases.isEmpty() && !isFinishing() && loginHinted.add(forProfile) && forProfile.equals(activeProfile)) linkAlias(); // pick the alias to sign in with
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastFillAt < 1500) return;
        lastFillAt = now;
        final String js = "(function(){try{var e=" + JSONObject.quote(email) + ";var i=document.querySelector('input[type=\"email\"],input[name=\"email\"],input[autocomplete=\"email\"],input[name=\"loginfmt\"],input[name=\"identifier\"],input[autocomplete=\"username\"]');if(!i||i.value||i.type==='password')return 0;var d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');d.set.call(i,e);i.dispatchEvent(new Event('input',{bubbles:true}));i.dispatchEvent(new Event('change',{bubbles:true}));return 1;}catch(x){return 0;}})()";
        int[] delays = {300, 1200, 2500};
        for (int dly : delays) ticker.postDelayed(() -> { if (v == webView) v.evaluateJavascript(js, null); }, dly);
    }
    private void addProfile() { if(mailMode)exitMail(); int i=1; while(profileNames.contains("Account "+i)) i++; String name="Account "+i; profileNames.add(name); activeProfile=name; try{ keys.put(name,"orbit_"+java.util.UUID.randomUUID().toString().replace("-","").substring(0,10)); }catch(Exception ignored){} saveMeta(); saveProfiles(); renderTabs(); if(profileSupported)showProfile(name); }
    private void switchProfile(String name) { if(mailMode)exitMail(); if(name.equals(activeProfile))return; activeProfile=name; saveProfiles(); renderTabs(); if(profileSupported)showProfile(name); }
    static String profileKey(String name) { return "orbit_"+name.toLowerCase().replaceAll("[^a-z0-9]+","_").replaceAll("^_+|_+$",""); }
    private WebView newProfileView(final String key) {
        WebView view = new WebView(this);
        WebViewCompat.setProfile(view, key);
        android.webkit.WebSettings ws = view.getSettings();
        ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setLoadsImagesAutomatically(true);
        ws.setJavaScriptCanOpenWindowsAutomatically(false); ws.setSupportMultipleWindows(false);
        ws.setAllowFileAccess(false); ws.setAllowContentAccess(true); ws.setSaveFormData(false);
        view.setOverScrollMode(View.OVER_SCROLL_NEVER);
        view.setBackgroundColor(Color.rgb(24, 24, 24));
        view.setWebChromeClient(newChromeClient());
        final DlBridge br = new DlBridge(); view.addJavascriptInterface(br, "OrbitDl");
        final WebView fview = view;
        view.setDownloadListener((u, ua, cd, mime, len) -> handleDownload(fview, br, key, u, ua, cd, mime));
        view.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) { String scheme = req.getUrl().getScheme(); return !("http".equals(scheme) || "https".equals(scheme)); }
            @Override public void doUpdateVisitedHistory(WebView v, String url, boolean isReload) {
                super.doUpdateVisitedHistory(v, url, isReload);
                br.allowed = trustedHost(url);
                String who = nameOfKey(key);
                if (who != null) { onUrlChanged(who, url); maybeFillEmail(v, url, who); checkGoogleBlock(url, who); }
                if (v == webView) { renderServiceChips(); }
            }
            @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) {
                super.onPageStarted(v, url, icon);
                if (v == webView) { if (url != null && !mailMode) address.setText(url); statusSuffix = "Loading…"; refreshStatus(); }
            }
            @Override public void onPageFinished(WebView v, String url) {
                super.onPageFinished(v, url);
                String who = nameOfKey(key);
                if (v == webView) { statusSuffix = "Session isolated"; refreshStatus(); }
                maybeFillEmail(v, url, who);
                scheduleServiceScan(who);
            }
        });
        return view;
    }
    private void showProfile(String name) {
        try {
            if (mailMode) exitMail();
            final String key = keyOf(name);
            if (webView != null) { webView.setVisibility(View.GONE); if (!keepAliveOn) webView.onPause(); }
            WebView cached = views.get(key);
            if (cached != null) { // already loaded: show it again at once, no reload
                views.remove(key); views.put(key, cached);
                webView = cached; cached.setVisibility(View.VISIBLE); cached.onResume();
                if (startUrl != null) { cached.loadUrl(startUrl); address.setText(startUrl); startUrl = null; }
                else { String u = cached.getUrl(); if (u != null) address.setText(u); }
                renderTabs(); refreshStatus(); scheduleServiceScan(name);
                return;
            }
            lastUrls.remove(key);
            WebView view = newProfileView(key);
            webView = view; views.put(key, view);
            webHost.addView(view, 0, new FrameLayout.LayoutParams(-1, -1));
            String url = startUrl != null ? startUrl : "https://claude.ai/"; startUrl = null;
            address.setText(url); view.loadUrl(url);
            trimViews();
            renderTabs(); refreshStatus();
        } catch (Exception e) { statusSuffix = "Unable to create isolated profile"; refreshStatus(); showMessage("Could not open profile. Update Android System WebView and try again.\n\n" + e.getMessage()); }
    }
    private void navigate(String raw) {
        String url=raw.trim(); if(url.isEmpty())return; if(!url.contains("://"))url="https://"+url; Uri uri=Uri.parse(url);
        if(!"https".equals(uri.getScheme())&& !"http".equals(uri.getScheme())){showMessage("Only HTTP and HTTPS pages are supported.");return;}
        address.setText(url); InputMethodManager imm=(InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE); if(imm!=null)imm.hideSoftInputFromWindow(address.getWindowToken(),0); WebView c=cur(); if(mailMode){ String h=uri.getHost(); if(h!=null&&(h.equals("claude.ai")||h.endsWith(".claude.ai"))){ openInClaude(url); return; } } if(c!=null)c.loadUrl(url);
    }
    private void showUnsupported() {
        webHost.removeAllViews(); TextView msg=new TextView(this); msg.setText("Isolated browser profiles are not supported by the installed Android System WebView.\n\nUpdate Android System WebView from Google Play, then reopen Orbit Browser. No shared-session fallback is used, so accounts won't accidentally share cookies."); msg.setTextSize(17); msg.setTextColor(Color.DKGRAY); msg.setGravity(Gravity.CENTER); msg.setPadding(dp(24),dp(24),dp(24),dp(24)); msg.setBackgroundColor(Color.WHITE); webHost.addView(msg,new FrameLayout.LayoutParams(-1,-1)); statusSuffix="Multi-profile feature unavailable"; refreshStatus();
    }
    private void showMessage(String message){ if(!isFinishing())dlg().setTitle("Orbit Browser").setMessage(message).setPositiveButton("OK",null).show(); }
    @Override public void onDestroy(){ if (isFinishing()) stopKeepAlive(); ticker.removeCallbacks(tick); ticker.removeCallbacks(limitTick); ticker.removeCallbacks(ghostTick); ticker.removeCallbacks(autoStep); if(mailView!=null){mailView.stopLoading();mailView.loadUrl("about:blank");mailView.destroy();mailView=null;} for (WebView lv : new ArrayList<>(views.values())) { try { lv.stopLoading(); lv.loadUrl("about:blank"); lv.destroy(); } catch (Exception ignored) { } } views.clear(); webView=null; if (fileCb != null) { fileCb.onReceiveValue(null); fileCb = null; } super.onDestroy(); }
}
