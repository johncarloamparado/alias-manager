package __PACKAGE__;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.KeyguardManager;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.webkit.ValueCallback;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.Gravity;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.webkit.ProfileStore;
import androidx.webkit.WebViewCompat;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import androidx.webkit.WebViewFeature;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class OrbitBrowserActivity extends Activity {
    private android.content.SharedPreferences prefs;
    private final List<String> profileNames = new ArrayList<>();
    private String activeProfile = "Account 1";
    private WebView webView;
    private LinearLayout root, tabs;
    private EditText address;
    private TextView status;
    private FrameLayout webHost;
    private boolean profileSupported;
    // ---- first-chat detection (URL only; page contents are never read) ----
    static final Object LOCK = new Object();
    private static final Pattern CHAT_URL = Pattern.compile("^https://claude\\.ai/chat/([0-9a-fA-F-]{36})");
    private static final Pattern NEW_CHAT_PAGE = Pattern.compile("^https://claude\\.ai(/new|/|/project/[^/?#]+)?/?([?#].*)?$");
    private final Map<String, String> lastUrls = new HashMap<>(); // profile key -> last URL (for first-chat detection)
    private boolean autoStart = true; // Alias Manager setting "Orbit auto-start timer"
    // ---- profile identity: a profile's WebView data key never changes, even when it is renamed ----
    private JSONObject keys = new JSONObject();    // displayName -> webview profile key (absent = legacy key from name)
    private JSONObject styles = new JSONObject();  // displayName -> {emoji, color}
    private static final int PURPLE = Color.rgb(92, 69, 158);
    private static final String[] COLOR_NAMES = {"Purple", "Blue", "Green", "Orange", "Red", "Pink", "Teal", "Gray"};
    private static final int[] COLOR_VALUES = {Color.rgb(92,69,158), Color.rgb(46,108,200), Color.rgb(36,140,90), Color.rgb(200,120,30),
            Color.rgb(190,60,60), Color.rgb(190,70,140), Color.rgb(30,140,150), Color.rgb(100,108,125)};
    private static final String[] EMOJIS = {"", "🟣", "🔵", "🟢", "🟠", "🔴", "⭐", "💼", "🏠", "🎮", "🧪"};
    // ---- toolbar timer: aliasId -> start time (ms). Same 5h rule as Alias Manager. ----
    private static final long FIVE_H = 5L * 60 * 60 * 1000;
    private final Map<String, Long> started = new HashMap<>();
    private String statusSuffix = "";
    private final Handler ticker = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() { @Override public void run() { refreshStatus(); ticker.postDelayed(this, 30000); } };
    // Aliases handed over by Alias Manager: {id, email}. Links are stored as profileName -> aliasId.
    private final List<String[]> aliases = new ArrayList<>();
    private JSONObject links = new JSONObject();
    // ---- Gmail view (own isolated profile, kept alive while you switch back to Claude) ----
    private static final String MAIL_KEY = "orbit_mail_inbox";
    private static final String MAIL_URL = "https://mail.google.com/";
    private static final Pattern LOGIN_URL = Pattern.compile("^https://claude\\.ai/(login|signup)");
    private WebView mailView;
    private boolean mailMode = false;
    private TextView mailBtn;
    private LinearLayout addressRow;
    private HorizontalScrollView tabScroll;
    private boolean compact = false;      // true = address bar + status line hidden (more room for the chat)
    private String aliasDebug = "";
    private static final Pattern LOGGED_IN_URL = Pattern.compile("^https://claude\\.ai/(new|chat/|recents|projects|settings|chats|code|artifacts)");
    private final Set<String> promptedLogin = new LinkedHashSet<>();
    private final Set<String> promptedChats = new LinkedHashSet<>();
    private final Set<String> loginSent = new LinkedHashSet<>();
    private String[] pendingChat = null; // {profile, chatId, provider}: chat seen on a profile with no alias yet
    private String[] pendingLink = null; // alias (id,email) Alias Manager asked for, with no profile linked yet
    private long lastFillAt = 0;
    private final Set<String> loginHinted = new LinkedHashSet<>();
    // ---- AI services (providers handed over by Alias Manager): {id, name, url, cookie-name prefixes (comma separated)} ----
    private final List<String[]> providers = new ArrayList<>();
    private HorizontalScrollView svcScroll;
    private LinearLayout svcRow;
    private String svcSig = "";
    private final Map<String, Set<String>> connectedByKey = new HashMap<>(); // profile key -> provider ids that have a sign-in cookie
    private final Map<String, String> servicesSent = new HashMap<>();
    private Runnable scanTask;
    private String startUrl = null;          // first page to load (e.g. ChatGPT when a chip was tapped in Alias Manager)
    private String wantService = "";
    private boolean createIfMissing = false; // chip tapped for an alias that has no profile yet: make one
    // ---- speed: recently used pages stay alive, so switching accounts does not reload them ----
    private final java.util.LinkedHashMap<String, WebView> views = new java.util.LinkedHashMap<>();
    private int keepLive = 2;
    private View progressBar;
    private ValueCallback<Uri[]> fileCb;      // file chooser (upload) callback
    private static final int REQ_FILE = 9021;
    private static final int REQ_TREE = 9023;
    private String treeKey = "", treePid = "";   // account + AI waiting for the folder picker
    private long loadedRev = 0;               // changes when Alias Manager removes aliases/profiles behind our back
    private java.io.File camFile; private Uri camUri; // photo taken for an upload
    private final Set<String> googleWarned = new LinkedHashSet<>();
    // ---- app lock (Alias Manager > Settings > App lock): phone PIN / pattern / fingerprint when coming back after 30 s ----
    private static final int REQ_UNLOCK = 9022;
    private boolean locked = false, skipLockOnce = false;
    private View lockCover;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(12, 15, 24));
        getWindow().setNavigationBarColor(Color.rgb(12, 15, 24));
        prefs = getSharedPreferences("orbit_profiles", Context.MODE_PRIVATE);
        profileSupported = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE);
        compact = prefs.getBoolean("compact", false);
        autoStart = getIntent().getBooleanExtra("autoStart", true);
        int kl = getIntent().getIntExtra("keepLive", 0); if (kl > 0) prefs.edit().putInt("keep_live", kl).apply();
        keepLive = Math.max(1, Math.min(3, prefs.getInt("keep_live", 2)));
        loadedRev = prefs.getLong("rev", 0);
        loadAliases(); loadProviders(); loadProfiles(); loadLinks(); loadMeta(); if (profileSupported) erasePendingNow(); applyRequestedAlias(); buildUi();
        if (profileSupported) showProfile(activeProfile); else showUnsupported();
        if (pendingLink != null) offerLink();
        checkLock();
    }
    private void loadProviders() {
        providers.clear();
        String raw = getIntent().getStringExtra("providers");
        if (raw == null || raw.length() < 3) raw = prefs.getString("providers_json", null);
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i); if (o == null) continue;
                String id = o.optString("id", "").trim(), url = o.optString("url", "").trim();
                if (id.isEmpty() || !url.startsWith("https://")) continue;
                providers.add(new String[]{id, o.optString("name", id), url, csv(o.optJSONArray("cookies")), csv(o.optJSONArray("hosts")),
                    o.optString("inPat", ""), o.optString("outPat", ""), o.optString("chat", ""), String.valueOf(o.optDouble("hours", 5)), o.optBoolean("fill", true) ? "1" : "0"});
            }
        } catch (Exception ignored) { }
        if (providers.isEmpty()) providers.add(new String[]{"claude", "Claude", "https://claude.ai/", "sessionKey", "claude.ai", "", "", "^https://claude\\.ai/chat/([0-9a-fA-F-]{36})", "5", "1"});
    }
    private static String csv(JSONArray a) {
        StringBuilder sb = new StringBuilder();
        if (a != null) for (int k = 0; k < a.length(); k++) { String v = a.optString(k, "").trim(); if (v.isEmpty()) continue; if (sb.length() > 0) sb.append(','); sb.append(v); }
        return sb.toString();
    }
    private String[] providerById(String id) { for (String[] p : providers) if (p[0].equals(id)) return p; return null; }
    private String providerName(String id) { String[] p = providerById(id); return p == null ? id : p[1]; }
    /** Timer window of an AI in ms. Claude is always 5 h; the others come from Alias Manager > Settings > Timer hours. */
    private long windowMs(String pid) {
        if (pid == null || pid.equals("claude")) return FIVE_H;
        String[] p = providerById(pid);
        try { double h = p == null ? 5 : Double.parseDouble(p[8]); if (h > 0) return (long) (h * 3600000L); } catch (Exception ignored) { }
        return FIVE_H;
    }
    private static String timerKey(String aliasId, String pid) { return (pid == null || pid.equals("claude")) ? aliasId : aliasId + "|" + pid; }
    private String reminderLabel(String email, String pid) { return (pid == null || pid.equals("claude")) ? email : email + " · " + providerName(pid); }
    private String providerIdForUrl(String url) {
        if (url == null) return null;
        String h; try { h = Uri.parse(url).getHost(); } catch (Exception e) { return null; }
        if (h == null) return null;
        for (String[] p : providers) {
            String ph; try { ph = Uri.parse(p[2]).getHost(); } catch (Exception e) { continue; }
            if (ph == null) continue;
            if (ph.startsWith("www.")) ph = ph.substring(4);
            if (h.equals(ph) || h.endsWith("." + ph)) return p[0];
            if (!p[4].isEmpty()) for (String x : p[4].split(",")) { x = x.trim(); if (!x.isEmpty() && (h.equals(x) || h.endsWith("." + x))) return p[0]; }
        }
        return null;
    }
    private void loadProfiles() {
        String saved = prefs.getString("profiles", "Account 1");
        Set<String> unique = new LinkedHashSet<>();
        for (String s : saved.split("\\n")) if (!s.trim().isEmpty()) unique.add(s.trim());
        profileNames.clear(); profileNames.addAll(unique);
        if (profileNames.isEmpty()) profileNames.add("Account 1");
        activeProfile = prefs.getString("active", profileNames.get(0));
        if (!profileNames.contains(activeProfile)) activeProfile = profileNames.get(0);
    }
    private void loadAliases() {
        aliases.clear();
        int fromIntent = parseAliases(getIntent().getStringExtra("aliases"), aliases);
        int fromSaved = 0;
        if (fromIntent == 0) { // fall back to the copy Alias Manager keeps in sync
            fromSaved = parseAliases(prefs.getString("aliases_json", null), aliases);
        }
        aliasDebug = "(from open: " + fromIntent + ", saved copy: " + fromSaved + ")";
    }
    /** Adds valid {id,email} entries to out and returns how many. A missing id falls back to the email. */
    private int parseAliases(String raw, List<String[]> out) {
        int n = 0;
        if (raw == null) return 0;
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String email = o.optString("email", "").trim();
                String id = o.optString("id", "").trim();
                if (email.isEmpty()) continue;
                if (id.isEmpty()) id = email;
                out.add(new String[]{id, email, o.optString("note", "").trim()}); n++;
                long lu = o.optLong("lastUsed", 0);
                if (lu > 0) { Long old = started.get(id); if (old == null || lu > old) started.put(id, lu); }
                JSONObject tm = o.optJSONObject("timers"); // timers of the other AIs: {chatgpt: startMs, ...}
                if (tm != null) { java.util.Iterator<String> ti = tm.keys(); while (ti.hasNext()) { String pk = ti.next(); long tv = tm.optLong(pk, 0); if (tv <= 0) continue; String tk = timerKey(id, pk); Long old2 = started.get(tk); if (old2 == null || tv > old2) started.put(tk, tv); } }
            }
        } catch (Exception ignored) { }
        return n;
    }
    /** Re-read the saved alias list (Alias Manager updates it every time something changes). */
    private void reloadAliases() {
        List<String[]> fresh = new ArrayList<>();
        if (parseAliases(prefs.getString("aliases_json", null), fresh) > 0) { aliases.clear(); aliases.addAll(fresh); }
    }
    /** If Alias Manager asked for a specific alias, start on the profile linked to it (and on the AI it asked for). */
    private void applyRequestedAlias() {
        wantService = getIntent().getStringExtra("service"); if (wantService == null) wantService = "";
        createIfMissing = getIntent().getBooleanExtra("createIfMissing", false);
        String want = getIntent().getStringExtra("aliasId");
        if (want == null || want.isEmpty()) return;
        String p = profileLinkedTo(want);
        if (p != null && profileNames.contains(p)) { activeProfile = p; saveProfiles(); setStartForService(); return; }
        if (createIfMissing && profileSupported) { createProfileFor(want); setStartForService(); return; }
        String email = "this alias";
        for (String[] a : aliases) if (a[0].equals(want)) email = a[1];
        pendingLink = new String[]{want, email}; // asked after the screen is built (offerLink)
    }
    private void setStartForService() {
        if (wantService.isEmpty()) return;
        for (String[] pr : providers) if (pr[0].equals(wantService)) { startUrl = pr[2]; return; }
    }
    /** A brand-new alias gets its own isolated profile. A lone, empty, unlinked profile is reused instead of leaving it unused. */
    private void createProfileFor(String aliasId) {
        String name = null;
        if (profileNames.size() == 1 && links.optString(profileNames.get(0), "").isEmpty()) {
            List<String> con = scanConnected(keyOf(profileNames.get(0)));
            if (scanCookieOk && con.isEmpty()) name = profileNames.get(0);
        }
        if (name == null) {
            int i = 1; while (profileNames.contains("Account " + i)) i++;
            name = "Account " + i; profileNames.add(name);
            try { keys.put(name, "orbit_" + java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 10)); } catch (Exception ignored) { }
        }
        try { String other = profileLinkedTo(aliasId); if (other != null) links.remove(other); links.put(name, aliasId); } catch (Exception ignored) { }
        activeProfile = name; saveProfiles(); saveLinks(); saveMeta();
    }
    /** Alias Manager opened Orbit for an alias that has no profile yet: offer to link it to the profile on screen. */
    private void offerLink() {
        final String[] pl = pendingLink; pendingLink = null;
        if (pl == null || isFinishing()) return;
        final String profile = activeProfile;
        new AlertDialog.Builder(this).setTitle("Link " + pl[1] + "?")
            .setMessage("No profile is linked to this alias yet.\n\nLink it to \"" + profile + "\"? (If it is another account, tap Not now, pick that tab, then tap 🔗.)")
            .setPositiveButton("Link", (d, w) -> {
                try { String other = profileLinkedTo(pl[0]); if (other != null) links.remove(other); links.put(profile, pl[0]); saveLinks(); } catch (Exception ignored) { }
                refreshStatus();
                afterLink(profile);
            }).setNegativeButton("Not now", null).show();
    }
    private void manageProfile() {
        final String name = activeProfile;
        String[] items = {"Switch AI…", compact ? "Show address bar" : "Hide address bar (more room for chat)", "Rename tab", "Reset tab name (use alias name)", "Change emoji", "Change color", "Sign out (keep this tab)…", "Google sign-in blocked? (help)", "Show cookie names (debug)", "Download project folder…", "Custom download folder…", "Downloaded files (dates)…", "Delete profile…"};
        new AlertDialog.Builder(this).setTitle(name).setItems(items, (d, which) -> {
            if (which == 0) pickService();
            else if (which == 1) { compact = !compact; prefs.edit().putBoolean("compact", compact).apply(); applyCompact(); }
            else if (which == 2) askRename(name);
            else if (which == 3) resetTabName(name);
            else if (which == 4) pickEmoji(name);
            else if (which == 5) pickColor(name);
            else if (which == 6) confirmSignOut(name);
            else if (which == 7) showGoogleBlocked(name);
            else if (which == 8) showCookieNames();
            else if (which == 9) pickProject();
            else if (which == 10) pickCustomDir();
            else if (which == 11) openFiles("");
            else confirmDelete(name);
        }).setNegativeButton("Close", null).show();
    }
    private void resetTabName(String name) {
        if (name.matches("Account \\d+")) { Toast.makeText(this, "Already using the alias name", Toast.LENGTH_SHORT).show(); return; }
        int i = 1; while (profileNames.contains("Account " + i)) i++;
        renameProfile(name, "Account " + i);
    }
    private void pickService() {
        Set<String> con = connectedByKey.get(keyOf(activeProfile));
        final String[] ids = new String[providers.size()]; String[] labels = new String[providers.size()];
        for (int i = 0; i < providers.size(); i++) { ids[i] = providers.get(i)[0]; labels[i] = (con != null && con.contains(ids[i]) ? "✓  " : "     ") + providers.get(i)[1]; }
        new AlertDialog.Builder(this).setTitle("Open which AI?").setItems(labels, (d, w) -> openService(ids[w])).setNegativeButton("Cancel", null).show();
    }
    private void openService(String id) {
        if (mailMode) exitMail();
        if (webView == null) return;
        for (String[] p : providers) if (p[0].equals(id)) { address.setText(p[2]); webView.loadUrl(p[2]); return; }
    }
    private void pickEmoji(final String name) {
        String[] labels = new String[EMOJIS.length];
        for (int i = 0; i < EMOJIS.length; i++) labels[i] = EMOJIS[i].isEmpty() ? "— None —" : EMOJIS[i];
        new AlertDialog.Builder(this).setTitle("Emoji for " + name).setItems(labels, (d, w) -> setStyle(name, EMOJIS[w], null)).show();
    }
    private void pickColor(final String name) {
        new AlertDialog.Builder(this).setTitle("Color for " + name).setItems(COLOR_NAMES, (d, w) -> setStyle(name, null, COLOR_VALUES[w])).show();
    }
    private void askRename(final String old) {
        final EditText in = new EditText(this); in.setSingleLine(true); in.setText(old); in.setSelection(old.length());
        new AlertDialog.Builder(this).setTitle("Rename profile").setView(in)
            .setPositiveButton("Save", (d, w) -> renameProfile(old, in.getText().toString()))
            .setNegativeButton("Cancel", null).show();
    }
    /** Renaming only changes the label; the WebView data key stays the same, so the login is kept. */
    private void renameProfile(String old, String raw) {
        String clean = raw.replace("\n", " ").trim();
        if (clean.isEmpty() || clean.length() > 24) { showMessage("Use 1 to 24 characters."); return; }
        if (clean.equals(old)) return;
        for (String n : profileNames) if (n.equalsIgnoreCase(clean)) { showMessage("A profile named \"" + n + "\" already exists."); return; }
        try {
            String k = keyOf(old);
            profileNames.set(profileNames.indexOf(old), clean);
            keys.remove(old); keys.put(clean, k);
            String l = links.optString(old, ""); links.remove(old); if (!l.isEmpty()) links.put(clean, l);
            JSONObject st = styles.optJSONObject(old); styles.remove(old); if (st != null) styles.put(clean, st);
            JSONObject seen = new JSONObject(prefs.getString("seen", "{}"));
            JSONArray ids = seen.optJSONArray(old); seen.remove(old); if (ids != null) seen.put(clean, ids);
            prefs.edit().putString("seen", seen.toString()).apply();
            if (activeProfile.equals(old)) activeProfile = clean;
            saveProfiles(); saveLinks(); saveMeta(); renderTabs(); refreshStatus();
        } catch (Exception e) { showMessage("Could not rename: " + e.getMessage()); }
    }
    // ---- Sign out: clears this profile's cookies + site data, but keeps the tab, its alias link and its style ----
    private void confirmSignOut(final String name) {
        if (!profileSupported) { showMessage("Profiles can't be managed until Android System WebView is updated."); return; }
        new AlertDialog.Builder(this).setTitle("Sign out \"" + name + "\"?")
            .setMessage("Erases the login (cookies and site data) of this profile on this phone. The tab, its alias link and its color stay. Your Claude account and chats are NOT deleted.")
            .setPositiveButton("Sign out", (d, w) -> signOut(name))
            .setNegativeButton("Cancel", null).show();
    }
    private void signOut(String name) {
        boolean ok = false;
        try {
            Object prof = ProfileStore.getInstance().getProfile(keyOf(name));
            if (prof != null) {
                // Looked up by reflection on the public androidx.webkit.Profile interface (signature not checked at build time).
                Class<?> pc = Class.forName("androidx.webkit.Profile");
                android.webkit.CookieManager cm = (android.webkit.CookieManager) pc.getMethod("getCookieManager").invoke(prof);
                android.webkit.WebStorage ws = (android.webkit.WebStorage) pc.getMethod("getWebStorage").invoke(prof);
                cm.removeAllCookies(null); cm.flush(); ws.deleteAllData();
                ok = true;
            }
        } catch (Throwable ignored) { }
        if (!ok) { showMessage("Could not sign out this profile (this WebView version does not allow it). Use Delete profile instead."); return; }
        saveUrlConn(keyOf(name), new LinkedHashSet<String>());
        String aliasId = links.optString(name, "");
        loginSent.remove(name + "|" + aliasId); promptedLogin.remove(name); loginHinted.remove(name);
        if (!aliasId.isEmpty()) {
            try { queueEvent(new JSONObject().put("type", "logout").put("aliasId", aliasId).put("profile", name).put("ts", System.currentTimeMillis())); } catch (Exception ignored) { }
        }
        if (name.equals(activeProfile) && webView != null) {
            webView.clearCache(true); webView.clearHistory(); lastUrls.remove(keyOf(name));
            address.setText("https://claude.ai/login"); webView.loadUrl("https://claude.ai/login");
        }
        servicesSent.remove(keyOf(name)); scheduleServiceScan(name);
        Toast.makeText(this, "Signed out: " + name, Toast.LENGTH_SHORT).show();
    }
    // ---- Limit detection (user-requested). Reads the visible text of the Claude page you are looking at, ONLY to find a
    // "you've reached your limit" message and its reset time. Only the matched line (max 300 chars) leaves the page; nothing is stored. ----
    private static final String LIMIT_JS = "(function(){try{var t=(document.body&&document.body.innerText)||'';"
        + "var m=t.match(/[^\\n]{0,80}(you(?:'|’)?ve (?:reached|hit)[^\\n]{0,60}limit|you(?:'|’)?re (?:out of|over)[^\\n]{0,30}(?:messages|usage)|usage limit reached|your limit (?:will )?resets?)[^\\n]*(?:\\n[^\\n]*){0,2}/i);"
        + "return m?m[0].slice(0,300):'';}catch(x){return '';}})()";
    private static final Pattern RESET_REL = Pattern.compile("(?i)\\bin\\s+(?:(\\d+)\\s*(?:hours?|hrs?|h)\\b)?\\s*(?:and\\s*)?(?:(\\d+)\\s*(?:minutes?|mins?|m)\\b)?");
    private static final Pattern RESET_CLOCK = Pattern.compile("(?i)\\b(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)\\b");
    private final Map<String, long[]> limitSeen = new HashMap<>(); // aliasId -> {key, when}
    private final Runnable limitTick = new Runnable() { @Override public void run() { checkLimit(); ticker.postDelayed(this, 10000); } };
    private void checkLimit() {
        if (!autoStart || mailMode || webView == null || isFinishing()) return;
        final WebView v = webView;
        String u = v.getUrl();
        if (u == null || !u.startsWith("https://claude.ai/")) return;
        final String profile = activeProfile;
        final String aliasId = links.optString(profile, "");
        if (aliasId.isEmpty() || linkedEmail(profile) == null) return;
        v.evaluateJavascript(LIMIT_JS, value -> {
            if (v != webView || value == null) return;
            String text = "";
            try { text = new JSONArray("[" + value + "]").optString(0, ""); } catch (Exception ignored) { }
            if (!text.isEmpty()) onLimitSeen(profile, aliasId, text);
        });
    }
    /** Best effort: "resets in 2 hours 10 minutes" or "resets at 3:30 PM". 0 = unknown (or not within the next 5h). */
    private long parseReset(String text, long now) {
        try { return parseResetUnsafe(text, now); } catch (Exception e) { return 0; } // e.g. absurdly long numbers in the page text
    }
    private long parseResetUnsafe(String text, long now) {
        long at = 0;
        Matcher r = RESET_REL.matcher(text);
        while (r.find()) {
            if (r.group(1) == null && r.group(2) == null) continue;
            long h = r.group(1) == null ? 0 : Long.parseLong(r.group(1)), mi = r.group(2) == null ? 0 : Long.parseLong(r.group(2));
            at = now + (h * 60 + mi) * 60000L; break;
        }
        if (at == 0) {
            Matcher c = RESET_CLOCK.matcher(text);
            if (c.find()) {
                int hh = Integer.parseInt(c.group(1)) % 12, mm = c.group(2) == null ? 0 : Integer.parseInt(c.group(2));
                if (c.group(3).equalsIgnoreCase("pm")) hh += 12;
                java.util.Calendar cal = java.util.Calendar.getInstance();
                cal.set(java.util.Calendar.HOUR_OF_DAY, hh); cal.set(java.util.Calendar.MINUTE, mm); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0);
                if (cal.getTimeInMillis() <= now) cal.add(java.util.Calendar.DAY_OF_YEAR, 1);
                at = cal.getTimeInMillis();
            }
        }
        if (at <= now || at - now > FIVE_H + 30 * 60000L) return 0;
        return at;
    }
    private void onLimitSeen(String profile, String aliasId, String text) {
        long now = System.currentTimeMillis();
        long resetAt = parseReset(text, now);
        long key = resetAt > 0 ? resetAt / 600000L : -1; // same reset time (10-minute buckets) = same limit message
        long[] prev = limitSeen.get(aliasId);
        if (prev != null && prev[0] == key && now - prev[1] < 30 * 60000L) return;
        limitSeen.put(aliasId, new long[]{key, now});
        String email = linkedEmail(profile);
        if (email == null) return;
        Long st = started.get(aliasId);
        boolean running = st != null && now - st < FIVE_H;
        long readyAt;
        if (resetAt > 0) { started.put(aliasId, resetAt - FIVE_H); readyAt = resetAt; }
        else if (running) { readyAt = st + FIVE_H; }
        else { started.put(aliasId, now); readyAt = now + FIVE_H; }
        OrbitReminderReceiver.add(this, aliasId, email, readyAt);
        try { queueEvent(new JSONObject().put("type", "limit").put("aliasId", aliasId).put("profile", profile).put("resetAt", resetAt).put("ts", now)); } catch (Exception ignored) { }
        refreshStatus();
        java.text.DateFormat df = android.text.format.DateFormat.getTimeFormat(this);
        Toast.makeText(this, "Limit reached: " + email + (resetAt > 0 ? " • resets " + df.format(new java.util.Date(resetAt)) : ""), Toast.LENGTH_LONG).show();
    }
    private void confirmDelete(final String victim) {
        if (!profileSupported) { showMessage("Profiles can't be managed until Android System WebView is updated."); return; }
        if (profileNames.size() <= 1) { showMessage("You need at least one profile. Add another one first."); return; }
        new AlertDialog.Builder(this).setTitle("Delete \"" + victim + "\"?")
            .setMessage("This signs out of this profile and erases its cookies and site data on this phone.\n\nYour Claude account and chats are NOT deleted. The alias link is removed. This cannot be undone.")
            .setPositiveButton("Delete", (d, w) -> deleteProfile(victim))
            .setNegativeButton("Cancel", null).show();
    }
    private void deleteProfile(String victim) {
        String key = keyOf(victim);
        int i = profileNames.indexOf(victim);
        if (i < 0 || profileNames.size() <= 1) return;
        String next = profileNames.get(i == 0 ? 1 : i - 1);
        if (victim.equals(activeProfile)) { activeProfile = next; saveProfiles(); renderTabs(); showProfile(next); }
        WebView dead = views.remove(key); if (dead != null && dead != webView) destroyView(dead); // its page must be gone before the data is erased
        // Remove it from Orbit right away. Android may still count the profile as "in use" for a moment,
        // so the erase of its cookies/site data is retried, and finished at the next start if needed.
        try {
            saveUrlConn(key, new LinkedHashSet<String>());
            profileNames.remove(victim); keys.remove(victim); styles.remove(victim); links.remove(victim); dropProjects(key); dropCustomDirs(key);
            JSONObject seen = new JSONObject(prefs.getString("seen", "{}")); seen.remove(victim);
            prefs.edit().putString("seen", seen.toString()).apply();
        } catch (Exception ignored) { }
        saveProfiles(); saveLinks(); saveMeta(); renderTabs(); refreshStatus();
        Set<String> pend = pendingErase(); pend.add(key); savePendingErase(pend);
        eraseAttempt(0);
    }
    private Set<String> pendingErase() {
        Set<String> out = new LinkedHashSet<>();
        for (String k : prefs.getString("pending_erase", "").split("\\n")) if (!k.trim().isEmpty()) out.add(k.trim());
        return out;
    }
    private void savePendingErase(Set<String> set) { prefs.edit().putString("pending_erase", android.text.TextUtils.join("\n", set)).commit(); }
    /** @return true when nothing is left to erase. */
    private boolean erasePendingNow() { return erasePendingStatic(prefs); }
    /** Also used by OrbitBrowserPlugin (Alias Manager deleting an alias). Erases profile data that Android refused to erase earlier. */
    static boolean erasePendingStatic(android.content.SharedPreferences sp) {
        Set<String> pend = new LinkedHashSet<>();
        for (String k : sp.getString("pending_erase", "").split("\\n")) if (!k.trim().isEmpty()) pend.add(k.trim());
        if (pend.isEmpty()) return true;
        try {
            ProfileStore store = ProfileStore.getInstance();
            for (String k : new ArrayList<>(pend)) {
                try { if (store.deleteProfile(k) || store.getProfile(k) == null) pend.remove(k); } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
        sp.edit().putString("pending_erase", android.text.TextUtils.join("\n", pend)).commit();
        return pend.isEmpty();
    }
    private void eraseAttempt(final int attempt) {
        if (erasePendingNow()) { Toast.makeText(this, "Profile deleted and data erased", Toast.LENGTH_SHORT).show(); return; }
        if (attempt < 6) ticker.postDelayed(() -> eraseAttempt(attempt + 1), 800);
        else Toast.makeText(this, "Profile removed. Its data is erased the next time you open Orbit.", Toast.LENGTH_LONG).show();
    }
    private void loadMeta() {
        try { keys = new JSONObject(prefs.getString("keys", "{}")); } catch (Exception e) { keys = new JSONObject(); }
        try { styles = new JSONObject(prefs.getString("styles", "{}")); } catch (Exception e) { styles = new JSONObject(); }
    }
    private void saveMeta() { prefs.edit().putString("keys", keys.toString()).putString("styles", styles.toString()).apply(); }
    private String keyOf(String name) { String k = keys.optString(name, ""); return k.isEmpty() ? profileKey(name) : k; }
    private String nameOfKey(String key) { for (String n : profileNames) if (keyOf(n).equals(key)) return n; return null; }
    private int colorOf(String name) { JSONObject st = styles.optJSONObject(name); return st == null ? PURPLE : st.optInt("color", PURPLE); }
    /** Tab text: your own name if you renamed the profile; otherwise the linked alias (note or short email), else "Account N". */
    private String tabLabel(String name) {
        if (!name.matches("Account \\d+")) return name;
        String id = links.optString(name, "");
        if (id.isEmpty()) return name;
        for (String[] a : aliases) if (a[0].equals(id)) {
            String t = a.length > 2 && !a[2].isEmpty() ? a[2] : a[1].contains("@") ? a[1].substring(0, a[1].indexOf('@')) : a[1];
            return t.length() > 14 ? t.substring(0, 13) + "…" : t;
        }
        return name;
    }
    private String emojiOf(String name) { JSONObject st = styles.optJSONObject(name); return st == null ? "" : st.optString("emoji", ""); }
    private void setStyle(String name, String emoji, Integer color) {
        try {
            JSONObject st = styles.optJSONObject(name); if (st == null) st = new JSONObject();
            if (emoji != null) st.put("emoji", emoji);
            if (color != null) st.put("color", color.intValue());
            styles.put(name, st); saveMeta(); renderTabs();
        } catch (Exception ignored) { }
    }
    private void loadLinks() {
        try { links = new JSONObject(prefs.getString("links", "{}")); } catch (Exception e) { links = new JSONObject(); }
    }
    private void saveLinks() { prefs.edit().putString("links", links.toString()).apply(); }
    private String linkedEmail(String profile) {
        String id = links.optString(profile, "");
        if (id.isEmpty()) return null;
        for (String[] a : aliases) if (a[0].equals(id)) return a[1];
        return null; // alias was deleted in Alias Manager
    }
    private String timerText(String profile) {
        String id = links.optString(profile, "");
        if (id.isEmpty() || linkedEmail(profile) == null) return "";
        String pid = (!mailMode && webView != null) ? providerIdForUrl(webView.getUrl()) : null;
        if (pid == null) pid = "claude";
        Long st = started.get(timerKey(id, pid));
        if (st == null) return " • Not started";
        long left = windowMs(pid) - (System.currentTimeMillis() - st);
        if (left <= 0) return " • ✓ Ready";
        long mins = (left + 59999) / 60000;
        return " • ⏱ " + (mins / 60) + "h " + (mins % 60) + "m left";
    }
    private String who() {
        String e = linkedEmail(activeProfile);
        if (mailMode) return "✉ Gmail • claude.ai links open in " + activeProfile + (e != null ? " → " + e : "");
        return "Profile: " + activeProfile + (e != null ? " → " + e : " (no alias linked - tap 🔗)") + timerText(activeProfile) + (autoStart ? "" : " • auto-start OFF");
    }
    private void refreshStatus() {
        if (tabs != null && tabs.getChildCount() > 0 && !tabsSignature().equals(tabsSig)) renderTabs(); // labels changed (alias linked / renamed in Alias Manager)
        renderServiceChips();
        if (status != null) status.setText(who() + (statusSuffix.isEmpty() ? "" : " • " + statusSuffix));
    }
    private void goBack() {
        if (mailMode) { if (mailView != null && mailView.canGoBack()) mailView.goBack(); else exitMail(); return; }
        if (webView != null && webView.canGoBack()) webView.goBack();
    }
    @Override public void onBackPressed() {
        if (mailMode) { goBack(); return; }
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onResume() { super.onResume(); checkLock(); checkRev(); reloadAliases(); scheduleServiceScan(activeProfile); refreshStatus(); ticker.removeCallbacks(tick); ticker.post(tick); ticker.removeCallbacks(limitTick); ticker.postDelayed(limitTick, 6000); }
    @Override protected void onPause() { OrbitBrowserPlugin.lastActive = System.currentTimeMillis(); ticker.removeCallbacks(tick); ticker.removeCallbacks(limitTick); super.onPause(); }
    /** Alias Manager deleted an alias (and its profile) while Orbit was in the background: pick up the new state. */
    private void checkRev() {
        long r = prefs.getLong("rev", 0);
        if (r == loadedRev) return;
        loadedRev = r;
        loadProfiles(); loadLinks(); loadMeta();
        java.util.HashSet<String> valid = new java.util.HashSet<>();
        for (String n : profileNames) valid.add(keyOf(n));
        java.util.Iterator<Map.Entry<String, WebView>> it = views.entrySet().iterator();
        while (it.hasNext()) { Map.Entry<String, WebView> e = it.next(); if (!valid.contains(e.getKey())) { if (e.getValue() == webView) webView = null; destroyView(e.getValue()); it.remove(); } }
        erasePendingNow();
        if (profileSupported && views.get(keyOf(activeProfile)) != webView) showProfile(activeProfile);
        renderTabs(); refreshStatus();
    }
    private void linkAlias() {
        reloadAliases();
        if (aliases.isEmpty()) { showMessage("No aliases found. Add an email in Alias Manager first, then open Orbit Browser again.\n\n" + aliasDebug); return; }
        final String profile = activeProfile;
        final String[] items = new String[aliases.size() + 1];
        items[0] = "— No alias —";
        for (int i = 0; i < aliases.size(); i++) {
            String id = aliases.get(i)[0], email = aliases.get(i)[1];
            String other = profileLinkedTo(id);
            items[i + 1] = email + (other != null && !other.equals(profile) ? "  (now: " + other + ")" : "");
        }
        new AlertDialog.Builder(this).setTitle("Alias for " + profile).setItems(items, (d, which) -> {
            try {
                if (which == 0) { links.remove(profile); }
                else {
                    String id = aliases.get(which - 1)[0];
                    String other = profileLinkedTo(id);
                    if (other != null) links.remove(other); // one alias <-> one profile
                    links.put(profile, id);
                }
                saveLinks();
            } catch (Exception ignored) { }
            refreshStatus();
            if (which > 0) afterLink(profile);
        }).setNegativeButton("Cancel", null).show();
    }
    /** Right after a profile gets an alias: fill the login email, tell Alias Manager it is logged in, start a waiting chat. */
    private void afterLink(String profile) {
        if (webView == null) return;
        String u = webView.getUrl();
        maybeFillEmail(webView, u, profile);
        if (u != null && LOGGED_IN_URL.matcher(u).find()) onLoggedInPage(profile);
        servicesSent.remove(keyOf(profile)); reportServices(profile);
        if (pendingChat != null && pendingChat[0].equals(profile)) { String[] pc = pendingChat; pendingChat = null; handleNewChat(profile, pc[2], pc[1]); }
    }
    private void queueEvent(JSONObject ev) {
        try {
            synchronized (LOCK) {
                JSONArray q = new JSONArray(prefs.getString("events", "[]"));
                q.put(ev);
                prefs.edit().putString("events", q.toString()).commit();
            }
        } catch (Exception ignored) { }
    }
    /** A logged-in claude.ai page is showing in this profile. Linked -> tell Alias Manager; not linked -> ask which alias (once). */
    private void onLoggedInPage(String forProfile) {
        String aliasId = links.optString(forProfile, "");
        if (aliasId.isEmpty() || linkedEmail(forProfile) == null) {
            if (!aliases.isEmpty() && !isFinishing() && !mailMode && forProfile.equals(activeProfile) && promptedLogin.add(forProfile)) {
                Toast.makeText(this, forProfile + " is logged in. Pick its alias.", Toast.LENGTH_LONG).show();
                linkAlias();
            }
            return;
        }
        if (!loginSent.add(forProfile + "|" + aliasId)) return;
        try { queueEvent(new JSONObject().put("type", "login").put("aliasId", aliasId).put("profile", forProfile).put("ts", System.currentTimeMillis())); } catch (Exception ignored) { }
    }
    private String profileLinkedTo(String aliasId) {
        java.util.Iterator<String> it = links.keys();
        while (it.hasNext()) { String p = it.next(); if (aliasId.equals(links.optString(p, ""))) return p; }
        return null;
    }
    /** Called for every URL change (incl. single-page navigation). A "first chat" is: home page of an AI -> its conversation page. */
    private void onUrlChanged(String forProfile, String url) {
        if (url == null) return;
        String ukey = keyOf(forProfile);
        String prev = lastUrls.get(ukey);
        if (url.equals(prev)) return;
        lastUrls.put(ukey, url);
        trackUrlLogin(ukey, forProfile, url);
        if (LOGGED_IN_URL.matcher(url).find()) onLoggedInPage(forProfile);
        for (String[] p : providers) {
            if (p[7].isEmpty()) continue;
            Matcher m;
            try { m = Pattern.compile(p[7]).matcher(url); } catch (Exception e) { continue; }
            if (!m.find() || m.groupCount() < 1 || m.group(1) == null) continue;
            if (prev == null) return;
            boolean prevIsHome;
            if (p[0].equals("claude")) prevIsHome = NEW_CHAT_PAGE.matcher(prev).find();
            else prevIsHome = p[0].equals(providerIdForUrl(prev)) && !chatUrlMatches(p, prev);
            if (!prevIsHome) return;
            chatStarted(forProfile, p[0], m.group(1).toLowerCase());
            return;
        }
    }
    private static boolean chatUrlMatches(String[] p, String url) {
        try { return !p[7].isEmpty() && Pattern.compile(p[7]).matcher(url).find(); } catch (Exception e) { return false; }
    }
    private void chatStarted(String forProfile, String pid, String chatId) {
        String sid = pid.equals("claude") ? chatId : pid + ":" + chatId;
        if (isSeen(forProfile, sid)) return; // already counted
        if (autoStart && (links.optString(forProfile, "").isEmpty() || linkedEmail(forProfile) == null)) {
            // A chat was started but this profile has no alias yet: ask now, and start the timer right after.
            pendingChat = new String[]{forProfile, chatId, pid};
            if (!aliases.isEmpty() && !isFinishing() && !mailMode && forProfile.equals(activeProfile) && promptedChats.add(forProfile + "|" + sid)) {
                Toast.makeText(this, "Chat detected. Pick the alias for " + forProfile + " to start its timer.", Toast.LENGTH_LONG).show();
                linkAlias();
            }
            return;
        }
        handleNewChat(forProfile, pid, chatId);
    }
    private void handleNewChat(String forProfile, String pid, String chatId) {
        String sid = pid.equals("claude") ? chatId : pid + ":" + chatId;
        if (!markSeen(forProfile, sid)) return;
        if (!autoStart) return; // chat is remembered, but no timer is started while auto-start is off
        String aliasId = links.optString(forProfile, "");
        String email = linkedEmail(forProfile);
        if (aliasId.isEmpty() || email == null) return;
        try {
            long now = System.currentTimeMillis();
            JSONObject ev = new JSONObject().put("aliasId", aliasId).put("profile", forProfile).put("chatId", chatId).put("ts", now);
            if (!pid.equals("claude")) ev.put("service", pid);
            queueEvent(ev);
            String tk = timerKey(aliasId, pid); long win = windowMs(pid);
            Long st = started.get(tk);
            if (st == null || now - st >= win) { started.put(tk, now); OrbitReminderReceiver.add(this, tk, reminderLabel(email, pid), now + win); } // first chat of a new window
            refreshStatus();
            Toast.makeText(this, "Chat detected: " + email + (pid.equals("claude") ? "" : " · " + providerName(pid)), Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) { }
    }
    private boolean isSeen(String profile, String chatId) {
        try {
            JSONArray ids = new JSONObject(prefs.getString("seen", "{}")).optJSONArray(profile);
            if (ids != null) for (int i = 0; i < ids.length(); i++) if (chatId.equals(ids.optString(i))) return true;
        } catch (Exception ignored) { }
        return false;
    }
    /** @return true if chatId is new for this profile (and remembers it). Keeps the last 300 ids. */
    private boolean markSeen(String profile, String chatId) {
        try {
            JSONObject all = new JSONObject(prefs.getString("seen", "{}"));
            JSONArray ids = all.optJSONArray(profile);
            if (ids == null) ids = new JSONArray();
            for (int i = 0; i < ids.length(); i++) if (chatId.equals(ids.optString(i))) return false;
            ids.put(chatId);
            if (ids.length() > 300) { JSONArray t = new JSONArray(); for (int i = ids.length() - 300; i < ids.length(); i++) t.put(ids.optString(i)); ids = t; }
            all.put(profile, ids);
            prefs.edit().putString("seen", all.toString()).apply();
            return true;
        } catch (Exception e) { return false; }
    }
    private void saveProfiles() {
        prefs.edit().putString("profiles", android.text.TextUtils.join("\n", profileNames)).putString("active", activeProfile).apply();
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView label(String text, float size) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(Color.rgb(235,238,248)); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private TextView button(String text, Runnable action) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(13); t.setGravity(Gravity.CENTER); t.setTextColor(Color.WHITE);
        t.setPadding(dp(10),dp(6),dp(10),dp(6)); t.setBackground(rounded(Color.rgb(39,45,64), 10)); t.setClickable(true); t.setFocusable(true); t.setOnClickListener(v -> action.run()); return t;
    }
    private TextView iconButton(String text, Runnable action) {
        TextView t = button(text, action); t.setTextSize(16); t.setPadding(0,0,0,0); return t;
    }
    // ---- Which AIs is this profile signed in to? Looks only at cookie NAMES (never values) of the profile's own sign-in cookies. ----
    private boolean scanCookieOk = true; // false when this WebView version could not be asked for cookies
    /** @return provider ids the profile is signed in to: sign-in cookie seen (names only) or a logged-in page was seen (providers without a known cookie). */
    private List<String> scanConnected(String key) {
        List<String> out = new ArrayList<>(); scanCookieOk = false;
        try {
            Object prof = ProfileStore.getInstance().getProfile(key);
            if (prof == null) scanCookieOk = true; // no data yet
            else {
                Class<?> pc = Class.forName("androidx.webkit.Profile");
                android.webkit.CookieManager cm = (android.webkit.CookieManager) pc.getMethod("getCookieManager").invoke(prof);
                if (cm != null) {
                    for (String[] p : providers) {
                        if (p[3].isEmpty()) continue;
                        String header = cm.getCookie(p[2]);
                        if (header != null && hasCookieNamed(header, p[3])) out.add(p[0]);
                    }
                    scanCookieOk = true;
                }
            }
        } catch (Throwable t) { scanCookieOk = false; }
        for (String id : urlConnSet(key)) if (!out.contains(id)) out.add(id);
        return out;
    }
    /** Cookie name rules: "name" = exact match, "name*" = starts with (e.g. chunked session cookies .0 .1). */
    private static boolean hasCookieNamed(String header, String rulesCsv) {
        String[] rules = rulesCsv.split(",");
        for (String part : header.split(";")) {
            String nm = part.trim(); int eq = nm.indexOf('='); if (eq > 0) nm = nm.substring(0, eq);
            for (String r : rules) {
                if (r.isEmpty()) continue;
                if (r.endsWith("*") ? nm.startsWith(r.substring(0, r.length() - 1)) : nm.equals(r)) return true;
            }
        }
        return false;
    }
    // ---- AIs with no known sign-in cookie (DeepSeek ...): a logged-in page URL marks it connected, its login page clears it ----
    private Set<String> urlConnSet(String key) {
        Set<String> out = new LinkedHashSet<>();
        try { JSONArray a = new JSONObject(prefs.getString("url_conn", "{}")).optJSONArray(key); if (a != null) for (int i = 0; i < a.length(); i++) out.add(a.optString(i)); } catch (Exception ignored) { }
        return out;
    }
    private void saveUrlConn(String key, Set<String> set) {
        try {
            JSONObject all = new JSONObject(prefs.getString("url_conn", "{}"));
            if (set.isEmpty()) all.remove(key); else all.put(key, new JSONArray(set));
            prefs.edit().putString("url_conn", all.toString()).apply();
        } catch (Exception ignored) { }
    }
    private void trackUrlLogin(String key, String name, String url) {
        if (url == null) return;
        for (String[] p : providers) {
            if (p[5].isEmpty()) continue;
            boolean in, out = false;
            try { in = Pattern.compile(p[5]).matcher(url).find(); if (!p[6].isEmpty()) out = Pattern.compile(p[6]).matcher(url).find(); } catch (Exception e) { continue; }
            if (!in && !out) continue;
            Set<String> set = urlConnSet(key);
            boolean changed = out ? set.remove(p[0]) : set.add(p[0]);
            if (changed) { saveUrlConn(key, set); scheduleServiceScan(name); }
        }
    }
    /** Cookie header of a page in one profile (used for downloads and the cookie-name debug list). */
    private String cookieFor(String key, String url) {
        try {
            Object prof = ProfileStore.getInstance().getProfile(key);
            if (prof == null) return null;
            Class<?> pc = Class.forName("androidx.webkit.Profile");
            android.webkit.CookieManager cm = (android.webkit.CookieManager) pc.getMethod("getCookieManager").invoke(prof);
            return cm == null ? null : cm.getCookie(url);
        } catch (Throwable t) { return null; }
    }
    private void showCookieNames() {
        WebView c = cur(); String url = c == null ? null : c.getUrl();
        if (url == null) { showMessage("No page is open."); return; }
        String header = cookieFor(mailMode ? MAIL_KEY : keyOf(activeProfile), url);
        StringBuilder sb = new StringBuilder();
        if (header != null) for (String part : header.split(";")) { String nm = part.trim(); int eq = nm.indexOf('='); if (eq > 0) nm = nm.substring(0, eq); if (!nm.isEmpty()) { if (sb.length() > 0) sb.append(", "); sb.append(nm); } }
        String host = ""; try { host = Uri.parse(url).getHost(); } catch (Exception ignored) { }
        showMessage("Cookie NAMES for " + host + ":\n\n" + (sb.length() == 0 ? "(none)" : sb.toString()) + "\n\nValues are never shown. If an AI never gets a ✓ after you sign in, send this list to fix its detection.");
    }
    private void scheduleServiceScan(final String name) {
        if (name == null) return;
        if (scanTask != null) ticker.removeCallbacks(scanTask);
        scanTask = () -> reportServices(name);
        ticker.postDelayed(scanTask, 1500);
    }
    private void reportServices(String name) {
        if (name == null || isFinishing() || !profileNames.contains(name)) return;
        String key = keyOf(name);
        List<String> con = scanConnected(key);
        connectedByKey.put(key, new LinkedHashSet<>(con));
        renderServiceChips();
        String aliasId = links.optString(name, "");
        if (aliasId.isEmpty() || linkedEmail(name) == null) {
            if (!con.isEmpty() && !aliases.isEmpty() && !mailMode && name.equals(activeProfile) && promptedLogin.add(name)) {
                Toast.makeText(this, name + " is signed in. Pick its alias.", Toast.LENGTH_LONG).show();
                linkAlias();
            }
            return;
        }
        JSONArray checked = new JSONArray(), conn = new JSONArray();
        for (String[] p : providers) if ((!p[3].isEmpty() && scanCookieOk) || !p[5].isEmpty()) checked.put(p[0]);
        for (String id : con) conn.put(id);
        String sig = aliasId + "|" + conn.toString();
        if (sig.equals(servicesSent.get(key))) return;
        servicesSent.put(key, sig);
        try { queueEvent(new JSONObject().put("type", "services").put("aliasId", aliasId).put("checked", checked).put("connected", conn).put("ts", System.currentTimeMillis())); } catch (Exception ignored) { }
    }
    private void renderServiceChips() {
        if (svcRow == null) return;
        String cur = providerIdForUrl(webView == null ? null : webView.getUrl()); if (cur == null) cur = "";
        String key = keyOf(activeProfile);
        Set<String> con = connectedByKey.get(key);
        StringBuilder sig = new StringBuilder(key).append('#').append(cur);
        for (String[] p : providers) sig.append('|').append(p[0]).append(con != null && con.contains(p[0]) ? '1' : '0');
        if (sig.toString().equals(svcSig)) return;
        svcSig = sig.toString();
        svcRow.removeAllViews();
        for (final String[] p : providers) {
            boolean on = p[0].equals(cur), ok = con != null && con.contains(p[0]);
            TextView t = new TextView(this);
            t.setText((ok ? "✓ " : "") + p[1]); t.setTextSize(12); t.setGravity(Gravity.CENTER); t.setSingleLine(true);
            t.setTextColor(on ? Color.WHITE : (ok ? Color.rgb(120, 220, 160) : Color.rgb(170, 180, 205)));
            t.setPadding(dp(11), 0, dp(11), 0); t.setBackground(rounded(on ? PURPLE : Color.rgb(31, 36, 52), 14));
            t.setOnClickListener(v -> openService(p[0]));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(28)); lp.setMargins(dp(2), 0, dp(2), 0);
            svcRow.addView(t, lp);
        }
    }
    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radiusDp)); return g;
    }
    private void setLoadProgress(int p) {
        if (progressBar == null || webHost == null) return;
        if (p >= 100) { progressBar.setVisibility(View.GONE); return; }
        progressBar.setVisibility(View.VISIBLE);
        android.view.ViewGroup.LayoutParams lp = progressBar.getLayoutParams();
        lp.width = Math.max(dp(8), webHost.getWidth() * p / 100); progressBar.setLayoutParams(lp);
    }
    /** Shared by every page: loading bar + file chooser, so Upload / Choose file buttons open Android's file picker. */
    private WebChromeClient newChromeClient() {
        return new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) { if (v == webView || v == mailView) setLoadProgress(p); }
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb; camFile = null; camUri = null;
                try {
                    Intent launch = params.createIntent();
                    String[] acc = params.getAcceptTypes();
                    boolean any = acc == null || acc.length == 0, img = any;
                    if (!any) { boolean allEmpty = true; for (String a : acc) { if (a != null && !a.trim().isEmpty()) { allEmpty = false; if (a.contains("image") || a.contains("*/*")) img = true; } } if (allEmpty) img = true; }
                    Intent cam = img ? cameraIntent() : null;
                    if (cam != null) {
                        if (params.isCaptureEnabled()) launch = cam;
                        else { Intent ch = Intent.createChooser(launch, "Choose a file or take a photo"); ch.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam}); launch = ch; }
                    }
                    skipLockOnce = true;
                    startActivityForResult(launch, REQ_FILE);
                } catch (Exception e) { fileCb = null; cb.onReceiveValue(null); Toast.makeText(OrbitBrowserActivity.this, "No file picker available", Toast.LENGTH_SHORT).show(); return false; }
                return true;
            }
        };
    }
    /** Camera app intent that writes into our cache folder through the app's FileProvider; null if that is not possible (the picker still works). */
    private Intent cameraIntent() {
        try {
            java.io.File dir = new java.io.File(getCacheDir(), "orbit_cam"); dir.mkdirs();
            java.io.File f = new java.io.File(dir, "photo_" + System.currentTimeMillis() + ".jpg");
            Uri u = androidx.core.content.FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            Intent c = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            c.putExtra(MediaStore.EXTRA_OUTPUT, u);
            c.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            camFile = f; camUri = u;
            return c;
        } catch (Throwable t) { camFile = null; camUri = null; return null; }
    }
    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE) {
            if (fileCb != null) {
                Uri[] result = null;
                if (res == RESULT_OK) {
                    result = WebChromeClient.FileChooserParams.parseResult(res, data);
                    if (result == null && camUri != null && camFile != null && camFile.length() > 0) result = new Uri[]{camUri}; // photo from the camera
                }
                fileCb.onReceiveValue(result); fileCb = null;
            }
            camFile = null; camUri = null;
            return;
        }
        if (req == REQ_UNLOCK) {
            if (res == RESULT_OK) unlocked(); else finish();
            return;
        }
        if (req == REQ_TREE) {
            if (res == RESULT_OK && data != null && data.getData() != null) setCustomDir(treeKey, treePid, data.getData());
            return;
        }
        super.onActivityResult(req, res, data);
    }
    // ---- App lock ----
    private void checkLock() {
        if (skipLockOnce) { skipLockOnce = false; return; }
        if (locked || !prefs.getBoolean("app_lock", false)) return;
        long last = OrbitBrowserPlugin.lastActive;
        if (last != 0 && System.currentTimeMillis() - last < 30000) return;
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        Intent i = (km != null && km.isDeviceSecure()) ? km.createConfirmDeviceCredentialIntent("Orbit Browser", "Unlock to continue") : null;
        if (i == null) return; // the phone has no screen lock: nothing to ask for
        locked = true;
        lockCover = new View(this); lockCover.setBackgroundColor(Color.BLACK);
        addContentView(lockCover, new android.view.ViewGroup.LayoutParams(-1, -1));
        try { startActivityForResult(i, REQ_UNLOCK); } catch (Exception e) { unlocked(); }
    }
    private void unlocked() {
        locked = false; OrbitBrowserPlugin.lastActive = System.currentTimeMillis();
        if (lockCover != null && lockCover.getParent() instanceof android.view.ViewGroup) ((android.view.ViewGroup) lockCover.getParent()).removeView(lockCover);
        lockCover = null;
    }
    // ---- Google blocks sign-in inside in-app browsers. Orbit does not disguise itself to get around that; it explains and offers a way out. ----
    private void checkGoogleBlock(String url, String forProfile) {
        if (url == null || forProfile == null || !url.contains("accounts.google.com")) return;
        String low = url.toLowerCase();
        if (!(low.contains("disallowed_useragent") || low.contains("/signin/rejected") || low.contains("deniedsigninrejected") || low.contains("/signin/oauth/error"))) return;
        if (!googleWarned.add(forProfile)) return;
        showGoogleBlocked(forProfile);
    }
    private void showGoogleBlocked(final String profile) {
        if (isFinishing()) return;
        final String pid = "gemini";
        final String aliasId = links.optString(profile, "");
        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle("Google sign-in")
            .setMessage("Google does not allow sign-in inside in-app browsers like this one, so Gemini and \"Sign in with Google\" may be refused here. Orbit does not hide itself to get around that.\n\nWhat works: sign in with email + password / email code on sites that offer it. For Gemini: sign in with Chrome, and tick Gemini yourself (long-press its chip in Alias Manager).")
            .setPositiveButton("Open Gemini in Chrome", (d, w) -> { try { Intent v = new Intent(Intent.ACTION_VIEW, Uri.parse("https://gemini.google.com/app")); v.addCategory(Intent.CATEGORY_BROWSABLE); startActivity(v); } catch (Exception e) { Toast.makeText(this, "No browser found", Toast.LENGTH_SHORT).show(); } })
            .setNegativeButton("Close", null);
        if (!aliasId.isEmpty()) b.setNeutralButton("Tick Gemini ✓ (signed in elsewhere)", (d, w) -> {
            try { queueEvent(new JSONObject().put("type", "mark").put("aliasId", aliasId).put("service", pid).put("ts", System.currentTimeMillis())); Toast.makeText(this, "Gemini ticked for " + linkedEmail(profile), Toast.LENGTH_SHORT).show(); } catch (Exception ignored) { }
        });
        b.show();
    }
    // ---- Downloads: normal links through Android's DownloadManager (with this profile's cookies), blob:/data: files through a small bridge ----
    public final class DlBridge {
        volatile boolean allowed = false; volatile String blobUrl = "", cd = "", sub = "Orbit", proj = ""; volatile Uri tree; java.io.File tmp; long total = 0;
        @JavascriptInterface public void chunk(int i, int n, String b64) {
            if (!allowed) return;
            try {
                if (i == 0) { tmp = new java.io.File(getCacheDir(), "orbit_dl.tmp"); total = 0; if (tmp.exists()) tmp.delete(); }
                if (tmp == null) return;
                byte[] bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
                total += bytes.length;
                if (total > 80L * 1024 * 1024) { tmp.delete(); tmp = null; toastUi("File is too large (max 80 MB)"); return; }
                try (java.io.FileOutputStream fo = new java.io.FileOutputStream(tmp, true)) { fo.write(bytes); }
            } catch (Exception e) { tmp = null; }
        }
        @JavascriptInterface public void done(String mime) {
            if (!allowed || tmp == null) return;
            java.io.File f = tmp; tmp = null;
            String mt = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
            saveToDownloads(f, URLUtil.guessFileName(blobUrl, cd, mt), mt, sub, tree, proj);
        }
        @JavascriptInterface public void fail(String msg) { toastUi("Download failed"); }
    }
    private void toastUi(final String msg) { runOnUiThread(() -> Toast.makeText(OrbitBrowserActivity.this, msg, Toast.LENGTH_LONG).show()); }
    private boolean trustedHost(String url) {
        if (url == null) return false;
        if (providerIdForUrl(url) != null) return true;
        try { String h = Uri.parse(url).getHost(); return h != null && (h.equals("mail.google.com") || h.endsWith(".googleusercontent.com")); } catch (Exception e) { return false; }
    }
    // ---- Step 12c: simple file manager for Downloads/Orbit (list, date/time, size, NEW badge, newest first). Delete/rename = 12d. ----
    private static final class FRow { String rel = "", name = ""; long size, modMs, id; java.io.File file; }
    private AlertDialog filesDlg;
    private static final long DAY_MS = 24L * 3600L * 1000L;
    private static String fmtSize(long b) {
        if (b < 1024) return b + " B";
        double k = b / 1024.0; if (k < 1024) return String.format(java.util.Locale.US, "%.0f KB", k);
        double m = k / 1024.0; if (m < 1024) return String.format(java.util.Locale.US, "%.1f MB", m);
        return String.format(java.util.Locale.US, "%.2f GB", m / 1024.0);
    }
    private static String fmtDate(long ms) {
        return ms <= 0 ? "?" : new java.text.SimpleDateFormat("MMM d, yyyy h:mm a", java.util.Locale.getDefault()).format(new java.util.Date(ms));
    }
    private CharSequence twoLine(String a, String b, boolean isNew) {
        String second = (isNew ? "● NEW · " : "") + b;
        android.text.SpannableString ss = new android.text.SpannableString(a + "\n" + second);
        int st = a.length() + 1;
        ss.setSpan(new android.text.style.RelativeSizeSpan(0.8f), st, ss.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ss.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(150, 160, 180)), st, ss.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (isNew) ss.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(80, 200, 120)), st, st + 5, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return ss;
    }
    /** Every file under Downloads/Orbit that this app can see (Android 10+: MediaStore; older: the app's own Downloads/Orbit folder). Run off the UI thread. */
    private List<FRow> queryFiles() {
        List<FRow> out = new ArrayList<>();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                String[] proj = { MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.RELATIVE_PATH, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_MODIFIED, MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns._ID };
                String base = Environment.DIRECTORY_DOWNLOADS + "/Orbit/";
                try (android.database.Cursor c = getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, proj, MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?", new String[]{ base + "%" }, null)) {
                    if (c != null) while (c.moveToNext()) {
                        String nm = c.getString(0), rp = c.getString(1);
                        if (nm == null || rp == null || !rp.startsWith(base)) continue;
                        FRow r = new FRow(); r.name = nm; r.rel = rp.substring(base.length()); r.size = c.getLong(2);
                        long m = c.getLong(3), a = c.getLong(4); r.modMs = (m > 0 ? m : a) * 1000L; r.id = c.getLong(5);
                        out.add(r);
                    }
                }
            } else {
                java.io.File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (dir != null) walkLegacy(new java.io.File(dir, "Orbit"), "", out);
            }
        } catch (Exception e) { toastUi("Could not list files: " + e.getMessage()); }
        return out;
    }
    private void walkLegacy(java.io.File d, String rel, List<FRow> out) {
        java.io.File[] ls = d.listFiles(); if (ls == null) return;
        for (java.io.File f : ls) {
            if (f.isDirectory()) walkLegacy(f, rel + f.getName() + "/", out);
            else { FRow r = new FRow(); r.name = f.getName(); r.rel = rel; r.size = f.length(); r.modMs = f.lastModified(); r.file = f; out.add(r); }
        }
    }
    private void openFiles(final String cur) {
        Toast.makeText(this, "Loading files…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            final List<FRow> rows = queryFiles();
            runOnUiThread(() -> { if (!isFinishing()) showFiles(rows, cur); });
        }).start();
    }
    private void showFiles(final List<FRow> rows, final String cur) {
        if (filesDlg != null) { try { filesDlg.dismiss(); } catch (Exception ignored) { } filesDlg = null; }
        final long now = System.currentTimeMillis();
        final Map<String, long[]> folders = new HashMap<>();   // folder name -> {file count, latest modified, total size}
        final List<FRow> files = new ArrayList<>();
        for (FRow r : rows) {
            if (!r.rel.startsWith(cur)) continue;
            if (r.rel.length() == cur.length()) { files.add(r); continue; }
            String rest = r.rel.substring(cur.length());
            int sl = rest.indexOf('/'); String seg = sl < 0 ? rest : rest.substring(0, sl);
            if (seg.isEmpty()) continue;
            long[] f = folders.get(seg); if (f == null) { f = new long[3]; folders.put(seg, f); }
            f[0]++; f[1] = Math.max(f[1], r.modMs); f[2] += r.size;
        }
        final List<String> fnames = new ArrayList<>(folders.keySet());
        java.util.Collections.sort(fnames, (a, b) -> Long.compare(folders.get(b)[1], folders.get(a)[1]));
        java.util.Collections.sort(files, (a, b) -> Long.compare(b.modMs, a.modMs));
        final List<CharSequence> items = new ArrayList<>();
        final List<Object> targets = new ArrayList<>();   // Boolean.TRUE = up, Boolean.FALSE = empty note, String = folder name, FRow = file
        if (!cur.isEmpty()) { items.add("⬆  .. (up)"); targets.add(Boolean.TRUE); }
        for (String fn : fnames) {
            long[] f = folders.get(fn);
            items.add(twoLine("📁  " + fn, f[0] + (f[0] == 1 ? " file" : " files") + " · " + fmtSize(f[2]) + " · latest " + fmtDate(f[1]), now - f[1] < DAY_MS));
            targets.add(fn);
        }
        for (FRow r : files) {
            items.add(twoLine(r.name, fmtDate(r.modMs) + " · " + fmtSize(r.size), now - r.modMs < DAY_MS));
            targets.add(r);
        }
        if (fnames.isEmpty() && files.isEmpty()) { items.add("(nothing here yet — files you download in Orbit appear here)"); targets.add(Boolean.FALSE); }
        String where = cur.isEmpty() ? "" : " / " + cur.substring(0, cur.length() - 1).replace("/", " / ");
        filesDlg = new AlertDialog.Builder(this).setTitle("Orbit files" + where)
            .setItems(items.toArray(new CharSequence[0]), (d, w) -> {
                Object t = targets.get(w);
                if (t instanceof FRow) { showFileInfo(rows, cur, (FRow) t); }
                else if (t instanceof String) { showFiles(rows, cur + (String) t + "/"); }
                else if (Boolean.TRUE.equals(t)) {
                    String up = cur.substring(0, cur.length() - 1); int i = up.lastIndexOf('/');
                    showFiles(rows, i < 0 ? "" : up.substring(0, i + 1));
                } else showFiles(rows, cur);
            })
            .setPositiveButton("Delete…", (d, w) -> showMultiDelete(rows, cur, fnames, files))
            .setNeutralButton("Refresh", (d, w) -> openFiles(cur))
            .setNegativeButton("Close", null).create();
        filesDlg.show();
        try {
            filesDlg.getListView().setOnItemLongClickListener((parent, itemView, pos, rowId) -> {
                if (pos >= 0 && pos < targets.size() && targets.get(pos) instanceof String) { showFolderMenu(rows, cur, (String) targets.get(pos)); return true; }
                return false;
            });
        } catch (Exception ignored) { }
    }
    private void showFileInfo(final List<FRow> rows, final String cur, final FRow r) {
        String msg = r.name + "\n\nFolder: Downloads/Orbit/" + r.rel + "\nUpdated: " + fmtDate(r.modMs) + "\nSize: " + fmtSize(r.size)
            + (System.currentTimeMillis() - r.modMs < DAY_MS ? "\n\n● NEW (last 24 hours)" : "");
        new AlertDialog.Builder(this).setTitle("File").setMessage(msg)
            .setPositiveButton("Back", (d, w) -> showFiles(rows, cur))
            .setNeutralButton("Rename", (d, w) -> askRenameFile(rows, cur, r))
            .setNegativeButton("Delete", (d, w) -> confirmDeleteFiles(rows, cur, new ArrayList<String>(), java.util.Collections.singletonList(r)))
            .setOnCancelListener(d -> showFiles(rows, cur)).show();
    }
    // ---- Step 12d: delete (one / many / whole folder) and rename (file / folder). Rename has NO extension warning (user's choice). ----
    private static String safeFileName(String s) {
        String r = (s == null ? "" : s).replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (r.length() > 120) r = r.substring(0, 120).trim();
        return r.isEmpty() ? "file" : r;
    }
    private Uri rowUri(FRow r) { return android.content.ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, r.id); }
    /** null = deleted, otherwise the reason. */
    private String deleteRow(FRow r) {
        try {
            if (r.file != null) return r.file.delete() ? null : "could not delete";
            return getContentResolver().delete(rowUri(r), null, null) > 0 ? null : "not found";
        } catch (SecurityException e) { return "not allowed (file was not created by Orbit)"; }
        catch (Exception e) { return String.valueOf(e.getMessage()); }
    }
    /** null = renamed, otherwise the reason. */
    private String renameRow(FRow r, String newName) {
        try {
            if (r.file != null) return r.file.renameTo(new java.io.File(r.file.getParentFile(), newName)) ? null : "could not rename";
            android.content.ContentValues cv = new android.content.ContentValues(); cv.put(MediaStore.MediaColumns.DISPLAY_NAME, newName);
            return getContentResolver().update(rowUri(r), cv, null, null) > 0 ? null : "not found";
        } catch (SecurityException e) { return "not allowed (file was not created by Orbit)"; }
        catch (Exception e) { return String.valueOf(e.getMessage()); }
    }
    private String moveRow(FRow r, String newRel) {
        try {
            android.content.ContentValues cv = new android.content.ContentValues();
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Orbit/" + newRel);
            return getContentResolver().update(rowUri(r), cv, null, null) > 0 ? null : "not found";
        } catch (SecurityException e) { return "not allowed (file was not created by Orbit)"; }
        catch (Exception e) { return String.valueOf(e.getMessage()); }
    }
    private void askRenameFile(final List<FRow> rows, final String cur, final FRow r) {
        final EditText in = new EditText(this); in.setSingleLine(true); in.setText(r.name);
        int dot = r.name.lastIndexOf('.'); in.setSelection(0, dot > 0 ? dot : r.name.length());
        new AlertDialog.Builder(this).setTitle("Rename file").setView(in)
            .setPositiveButton("Rename", (d, w) -> {
                final String nn = safeFileName(in.getText().toString());
                if (nn.equals(r.name)) { showFiles(rows, cur); return; }
                for (FRow x : rows) if (x != r && x.rel.equals(r.rel) && x.name.equalsIgnoreCase(nn)) { toastUi("A file named \"" + nn + "\" already exists here"); showFiles(rows, cur); return; }
                new Thread(() -> { String err = renameRow(r, nn); toastUi(err == null ? "Renamed" : "Could not rename: " + err); runOnUiThread(() -> openFiles(cur)); }).start();
            })
            .setNegativeButton("Cancel", (d, w) -> showFiles(rows, cur))
            .setOnCancelListener(d -> showFiles(rows, cur)).show();
    }
    private void showFolderMenu(final List<FRow> rows, final String cur, final String name) {
        String[] items = { "Rename folder", "Delete folder…" };
        new AlertDialog.Builder(this).setTitle("📁  " + name).setItems(items, (d, w) -> {
            if (w == 0) askRenameFolder(rows, cur, name);
            else confirmDeleteFiles(rows, cur, java.util.Collections.singletonList(name), new ArrayList<FRow>());
        }).setNegativeButton("Cancel", null).show();
    }
    private void askRenameFolder(final List<FRow> rows, final String cur, final String name) {
        final EditText in = new EditText(this); in.setSingleLine(true); in.setText(name); in.setSelection(name.length());
        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle("Rename folder").setView(in);
        if (cur.split("/").length < 2) b.setMessage("Note: new downloads still use the profile / AI name, so this folder name will be created again by the next download.");
        b.setPositiveButton("Rename", (d, w) -> {
            final String nn = safeDirName(in.getText().toString());
            if (nn.equals(name)) { showFiles(rows, cur); return; }
            final String oldPre = cur + name + "/", newPre = cur + nn + "/";
            if (!nn.equalsIgnoreCase(name)) for (FRow x : rows) if (x.rel.toLowerCase().startsWith(newPre.toLowerCase())) { toastUi("A folder named \"" + nn + "\" already exists here"); showFiles(rows, cur); return; }
            new Thread(() -> {
                int ok = 0, bad = 0; String why = "";
                if (Build.VERSION.SDK_INT < 29) {
                    java.io.File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    java.io.File from = new java.io.File(new java.io.File(dir, "Orbit"), oldPre), to = new java.io.File(new java.io.File(dir, "Orbit"), newPre);
                    if (from.renameTo(to)) ok = 1; else { bad = 1; why = "could not rename"; }
                } else {
                    for (FRow x : rows) if (x.rel.startsWith(oldPre)) {
                        String err = moveRow(x, newPre + x.rel.substring(oldPre.length()));
                        if (err == null) ok++; else { bad++; why = err; }
                    }
                }
                if (ok > 0) renameProjectInPrefs(cur, name, nn);
                toastUi(bad == 0 ? "Folder renamed" : "Renamed " + ok + ", failed " + bad + ": " + why);
                runOnUiThread(() -> openFiles(cur));
            }).start();
        });
        b.setNegativeButton("Cancel", (d, w) -> showFiles(rows, cur)).setOnCancelListener(d -> showFiles(rows, cur)).show();
    }
    /** If the renamed folder is a project folder (Account/AI/Project), keep the project list in step so downloads keep going there. */
    private void renameProjectInPrefs(String cur, String oldName, String newName) {
        try {
            String[] seg = cur.split("/"); if (seg.length != 2) return;
            String key = null, pid = null;
            for (String n : profileNames) if (safeDirName(n).equals(seg[0])) key = keyOf(n);
            for (String[] p : providers) if (safeDirName(p[1]).equals(seg[1])) pid = p[0];
            if (key == null || pid == null) return;
            List<String> list = projectList(key, pid); String act = activeProject(key, pid); boolean changed = false;
            for (int i = 0; i < list.size(); i++) if (list.get(i).equals(oldName)) { list.set(i, newName); changed = true; }
            if (changed) saveProject(key, pid, list, act.equals(oldName) ? newName : act);
        } catch (Exception ignored) { }
    }
    private void showMultiDelete(final List<FRow> rows, final String cur, final List<String> fnames, final List<FRow> files) {
        final int nf = fnames.size(), total = nf + files.size();
        if (total == 0) { showFiles(rows, cur); return; }
        final String[] labels = new String[total];
        for (int i = 0; i < total; i++) labels[i] = i < nf ? "📁  " + fnames.get(i) : files.get(i - nf).name + "  (" + fmtSize(files.get(i - nf).size) + ")";
        final boolean[] chk = new boolean[total];
        new AlertDialog.Builder(this).setTitle("Select what to delete")
            .setMultiChoiceItems(labels, chk, (d, w, on) -> chk[w] = on)
            .setPositiveButton("Delete selected", (d, w) -> {
                List<String> fs = new ArrayList<>(); List<FRow> fl = new ArrayList<>();
                for (int i = 0; i < total; i++) if (chk[i]) { if (i < nf) fs.add(fnames.get(i)); else fl.add(files.get(i - nf)); }
                if (fs.isEmpty() && fl.isEmpty()) { showFiles(rows, cur); return; }
                confirmDeleteFiles(rows, cur, fs, fl);
            })
            .setNegativeButton("Cancel", (d, w) -> showFiles(rows, cur))
            .setOnCancelListener(d -> showFiles(rows, cur)).show();
    }
    private void confirmDeleteFiles(final List<FRow> rows, final String cur, final List<String> folderNames, final List<FRow> fileRows) {
        final List<FRow> targets = new ArrayList<>(fileRows);
        for (String fn : folderNames) { String pre = cur + fn + "/"; for (FRow x : rows) if (x.rel.startsWith(pre)) targets.add(x); }
        long size = 0; for (FRow x : targets) size += x.size;
        String what = (folderNames.isEmpty() ? "" : folderNames.size() + (folderNames.size() == 1 ? " folder" : " folders") + (fileRows.isEmpty() ? "" : " + "))
            + (fileRows.isEmpty() ? "" : fileRows.size() + (fileRows.size() == 1 ? " file" : " files"));
        String msg = "Delete " + what + "?\n\n" + targets.size() + (targets.size() == 1 ? " file" : " files in total") + " · " + fmtSize(size)
            + (targets.size() == 1 ? "\n" + targets.get(0).name : "") + "\n\nThis cannot be undone.";
        new AlertDialog.Builder(this).setTitle("Delete").setMessage(msg)
            .setPositiveButton("Delete", (d, w) -> new Thread(() -> {
                int ok = 0, bad = 0; String why = "";
                for (FRow x : targets) { String err = deleteRow(x); if (err == null) ok++; else { bad++; why = err; } }
                toastUi(bad == 0 ? "Deleted " + ok + (ok == 1 ? " file" : " files") : "Deleted " + ok + ", failed " + bad + ": " + why);
                runOnUiThread(() -> openFiles(cur));
            }).start())
            .setNegativeButton("Cancel", (d, w) -> showFiles(rows, cur))
            .setOnCancelListener(d -> showFiles(rows, cur)).show();
    }
    // ---- Step 12e: custom download folder per account + AI (Android folder picker / SAF). prefs "custom_dirs" = {"<profileKey>|<aiId>": "<tree uri>"} ----
    private JSONObject loadCustomDirs() { try { return new JSONObject(prefs.getString("custom_dirs", "{}")); } catch (Exception e) { return new JSONObject(); } }
    private Uri customTree(String key, String pid) {
        if (key == null || pid == null) return null;
        String u = loadCustomDirs().optString(key + "|" + pid, "");
        if (u.isEmpty()) return null;
        try {
            Uri t = Uri.parse(u);
            for (android.content.UriPermission up : getContentResolver().getPersistedUriPermissions()) if (up.getUri().equals(t) && up.isWritePermission()) return t;
        } catch (Exception ignored) { }
        return null;   // permission lost -> default folder
    }
    private Uri customTreeFor(WebView v, String key) {
        try {
            if (MAIL_KEY.equals(key)) return null;
            return customTree(key, providerIdForUrl(v == null ? null : v.getUrl()));
        } catch (Exception e) { return null; }
    }
    private String projectFor(WebView v, String key) {
        try {
            String pid = providerIdForUrl(v == null ? null : v.getUrl());
            if (pid == null) return "";
            String p = activeProject(key, pid);
            return p.isEmpty() ? "" : safeDirName(p);
        } catch (Exception e) { return ""; }
    }
    private String treeLabel(Uri tree) {
        try { String id = android.provider.DocumentsContract.getTreeDocumentId(tree); int c = id.indexOf(':'); String r = c >= 0 ? id.substring(c + 1) : id; return r.isEmpty() ? "Internal storage" : r; }
        catch (Exception e) { return "your folder"; }
    }
    private void dropCustomDirs(String key) {
        try {
            JSONObject all = loadCustomDirs(); List<String> rm = new ArrayList<>();
            java.util.Iterator<String> it = all.keys();
            while (it.hasNext()) { String k = it.next(); if (k.startsWith(key + "|")) rm.add(k); }
            for (String k : rm) { try { getContentResolver().releasePersistableUriPermission(Uri.parse(all.optString(k, "")), Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); } catch (Exception ignored) { } all.remove(k); }
            prefs.edit().putString("custom_dirs", all.toString()).apply();
        } catch (Exception ignored) { }
    }
    private void pickCustomDir() {
        final String key = keyOf(activeProfile);
        final String pid = (!mailMode && webView != null) ? providerIdForUrl(webView.getUrl()) : null;
        if (pid == null) { showMessage("Open an AI site first (Claude, ChatGPT, Gemini…). A custom folder belongs to one account + one AI."); return; }
        final Uri cur = customTree(key, pid);
        final String[] items = cur == null ? new String[]{ "Choose a folder…" } : new String[]{ "Choose a different folder…", "Use the default (Downloads/Orbit)" };
        final String now = cur == null ? "default (Downloads/Orbit/" + safeDirName(activeProfile) + "/" + safeDirName(providerName(pid)) + ")" : treeLabel(cur) + " (projects are made inside it)";
        new AlertDialog.Builder(this).setTitle(activeProfile + " · " + providerName(pid) + "\nNow: " + now)
            .setItems(items, (d, w) -> {
                if (w == 0) {
                    treeKey = key; treePid = pid;
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                    skipLockOnce = true;
                    try { startActivityForResult(i, REQ_TREE); } catch (Exception e) { skipLockOnce = false; toastUi("No folder picker found on this phone"); }
                } else clearCustomDir(key, pid);
            }).setNegativeButton("Close", null).show();
    }
    private void setCustomDir(String key, String pid, Uri tree) {
        if (key == null || key.isEmpty() || pid == null || pid.isEmpty()) return;
        try {
            getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            JSONObject all = loadCustomDirs();
            String old = all.optString(key + "|" + pid, "");
            all.put(key + "|" + pid, tree.toString());
            prefs.edit().putString("custom_dirs", all.toString()).apply();
            if (!old.isEmpty() && !old.equals(tree.toString())) { try { getContentResolver().releasePersistableUriPermission(Uri.parse(old), Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); } catch (Exception ignored) { } }
            toastUi("Downloads of " + providerName(pid) + " → " + treeLabel(tree));
        } catch (Exception e) { toastUi("Could not use that folder: " + e.getMessage()); }
    }
    private void clearCustomDir(String key, String pid) {
        try {
            JSONObject all = loadCustomDirs(); String old = all.optString(key + "|" + pid, "");
            all.remove(key + "|" + pid);
            prefs.edit().putString("custom_dirs", all.toString()).apply();
            if (!old.isEmpty()) { try { getContentResolver().releasePersistableUriPermission(Uri.parse(old), Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); } catch (Exception ignored) { } }
            toastUi("Back to Downloads/Orbit");
        } catch (Exception ignored) { }
    }
    /** Child folder of a picked tree (existing one is reused). */
    private Uri childDir(Uri tree, Uri parent, String dirName) throws Exception {
        Uri kids = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, android.provider.DocumentsContract.getDocumentId(parent));
        String[] proj = { android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID, android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME, android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE };
        try (android.database.Cursor c = getContentResolver().query(kids, proj, null, null, null)) {
            if (c != null) while (c.moveToNext())
                if (dirName.equals(c.getString(1)) && android.provider.DocumentsContract.Document.MIME_TYPE_DIR.equals(c.getString(2)))
                    return android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0));
        }
        Uri d = android.provider.DocumentsContract.createDocument(getContentResolver(), parent, android.provider.DocumentsContract.Document.MIME_TYPE_DIR, dirName);
        if (d == null) throw new java.io.IOException("cannot create the project folder");
        return d;
    }
    /** Copies a finished temp file into the picked folder (inside the project sub-folder if one is active). Deletes the temp file on success. */
    private void saveToTree(java.io.File f, String name, Uri tree, String proj) throws Exception {
        Uri parent = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, android.provider.DocumentsContract.getTreeDocumentId(tree));
        if (proj != null && !proj.isEmpty()) parent = childDir(tree, parent, proj);
        Uri doc = android.provider.DocumentsContract.createDocument(getContentResolver(), parent, "application/octet-stream", name);
        if (doc == null) throw new java.io.IOException("cannot create the file there");
        try (java.io.InputStream in = new java.io.FileInputStream(f); java.io.OutputStream o = getContentResolver().openOutputStream(doc)) {
            if (o == null) throw new java.io.IOException("cannot write there");
            byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        }
        f.delete();
    }
    /** Normal link download into a picked folder: DownloadManager cannot write there, so Orbit downloads it itself (with the profile's cookies). */
    private void downloadToCustom(final String url, final String ua, final String cookie, final String name, final String mime, final String sub, final Uri tree, final String proj) {
        toastUi("Downloading " + name + " …");
        new Thread(() -> {
            java.io.File tmp = new java.io.File(getCacheDir(), "orbit_dl_" + System.currentTimeMillis() + ".tmp");
            java.net.HttpURLConnection con = null;
            try {
                con = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                con.setConnectTimeout(20000); con.setReadTimeout(60000); con.setInstanceFollowRedirects(true);
                if (cookie != null && !cookie.isEmpty()) con.setRequestProperty("Cookie", cookie);
                if (ua != null && !ua.isEmpty()) con.setRequestProperty("User-Agent", ua);
                int code = con.getResponseCode();
                if (code < 200 || code >= 300) throw new java.io.IOException("HTTP " + code);
                long total = 0;
                try (java.io.InputStream in = con.getInputStream(); java.io.FileOutputStream fo = new java.io.FileOutputStream(tmp)) {
                    byte[] buf = new byte[65536]; int n;
                    while ((n = in.read(buf)) > 0) { total += n; if (total > 500L * 1024 * 1024) throw new java.io.IOException("file is larger than 500 MB"); fo.write(buf, 0, n); }
                }
                saveToDownloads(tmp, name, (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime, sub, tree, proj);
            } catch (Exception e) { tmp.delete(); toastUi("Could not download: " + e.getMessage()); }
            finally { if (con != null) con.disconnect(); }
        }).start();
    }
    // ---- Step 12b: project folders. Saved per profile KEY + AI id (so renaming a profile keeps them). prefs "projects" = {"<key>|<aiId>": {"list":[names], "active":"name"}} ----
    private JSONObject loadProjects() { try { return new JSONObject(prefs.getString("projects", "{}")); } catch (Exception e) { return new JSONObject(); } }
    private String activeProject(String key, String pid) {
        if (key == null || pid == null) return "";
        JSONObject o = loadProjects().optJSONObject(key + "|" + pid);
        return o == null ? "" : o.optString("active", "");
    }
    private List<String> projectList(String key, String pid) {
        List<String> out = new ArrayList<>();
        JSONObject o = loadProjects().optJSONObject(key + "|" + pid);
        JSONArray a = o == null ? null : o.optJSONArray("list");
        if (a != null) for (int i = 0; i < a.length(); i++) { String n = a.optString(i, "").trim(); if (!n.isEmpty()) out.add(n); }
        return out;
    }
    private void saveProject(String key, String pid, List<String> list, String active) {
        try {
            JSONObject all = loadProjects(), o = new JSONObject();
            JSONArray a = new JSONArray(); for (String n : list) a.put(n);
            o.put("list", a); o.put("active", active == null ? "" : active);
            all.put(key + "|" + pid, o);
            prefs.edit().putString("projects", all.toString()).apply();
        } catch (Exception ignored) { }
    }
    private void dropProjects(String key) {
        try {
            JSONObject all = loadProjects(); List<String> rm = new ArrayList<>();
            java.util.Iterator<String> it = all.keys();
            while (it.hasNext()) { String k = it.next(); if (k.startsWith(key + "|")) rm.add(k); }
            for (String k : rm) all.remove(k);
            prefs.edit().putString("projects", all.toString()).apply();
        } catch (Exception ignored) { }
    }
    /** Menu: choose where this account's downloads of the AI on screen go (AI folder itself, or a project folder inside it). */
    private void pickProject() {
        final String key = keyOf(activeProfile);
        final String pid = (!mailMode && webView != null) ? providerIdForUrl(webView.getUrl()) : null;
        if (pid == null) { showMessage("Open an AI site first (Claude, ChatGPT, Gemini…). A project belongs to one account + one AI."); return; }
        final List<String> list = projectList(key, pid);
        final String active = activeProject(key, pid);
        final int n = list.size();
        final String[] labels = new String[n + 2 + (n > 0 ? 1 : 0)];
        labels[0] = (active.isEmpty() ? "✓  " : "     ") + "No project (" + providerName(pid) + " folder)";
        for (int i = 0; i < n; i++) labels[i + 1] = (list.get(i).equals(active) ? "✓  " : "     ") + list.get(i);
        labels[n + 1] = "＋ New project…";
        if (n > 0) labels[n + 2] = "Remove a project from the list…";
        new AlertDialog.Builder(this).setTitle(activeProfile + " · " + providerName(pid) + " downloads").setItems(labels, (d, w) -> {
            if (w == 0) { saveProject(key, pid, list, ""); toastUi("Downloads → " + providerName(pid) + " folder"); }
            else if (w <= n) { saveProject(key, pid, list, list.get(w - 1)); toastUi("Downloads → " + list.get(w - 1)); }
            else if (w == n + 1) askNewProject(key, pid);
            else askRemoveProject(key, pid);
        }).setNegativeButton("Close", null).show();
    }
    private void askNewProject(final String key, final String pid) {
        final EditText in = new EditText(this); in.setSingleLine(true); in.setHint("Project name");
        new AlertDialog.Builder(this).setTitle("New project folder").setView(in)
            .setPositiveButton("Create", (d, w) -> {
                String clean = in.getText().toString().replace("\n", " ").trim();
                if (clean.isEmpty() || clean.length() > 40) { showMessage("Use 1 to 40 characters."); return; }
                clean = safeDirName(clean);
                List<String> list = projectList(key, pid);
                String found = null; for (String x : list) if (x.equalsIgnoreCase(clean)) found = x;
                if (found == null) { list.add(clean); found = clean; }
                saveProject(key, pid, list, found);
                toastUi("Downloads → " + found + " (folder is created with the first download)");
            }).setNegativeButton("Cancel", null).show();
    }
    private void askRemoveProject(final String key, final String pid) {
        final List<String> list = projectList(key, pid);
        if (list.isEmpty()) return;
        final String[] labels = list.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Remove from the list (files stay on the phone)").setItems(labels, (d, w) -> {
            String gone = list.get(w); String act = activeProject(key, pid);
            list.remove(w);
            saveProject(key, pid, list, gone.equals(act) ? "" : act);
            toastUi("Removed \"" + gone + "\" from the list");
        }).setNegativeButton("Cancel", null).show();
    }
    /** Folder inside Downloads for a file: Orbit/<profile name>/<AI name> (Gmail attachments: Orbit/Gmail). Step 12a. Call on the UI thread. */
    private String orbitSubPath(WebView v, String key) {
        try {
            if (MAIL_KEY.equals(key)) return "Orbit/Gmail";
            String who = nameOfKey(key);
            String pid = providerIdForUrl(v == null ? null : v.getUrl());
            String proj = (pid == null) ? "" : activeProject(key, pid);
            return "Orbit/" + safeDirName(who == null ? "Account" : who) + "/" + safeDirName(pid == null ? "Other" : providerName(pid)) + (proj.isEmpty() ? "" : "/" + safeDirName(proj));
        } catch (Exception e) { return "Orbit"; }
    }
    private static String safeDirName(String s) {
        String r = (s == null ? "" : s).replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim().replaceAll("^\\.+", "");
        if (r.length() > 60) r = r.substring(0, 60).trim();
        return r.isEmpty() ? "Other" : r;
    }
    private void handleDownload(WebView v, DlBridge br, String key, String url, String ua, String cd, String mime) {
        if (url == null) return;
        final String sub = orbitSubPath(v, key);
        final Uri tree = customTreeFor(v, key);
        final String proj = tree == null ? "" : projectFor(v, key);
        if (url.startsWith("blob:")) {
            br.blobUrl = url; br.cd = cd == null ? "" : cd; br.sub = sub; br.tree = tree; br.proj = proj;
            String js = "(function(u){fetch(u).then(function(r){return r.blob();}).then(function(b){var rd=new FileReader();rd.onloadend=function(){var s=String(rd.result);var d=s.substring(s.indexOf(',')+1);var N=262144;var n=Math.max(1,Math.ceil(d.length/N));for(var k=0;k<n;k++){OrbitDl.chunk(k,n,d.substring(k*N,(k+1)*N));}OrbitDl.done(b.type||'');};rd.readAsDataURL(b);}).catch(function(e){OrbitDl.fail(String(e));});})(" + JSONObject.quote(url) + ")";
            v.evaluateJavascript(js, null);
            Toast.makeText(this, "Saving file…", Toast.LENGTH_SHORT).show();
            return;
        }
        if (url.startsWith("data:")) {
            try {
                int comma = url.indexOf(','); String head = url.substring(5, comma); String body = url.substring(comma + 1);
                byte[] bytes = head.contains(";base64") ? android.util.Base64.decode(body, android.util.Base64.DEFAULT) : Uri.decode(body).getBytes("UTF-8");
                String mt = head.contains(";") ? head.substring(0, head.indexOf(';')) : head; if (mt.isEmpty()) mt = "application/octet-stream";
                java.io.File f = new java.io.File(getCacheDir(), "orbit_dl.tmp");
                try (java.io.FileOutputStream fo = new java.io.FileOutputStream(f)) { fo.write(bytes); }
                saveToDownloads(f, URLUtil.guessFileName(url, cd, mt), mt, sub, tree, proj);
            } catch (Exception e) { toastUi("Download failed"); }
            return;
        }
        if (!url.startsWith("http://") && !url.startsWith("https://")) return;
        if (tree != null) { downloadToCustom(url, ua, cookieFor(key, url), URLUtil.guessFileName(url, cd, mime), mime, sub, tree, proj); return; }
        try {
            String name = URLUtil.guessFileName(url, cd, mime);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            String ck = cookieFor(key, url);
            if (ck != null && !ck.isEmpty()) r.addRequestHeader("Cookie", ck);
            if (ua != null && !ua.isEmpty()) r.addRequestHeader("User-Agent", ua);
            if (mime != null && !mime.isEmpty()) r.setMimeType(mime);
            r.setTitle(name).setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            if (Build.VERSION.SDK_INT >= 29) r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, sub + "/" + name);
            else r.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, sub + "/" + name);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null) { Toast.makeText(this, "Downloads are not available", Toast.LENGTH_SHORT).show(); return; }
            dm.enqueue(r);
            Toast.makeText(this, "Downloading " + name + (Build.VERSION.SDK_INT >= 29 ? " → Downloads/" + sub : ""), Toast.LENGTH_SHORT).show();
        } catch (Exception e) { Toast.makeText(this, "Could not download: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    /** Copies a finished temp file into the public Downloads folder (Android 10+) or the app's Downloads folder (older). */
    private void saveToDownloads(java.io.File f, String name, String mime, String sub, Uri tree, String proj) {
        if (tree != null) {
            try { saveToTree(f, name, tree, proj); toastUi("Saved: " + name + " (" + treeLabel(tree) + (proj == null || proj.isEmpty() ? "" : "/" + proj) + ")"); return; }
            catch (Exception e) { toastUi("Custom folder failed (" + e.getMessage() + "). Saving to Downloads/" + sub); }
        }
        try {
            java.io.OutputStream out; String where;
            if (Build.VERSION.SDK_INT >= 29) {
                android.content.ContentValues cv = new android.content.ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name); cv.put(MediaStore.MediaColumns.MIME_TYPE, mime); cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + sub);
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (u == null) throw new java.io.IOException("cannot create file");
                out = getContentResolver().openOutputStream(u); where = "Downloads/" + sub;
            } else {
                java.io.File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS); if (dir == null) dir = getFilesDir();
                dir = new java.io.File(dir, sub); dir.mkdirs(); out = new java.io.FileOutputStream(new java.io.File(dir, name)); where = dir.getAbsolutePath();
            }
            try (java.io.InputStream in = new java.io.FileInputStream(f); java.io.OutputStream o = out) {
                byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            }
            f.delete();
            toastUi("Saved: " + name + " (" + where + ")");
        } catch (Exception e) { toastUi("Could not save the file: " + e.getMessage()); }
    }
    private void destroyView(WebView v) {
        try { webHost.removeView(v); v.stopLoading(); v.loadUrl("about:blank"); v.destroy(); } catch (Exception ignored) { }
    }
    /** Keep only the most recently used pages alive (Alias Manager > Settings > Orbit speed). */
    private void trimViews() {
        java.util.Iterator<Map.Entry<String, WebView>> it = views.entrySet().iterator();
        while (views.size() > keepLive && it.hasNext()) {
            Map.Entry<String, WebView> e = it.next();
            if (e.getValue() == webView) continue;
            destroyView(e.getValue()); it.remove();
        }
    }
    private void buildUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(12,15,24));
        // Keep the toolbar clear of the status bar / navigation bar / keyboard (Android 15 draws edge-to-edge).
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l, t, r, b;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                l = i.left; t = i.top; r = i.right; b = i.bottom;
            } else {
                l = insets.getSystemWindowInsetLeft(); t = insets.getSystemWindowInsetTop(); r = insets.getSystemWindowInsetRight(); b = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(l, t, r, b);
            return insets;
        });
        // Row 1: account tabs (scroll) + small icon buttons.   🔗 alias   ✉ Gmail   ＋ account   ⋯ manage   ✕ close
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setBackgroundColor(Color.rgb(19,23,36));
        tabScroll = new HorizontalScrollView(this); tabScroll.setHorizontalScrollBarEnabled(false);
        tabs = new LinearLayout(this); tabs.setGravity(Gravity.CENTER_VERTICAL); tabs.setPadding(dp(4),dp(4),dp(4),dp(4)); tabScroll.addView(tabs);
        top.addView(tabScroll, new LinearLayout.LayoutParams(0,dp(40),1));
        mailBtn = iconButton("✉", this::toggleMail);
        TextView[] icons = { iconButton("🔗", this::linkAlias), mailBtn, iconButton("＋", this::addProfile), iconButton("⋯", this::manageProfile), iconButton("✕", this::finish) };
        for (TextView ic : icons) { LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(36),dp(40)); lp.setMargins(dp(1),0,0,0); top.addView(ic, lp); }
        root.addView(top);
        svcScroll = new HorizontalScrollView(this); svcScroll.setHorizontalScrollBarEnabled(false); svcScroll.setBackgroundColor(Color.rgb(16,20,31));
        svcRow = new LinearLayout(this); svcRow.setGravity(Gravity.CENTER_VERTICAL); svcRow.setPadding(dp(4),dp(3),dp(4),dp(3)); svcScroll.addView(svcRow);
        root.addView(svcScroll, new LinearLayout.LayoutParams(-1, dp(36)));
        // Row 2: back / address / go / reload (can be hidden from ⋯)
        addressRow = new LinearLayout(this); addressRow.setGravity(Gravity.CENTER_VERTICAL); addressRow.setPadding(dp(6),dp(3),dp(6),dp(3)); addressRow.setBackgroundColor(Color.rgb(16,20,31));
        address = new EditText(this); address.setSingleLine(true); address.setTextSize(13); address.setTextColor(Color.WHITE); address.setHintTextColor(Color.LTGRAY); address.setHint("https://claude.ai/"); address.setText("https://claude.ai/"); address.setMinHeight(0); address.setMinimumHeight(0); address.setPadding(dp(10),0,dp(10),0); address.setBackground(rounded(Color.rgb(25,29,43), 10)); address.setImeOptions(EditorInfo.IME_ACTION_GO);
        address.setOnEditorActionListener((v,id,event)-> { if (id == EditorInfo.IME_ACTION_GO) { navigate(address.getText().toString()); return true; } return false; });
        addressRow.addView(button("◀",this::goBack),new LinearLayout.LayoutParams(dp(38),dp(34))); LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(0,dp(34),1); alp.setMargins(dp(3),0,dp(3),0); addressRow.addView(address,alp); addressRow.addView(button("Go",()->navigate(address.getText().toString())),new LinearLayout.LayoutParams(dp(44),dp(34))); LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(dp(38),dp(34)); rlp.setMargins(dp(3),0,0,0); addressRow.addView(button("↻",()->{ WebView c=cur(); if(c!=null)c.reload(); }),rlp); root.addView(addressRow);
        // Row 3: one small status line
        status = label(who(),10.5f); status.setSingleLine(true); status.setEllipsize(android.text.TextUtils.TruncateAt.END); status.setPadding(dp(10),dp(2),dp(10),dp(3)); status.setTextColor(Color.rgb(155,165,188)); status.setBackgroundColor(Color.rgb(16,20,31)); root.addView(status);
        webHost = new FrameLayout(this); webHost.setBackgroundColor(Color.rgb(24,24,24)); root.addView(webHost,new LinearLayout.LayoutParams(-1,0,1));
        progressBar = new View(this); progressBar.setBackgroundColor(Color.rgb(124,156,255)); progressBar.setVisibility(View.GONE);
        FrameLayout.LayoutParams ppl = new FrameLayout.LayoutParams(0, dp(2)); ppl.gravity = Gravity.TOP; webHost.addView(progressBar, ppl); setContentView(root); renderTabs(); applyCompact(); root.requestApplyInsets();
    }
    private void applyCompact() {
        int vis = compact ? View.GONE : View.VISIBLE;
        if (addressRow != null) addressRow.setVisibility(vis);
        if (svcScroll != null) svcScroll.setVisibility(vis);
        if (status != null) status.setVisibility(vis);
    }
    private WebView cur() { return mailMode && mailView != null ? mailView : webView; }
    private String tabsSig = "";
    private String tabsSignature() {
        StringBuilder sb = new StringBuilder(activeProfile);
        for (String n : profileNames) sb.append('|').append(n).append('=').append(tabLabel(n)).append(colorOf(n)).append(emojiOf(n));
        return sb.toString();
    }
    private void renderTabs() {
        tabsSig = tabsSignature();
        tabs.removeAllViews();
        TextView activeTab = null;
        for (String name : profileNames) { final String selectedName=name; boolean on=name.equals(activeProfile); String em=emojiOf(name);
            TextView b=button("",()->switchProfile(selectedName)); b.setTextSize(12);
            SpannableString sp=new SpannableString("●  "+(em.isEmpty()?"":em+" ")+tabLabel(name)); sp.setSpan(new ForegroundColorSpan(on?Color.WHITE:colorOf(name)),0,1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); b.setText(sp);
            b.setBackground(rounded(on?colorOf(name):Color.rgb(31,36,52), 16)); b.setOnLongClickListener(v -> { if (!selectedName.equals(activeProfile)) switchProfile(selectedName); manageProfile(); return true; }); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(32)); lp.setMargins(dp(2),0,dp(2),0); tabs.addView(b,lp); if(on) activeTab=b; }
        final TextView at = activeTab;
        if (at != null && tabScroll != null) tabScroll.post(() -> tabScroll.smoothScrollTo(Math.max(0, at.getLeft() - dp(8)), 0));
    }
    // ---- Gmail: see verification emails inside the app. claude.ai links tapped there open in the ACTIVE Claude profile. ----
    private void toggleMail() {
        if (mailMode) { exitMail(); return; }
        if (!profileSupported) { showMessage("Gmail view needs an updated Android System WebView (isolated profiles)."); return; }
        try {
            if (mailView == null) createMailView();
            mailMode = true;
            if (webView != null) webView.setVisibility(View.GONE);
            mailView.setVisibility(View.VISIBLE);
            mailBtn.setBackground(rounded(PURPLE, 10));
            String u = mailView.getUrl(); address.setText(u == null ? MAIL_URL : u);
            refreshStatus();
        } catch (Exception e) { mailMode = false; showMessage("Could not open Gmail: " + e.getMessage()); }
    }
    private void exitMail() {
        mailMode = false;
        if (mailView != null) mailView.setVisibility(View.GONE);
        if (webView != null) { webView.setVisibility(View.VISIBLE); String u = webView.getUrl(); if (u != null) address.setText(u); }
        if (mailBtn != null) mailBtn.setBackground(rounded(Color.rgb(39,45,64), 10));
        refreshStatus();
    }
    private void createMailView() {
        WebView view = new WebView(this);
        WebViewCompat.setProfile(view, MAIL_KEY);
        view.getSettings().setJavaScriptEnabled(true); view.getSettings().setDomStorageEnabled(true);
        view.getSettings().setJavaScriptCanOpenWindowsAutomatically(false); view.getSettings().setSupportMultipleWindows(false);
        try { android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(view, true); } catch (Exception ignored) { }
        view.setWebChromeClient(newChromeClient());
        final DlBridge mailBr = new DlBridge(); view.addJavascriptInterface(mailBr, "OrbitDl");
        view.setDownloadListener((u, ua, cd, mime, len) -> handleDownload(view, mailBr, MAIL_KEY, u, ua, cd, mime));
        view.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                Uri u = req.getUrl(); String scheme = u.getScheme();
                if (!"http".equals(scheme) && !"https".equals(scheme)) return true;
                if (!req.isForMainFrame()) return false;
                Uri target = unwrapRedirect(u);
                String host = target.getHost();
                if (host != null && (host.equals("claude.ai") || host.endsWith(".claude.ai"))) { openInClaude(target.toString()); return true; }
                return false;
            }
            @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) { super.onPageStarted(v, url, icon); mailBr.allowed = trustedHost(url); if (mailMode && url != null) address.setText(url); }
        });
        webHost.addView(view, new FrameLayout.LayoutParams(-1,-1));
        mailView = view;
        view.loadUrl(MAIL_URL);
    }
    /** Gmail wraps links as google.com/url?q=<real link>. Return the real link. */
    private Uri unwrapRedirect(Uri u) {
        try {
            String h = u.getHost();
            if (h != null && h.endsWith("google.com") && "/url".equals(u.getPath())) {
                String q = u.getQueryParameter("q"); if (q == null) q = u.getQueryParameter("url");
                if (q != null && q.startsWith("http")) return Uri.parse(q);
            }
        } catch (Exception ignored) { }
        return u;
    }
    private void openInClaude(String url) {
        exitMail();
        if (webView == null) return;
        String e = linkedEmail(activeProfile);
        address.setText(url); webView.loadUrl(url);
        Toast.makeText(this, "Opening in " + activeProfile + (e != null ? " → " + e : ""), Toast.LENGTH_SHORT).show();
    }
    private static final Pattern LOGINISH = Pattern.compile("(?i)(log-?in|sign-?in|sign-?up|/auth|auth\\.|accounts\\.|login\\.|identifier|oauth)");
    /** On an AI's login page, put this profile's linked alias in the email box (you still tap Continue yourself). Claude: also offers the alias picker. */
    private void maybeFillEmail(final WebView v, String url, String forProfile) {
        if (url == null || forProfile == null) return;
        boolean claudeLogin = LOGIN_URL.matcher(url).find();
        if (!claudeLogin) {
            String pid = providerIdForUrl(url);
            if (pid == null || pid.equals("claude")) return;
            String[] pr = providerById(pid);
            if (pr == null || !"1".equals(pr[9]) || !LOGINISH.matcher(url).find()) return;
        }
        String email = linkedEmail(forProfile);
        if (email == null) {
            if (claudeLogin && !aliases.isEmpty() && !isFinishing() && loginHinted.add(forProfile) && forProfile.equals(activeProfile)) linkAlias(); // pick the alias to sign in with
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastFillAt < 1500) return;
        lastFillAt = now;
        final String js = "(function(){try{var e=" + JSONObject.quote(email) + ";var i=document.querySelector('input[type=\"email\"],input[name=\"email\"],input[autocomplete=\"email\"],input[name=\"loginfmt\"],input[name=\"identifier\"],input[autocomplete=\"username\"]');if(!i||i.value||i.type==='password')return 0;var d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');d.set.call(i,e);i.dispatchEvent(new Event('input',{bubbles:true}));i.dispatchEvent(new Event('change',{bubbles:true}));return 1;}catch(x){return 0;}})()";
        int[] delays = {300, 1200, 2500};
        for (int dly : delays) ticker.postDelayed(() -> { if (v == webView) v.evaluateJavascript(js, null); }, dly);
    }
    private void addProfile() { if(mailMode)exitMail(); int i=1; while(profileNames.contains("Account "+i)) i++; String name="Account "+i; profileNames.add(name); activeProfile=name; try{ keys.put(name,"orbit_"+java.util.UUID.randomUUID().toString().replace("-","").substring(0,10)); }catch(Exception ignored){} saveMeta(); saveProfiles(); renderTabs(); if(profileSupported)showProfile(name); }
    private void switchProfile(String name) { if(mailMode)exitMail(); if(name.equals(activeProfile))return; activeProfile=name; saveProfiles(); renderTabs(); if(profileSupported)showProfile(name); }
    static String profileKey(String name) { return "orbit_"+name.toLowerCase().replaceAll("[^a-z0-9]+","_").replaceAll("^_+|_+$",""); }
    private WebView newProfileView(final String key) {
        WebView view = new WebView(this);
        WebViewCompat.setProfile(view, key);
        android.webkit.WebSettings ws = view.getSettings();
        ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setLoadsImagesAutomatically(true);
        ws.setJavaScriptCanOpenWindowsAutomatically(false); ws.setSupportMultipleWindows(false);
        ws.setAllowFileAccess(false); ws.setAllowContentAccess(true); ws.setSaveFormData(false);
        view.setOverScrollMode(View.OVER_SCROLL_NEVER);
        view.setBackgroundColor(Color.rgb(24, 24, 24));
        view.setWebChromeClient(newChromeClient());
        final DlBridge br = new DlBridge(); view.addJavascriptInterface(br, "OrbitDl");
        final WebView fview = view;
        view.setDownloadListener((u, ua, cd, mime, len) -> handleDownload(fview, br, key, u, ua, cd, mime));
        view.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) { String scheme = req.getUrl().getScheme(); return !("http".equals(scheme) || "https".equals(scheme)); }
            @Override public void doUpdateVisitedHistory(WebView v, String url, boolean isReload) {
                super.doUpdateVisitedHistory(v, url, isReload);
                br.allowed = trustedHost(url);
                String who = nameOfKey(key);
                if (who != null) { onUrlChanged(who, url); maybeFillEmail(v, url, who); checkGoogleBlock(url, who); }
                if (v == webView) { renderServiceChips(); }
            }
            @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) {
                super.onPageStarted(v, url, icon);
                if (v == webView) { if (url != null && !mailMode) address.setText(url); statusSuffix = "Loading…"; refreshStatus(); }
            }
            @Override public void onPageFinished(WebView v, String url) {
                super.onPageFinished(v, url);
                String who = nameOfKey(key);
                if (v == webView) { statusSuffix = "Session isolated"; refreshStatus(); }
                maybeFillEmail(v, url, who);
                scheduleServiceScan(who);
            }
        });
        return view;
    }
    private void showProfile(String name) {
        try {
            if (mailMode) exitMail();
            final String key = keyOf(name);
            if (webView != null) { webView.setVisibility(View.GONE); webView.onPause(); }
            WebView cached = views.get(key);
            if (cached != null) { // already loaded: show it again at once, no reload
                views.remove(key); views.put(key, cached);
                webView = cached; cached.setVisibility(View.VISIBLE); cached.onResume();
                if (startUrl != null) { cached.loadUrl(startUrl); address.setText(startUrl); startUrl = null; }
                else { String u = cached.getUrl(); if (u != null) address.setText(u); }
                renderTabs(); refreshStatus(); scheduleServiceScan(name);
                return;
            }
            lastUrls.remove(key);
            WebView view = newProfileView(key);
            webView = view; views.put(key, view);
            webHost.addView(view, 0, new FrameLayout.LayoutParams(-1, -1));
            String url = startUrl != null ? startUrl : "https://claude.ai/"; startUrl = null;
            address.setText(url); view.loadUrl(url);
            trimViews();
            renderTabs(); refreshStatus();
        } catch (Exception e) { statusSuffix = "Unable to create isolated profile"; refreshStatus(); showMessage("Could not open profile. Update Android System WebView and try again.\n\n" + e.getMessage()); }
    }
    private void navigate(String raw) {
        String url=raw.trim(); if(url.isEmpty())return; if(!url.contains("://"))url="https://"+url; Uri uri=Uri.parse(url);
        if(!"https".equals(uri.getScheme())&& !"http".equals(uri.getScheme())){showMessage("Only HTTP and HTTPS pages are supported.");return;}
        address.setText(url); InputMethodManager imm=(InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE); if(imm!=null)imm.hideSoftInputFromWindow(address.getWindowToken(),0); WebView c=cur(); if(mailMode){ String h=uri.getHost(); if(h!=null&&(h.equals("claude.ai")||h.endsWith(".claude.ai"))){ openInClaude(url); return; } } if(c!=null)c.loadUrl(url);
    }
    private void showUnsupported() {
        webHost.removeAllViews(); TextView msg=new TextView(this); msg.setText("Isolated browser profiles are not supported by the installed Android System WebView.\n\nUpdate Android System WebView from Google Play, then reopen Orbit Browser. No shared-session fallback is used, so accounts won't accidentally share cookies."); msg.setTextSize(17); msg.setTextColor(Color.DKGRAY); msg.setGravity(Gravity.CENTER); msg.setPadding(dp(24),dp(24),dp(24),dp(24)); msg.setBackgroundColor(Color.WHITE); webHost.addView(msg,new FrameLayout.LayoutParams(-1,-1)); statusSuffix="Multi-profile feature unavailable"; refreshStatus();
    }
    private void showMessage(String message){ if(!isFinishing())new AlertDialog.Builder(this).setTitle("Orbit Browser").setMessage(message).setPositiveButton("OK",null).show(); }
    @Override public void onDestroy(){ ticker.removeCallbacks(tick); ticker.removeCallbacks(limitTick); if(mailView!=null){mailView.stopLoading();mailView.loadUrl("about:blank");mailView.destroy();mailView=null;} for (WebView lv : new ArrayList<>(views.values())) { try { lv.stopLoading(); lv.loadUrl("about:blank"); lv.destroy(); } catch (Exception ignored) { } } views.clear(); webView=null; if (fileCb != null) { fileCb.onReceiveValue(null); fileCb = null; } super.onDestroy(); }
}
