package __PACKAGE__;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import org.json.JSONObject;

/**
 * Scheduled message (PROTOTYPE). One schedule per Orbit account (profile), kept as JSON in prefs "orbit_profiles" / key "sched":
 *   { "<profile>": { on, mode: "time"|"reset", hour, minute, at, text, incognito, repeat, lastRun, lastResult } }
 * An alarm wakes this receiver. It tries to open Orbit in "send now" mode (Android only allows that from the background when
 * e.g. "Display over other apps" is on) and always shows a notification that opens the same screen when tapped.
 * Orbit itself then types the text into the AI's page and presses send (OrbitBrowserActivity.autoSend*).
 */
public class OrbitScheduleReceiver extends BroadcastReceiver {
    static final String CHANNEL = "orbit_scheduled";
    private static final String PREFS = "orbit_profiles";
    private static final String KEY = "sched";

    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) { rearmAll(ctx); return; }
        String profile = intent.getStringExtra("profile");
        if (profile == null) return;
        JSONObject s = get(ctx, profile);
        if (s == null || !s.optBoolean("on", false)) return;
        try {
            if ("time".equals(s.optString("mode", "time")) && "daily".equals(s.optString("repeat", "once"))) {
                s.put("at", nextTimeOfDay(s.optInt("hour", 9), s.optInt("minute", 0), System.currentTimeMillis() + 60000L));
                put(ctx, profile, s); arm(ctx, profile); // tomorrow, already
            } else if ("time".equals(s.optString("mode", "time"))) {
                s.put("on", false); put(ctx, profile, s); // once: done after this run
            }
        } catch (Exception ignored) { }
        Intent go = launchIntent(ctx, profile, true);
        notifyUser(ctx, profile, "Scheduled message", "Tap to send it now if Orbit did not open by itself.", PendingIntent.getActivity(ctx, id(profile), launchIntent(ctx, profile, true), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        try { ctx.startActivity(go); } catch (Throwable ignored) { /* blocked by Android: the notification above is the way in */ }
    }

    // ---- storage ----
    static JSONObject all(Context ctx) {
        try { return new JSONObject(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }
    static JSONObject get(Context ctx, String profile) { return all(ctx).optJSONObject(profile); }
    static void put(Context ctx, String profile, JSONObject s) {
        synchronized (OrbitBrowserActivity.LOCK) {
            try { JSONObject a = all(ctx); a.put(profile, s); ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).commit(); }
            catch (Exception ignored) { }
        }
    }
    static void remove(Context ctx, String profile) {
        synchronized (OrbitBrowserActivity.LOCK) {
            JSONObject a = all(ctx); a.remove(profile);
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).commit();
        }
    }
    static JSONObject blank() {
        try { return new JSONObject().put("on", false).put("mode", "time").put("hour", 9).put("minute", 0).put("at", 0).put("text", "").put("incognito", false).put("repeat", "once").put("lastRun", 0).put("lastResult", ""); }
        catch (Exception e) { return new JSONObject(); }
    }

    // ---- time ----
    /** The next time of day hh:mm that is not before minMs. */
    static long nextTimeOfDay(int hour, int minute, long minMs) {
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.setTimeInMillis(minMs);
        c.set(java.util.Calendar.HOUR_OF_DAY, hour); c.set(java.util.Calendar.MINUTE, minute); c.set(java.util.Calendar.SECOND, 0); c.set(java.util.Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() < minMs) c.add(java.util.Calendar.DAY_OF_YEAR, 1);
        return c.getTimeInMillis();
    }

    // ---- alarm ----
    private static int id(String profile) { return ("sched:" + profile).hashCode(); }
    private static PendingIntent alarmIntent(Context ctx, String profile, int flags) {
        Intent i = new Intent(ctx, OrbitScheduleReceiver.class);
        i.setData(Uri.parse("orbit://sched/" + Uri.encode(profile))); // one PendingIntent per account
        i.putExtra("profile", profile);
        return PendingIntent.getBroadcast(ctx, id(profile), i, flags | PendingIntent.FLAG_IMMUTABLE);
    }
    static boolean canExact(Context ctx) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        return am != null && am.canScheduleExactAlarms();
    }
    /** Sets the alarm for s.at (milliseconds). Exact when Android allows it, otherwise it may fire a few minutes late. */
    static void arm(Context ctx, String profile) {
        JSONObject s = get(ctx, profile);
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (s == null || am == null || !s.optBoolean("on", false)) return;
        long at = s.optLong("at", 0);
        if (at <= System.currentTimeMillis()) return;
        PendingIntent pi = alarmIntent(ctx, profile, PendingIntent.FLAG_UPDATE_CURRENT);
        try {
            if (canExact(ctx)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (SecurityException e) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); }
    }
    static void disarm(Context ctx, String profile) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(alarmIntent(ctx, profile, PendingIntent.FLAG_UPDATE_CURRENT));
    }
    /** After a reboot: put every switched-on schedule back. A time that passed while the phone was off is not sent late. */
    static void rearmAll(Context ctx) {
        JSONObject a = all(ctx);
        java.util.Iterator<String> it = a.keys();
        long now = System.currentTimeMillis();
        while (it.hasNext()) {
            String p = it.next();
            JSONObject s = a.optJSONObject(p);
            if (s == null || !s.optBoolean("on", false)) continue;
            try {
                if (s.optLong("at", 0) <= now) {
                    if ("time".equals(s.optString("mode", "time")) && "daily".equals(s.optString("repeat", "once"))) { s.put("at", nextTimeOfDay(s.optInt("hour", 9), s.optInt("minute", 0), now + 60000L)); put(ctx, p, s); }
                    else { s.put("on", false).put("lastResult", "Missed: the phone was off."); put(ctx, p, s); continue; }
                }
            } catch (Exception ignored) { }
            arm(ctx, p);
        }
    }

    // ---- opening Orbit + notifications ----
    static Intent launchIntent(Context ctx, String profile, boolean unattended) {
        Intent i = new Intent(ctx, OrbitBrowserActivity.class);
        i.putExtra("autoSendProfile", profile);
        i.putExtra("unattended", unattended);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return i;
    }
    static void cancelNotice(Context ctx, String profile) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(id(profile));
    }
    static void notifyUser(Context ctx, String profile, String title, String text, PendingIntent open) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Scheduled messages", NotificationManager.IMPORTANCE_HIGH));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, CHANNEL) : new Notification.Builder(ctx);
        int small = ctx.getResources().getIdentifier("orbit_ic_notif", "drawable", ctx.getPackageName());
        b.setSmallIcon(small != 0 ? small : android.R.drawable.ic_lock_idle_alarm).setColor(0xFF524FFF)
                .setContentTitle(title).setContentText(text).setAutoCancel(true);
        if (open != null) b.setContentIntent(open);
        nm.notify(id(profile), b.build());
    }

    /** Called by Orbit when a run ended. Saves the result, arms the next run (reset mode: nextAt = end of the new timer), tells the person. */
    static void finished(Context ctx, String profile, boolean ok, String message, long nextResetAt) {
        JSONObject s = get(ctx, profile);
        if (s == null) return;
        try {
            s.put("lastRun", System.currentTimeMillis()).put("lastResult", ok ? "Sent" : message);
            if (ok && "reset".equals(s.optString("mode", "time")) && "reset".equals(s.optString("repeat", "once"))) {
                if (nextResetAt > System.currentTimeMillis()) { s.put("at", nextResetAt).put("on", true); }
                else { s.put("on", false).put("lastResult", "Sent. No new timer was found, so the schedule turned off."); }
            } else if ("reset".equals(s.optString("mode", "time"))) {
                s.put("on", false);
            }
            put(ctx, profile, s);
            if (s.optBoolean("on", false)) arm(ctx, profile);
        } catch (Exception ignored) { }
        notifyUser(ctx, profile, ok ? "Scheduled message sent" : "Scheduled message did not send", ok ? "Your message was sent." : message, null);
    }
}
