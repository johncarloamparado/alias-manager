package __PACKAGE__;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Scheduled message (PROTOTYPE). One schedule per Orbit account (profile), kept as JSON in prefs "orbit_profiles" / key "sched":
 *   { "<profile>": { on, mode: "time"|"reset", hour, minute, at, text, incognito, repeat, lastRun, lastResult } }
 * An alarm wakes this receiver. By default it starts OrbitSendService, which sends the message in a HIDDEN browser (no screen, works
 * with the phone locked, nothing opens over a game). If Android refuses that, it falls back to opening Orbit in "send now" mode plus a
 * notification that does the same when tapped (OrbitBrowserActivity.startAutoFromIntent).
 */
public class OrbitScheduleReceiver extends BroadcastReceiver {
    static final String CHANNEL = "orbit_scheduled";
    static final String ACTION_RETRY = "orbit.sched.retry";
    static final String CHANNEL_DONE = "orbit_scheduled_done"; // quiet: "sent" notes never pop up or make a sound
    private static final String PREFS = "orbit_profiles";
    private static final String KEY = "sched";

    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) { rearmAll(ctx); return; }
        String profile = intent.getStringExtra("profile");
        if (profile == null) return;
        if (ACTION_RETRY.equals(intent.getAction())) { // the run was waiting for free memory: try again (the schedule itself already ran its turn)
            JSONObject rs = get(ctx, profile);
            if (rs == null || rs.optString("text", "").trim().isEmpty()) return;
            try { OrbitSendService.start(ctx, profile, false, intent.getIntExtra("n", 1)); }
            catch (Throwable t) { openVisibly(ctx, profile, "Android did not let Orbit retry in the background."); }
            return;
        }
        JSONObject s = get(ctx, profile);
        if (s == null || !OrbitScheduleMath.shouldRun(s.optBoolean("on", false), intent.getLongExtra("at", 0), s.optLong("at", 0), System.currentTimeMillis())) return; // switched off, or a stale alarm
        try {
            if ("time".equals(s.optString("mode", "time")) && "daily".equals(s.optString("repeat", "once"))) {
                s.put("at", nextTimeOfDay(s.optInt("hour", 9), s.optInt("minute", 0), System.currentTimeMillis() + 60000L));
                put(ctx, profile, s); arm(ctx, profile); // tomorrow, already
            } else if ("time".equals(s.optString("mode", "time"))) {
                s.put("on", false); put(ctx, profile, s); // once: done after this run
            }
        } catch (Exception ignored) { }
        if (s.optBoolean("background", true)) {
            try { OrbitSendService.start(ctx, profile, false); return; } catch (Throwable ignored) { /* Android refused: open Orbit instead */ }
        }
        openVisibly(ctx, profile, "Tap to send it now if Orbit did not open by itself.");
    }

    /** Fallback: open Orbit in "send now" mode (needs "Display over other apps" or Orbit on screen) and leave a notification that does the same when tapped. */
    static void openVisibly(Context ctx, String profile, String why) {
        notifyUser(ctx, profile, "Scheduled message", why, PendingIntent.getActivity(ctx, id(profile), launchIntent(ctx, profile, true), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        try { ctx.startActivity(launchIntent(ctx, profile, true)); } catch (Throwable ignored) { /* blocked by Android: the notification is the way in */ }
    }

    /** WebView profile key of an account (same rule as the Orbit Browser). */
    static String profileKeyFor(Context ctx, String name) {
        try {
            String k = new JSONObject(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("keys", "{}")).optString(name, "");
            if (!k.isEmpty()) return k;
        } catch (Exception ignored) { }
        return OrbitBrowserActivity.profileKey(name);
    }

    /** Claude's timer length in ms, from Alias Manager > Settings > Timer length per AI (5 hours when nothing was set). */
    static long claudeWindowMs(Context ctx) {
        try {
            JSONArray a = new JSONArray(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("providers_json", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null && "claude".equals(o.optString("id"))) { double hrs = o.optDouble("hours", 5); if (hrs > 0) return (long) (hrs * 3600000L); }
            }
        } catch (Exception ignored) { }
        return 5L * 60 * 60 * 1000;
    }

    /** A message was sent without the browser screen: count it like a chat seen there (event for the Alias Manager + the Ready alarm
     *  when it is the first chat of a new window). Returns when the timer ends, or 0 if the account is not linked to an alias. */
    static long recordChat(Context ctx, String profile, boolean incognito) {
        try {
            android.content.SharedPreferences pr = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String aliasId = new JSONObject(pr.getString("links", "{}")).optString(profile, "");
            if (aliasId.isEmpty()) return 0;
            String email = null; long lastUsed = 0;
            JSONArray arr = new JSONArray(pr.getString("aliases_json", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String em = o.optString("email", "").trim(), id = o.optString("id", "").trim();
                if (id.isEmpty()) id = em;
                if (id.equals(aliasId)) { email = em; lastUsed = o.optLong("lastUsed", 0); }
            }
            if (email == null || email.isEmpty()) return 0;
            long now = System.currentTimeMillis(), win = claudeWindowMs(ctx);
            synchronized (OrbitBrowserActivity.LOCK) {
                JSONArray q = new JSONArray(pr.getString("events", "[]"));
                q.put(new JSONObject().put("aliasId", aliasId).put("profile", profile).put("chatId", (incognito ? "incognito-" : "sched-") + now).put("ts", now));
                pr.edit().putString("events", q.toString()).commit();
            }
            if (lastUsed <= 0 || now - lastUsed >= win) { OrbitReminderReceiver.add(ctx, aliasId, email, now + win); return now + win; }
            return lastUsed + win;
        } catch (Exception e) { return 0; }
    }

    // ---- storage ----
    static JSONObject all(Context ctx) {
        try { return new JSONObject(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }
    static JSONObject get(Context ctx, String profile) { return all(ctx).optJSONObject(profile); }
    static void put(Context ctx, String profile, JSONObject s) {
        synchronized (OrbitBrowserActivity.LOCK) {
            try { JSONObject a = all(ctx); a.put(profile, s); ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).commit(); }
            catch (Exception ignored) { }
        }
    }
    static void remove(Context ctx, String profile) {
        synchronized (OrbitBrowserActivity.LOCK) {
            JSONObject a = all(ctx); a.remove(profile);
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).commit();
        }
    }
    static JSONObject blank() {
        try { return new JSONObject().put("on", false).put("mode", "time").put("hour", 9).put("minute", 0).put("at", 0).put("text", "").put("incognito", false).put("background", true).put("ramwait", true).put("notifyok", true).put("repeat", "once").put("lastRun", 0).put("lastResult", ""); }
        catch (Exception e) { return new JSONObject(); }
    }

    // ---- time ----
    static long nextTimeOfDay(int hour, int minute, long minMs) { return OrbitScheduleMath.nextTimeOfDay(hour, minute, minMs); }

    // ---- alarm ----
    private static int id(String profile) { return ("sched:" + profile).hashCode(); }
    private static PendingIntent alarmIntent(Context ctx, String profile, long at, int flags) {
        Intent i = new Intent(ctx, OrbitScheduleReceiver.class);
        i.setData(Uri.parse("orbit://sched/" + Uri.encode(profile))); // one PendingIntent per account
        i.putExtra("profile", profile).putExtra("at", at); // the time it was set for: an alarm for any other time is a stale one
        return PendingIntent.getBroadcast(ctx, id(profile), i, flags | PendingIntent.FLAG_IMMUTABLE);
    }
    static boolean canExact(Context ctx) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        return am != null && am.canScheduleExactAlarms();
    }
    /** Sets the alarm for s.at (milliseconds). Exact when Android allows it, otherwise it may fire a few minutes late. */
    static void arm(Context ctx, String profile) {
        JSONObject s = get(ctx, profile);
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (s == null || am == null || !s.optBoolean("on", false)) return;
        long at = s.optLong("at", 0);
        if (at <= System.currentTimeMillis()) return;
        PendingIntent pi = alarmIntent(ctx, profile, at, PendingIntent.FLAG_UPDATE_CURRENT);
        try {
            if (canExact(ctx)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (SecurityException e) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); }
    }
    static void disarm(Context ctx, String profile) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(alarmIntent(ctx, profile, 0, PendingIntent.FLAG_UPDATE_CURRENT));
    }

    // ---- low-memory retries: the phone sleeps between checks; one alarm per minute wakes Orbit only for a moment ----
    private static PendingIntent retryIntent(Context ctx, String profile, int n) {
        Intent i = new Intent(ctx, OrbitScheduleReceiver.class).setAction(ACTION_RETRY);
        i.setData(Uri.parse("orbit://sched-retry/" + Uri.encode(profile)));
        i.putExtra("profile", profile).putExtra("n", n);
        return PendingIntent.getBroadcast(ctx, id(profile) + 1, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    static void scheduleRetry(Context ctx, String profile, int n, long delayMs) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        long at = System.currentTimeMillis() + delayMs;
        PendingIntent pi = retryIntent(ctx, profile, n);
        try {
            if (canExact(ctx)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (SecurityException e) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); }
        setRetry(ctx, profile, n);
    }
    static void cancelRetry(Context ctx, String profile) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(retryIntent(ctx, profile, 0));
        setRetry(ctx, profile, 0);
    }
    /** Remembers "waiting for free memory, try n of 10" so the sheet can show it (0 = not waiting). */
    static void setRetry(Context ctx, String profile, int n) {
        JSONObject s = get(ctx, profile);
        if (s == null || s.optInt("retry", 0) == n) return;
        try { s.put("retry", n); put(ctx, profile, s); } catch (Exception ignored) { }
    }
    /** After a reboot: put every switched-on schedule back. A time that passed while the phone was off is not sent late. */
    static void rearmAll(Context ctx) {
        JSONObject a = all(ctx);
        java.util.Iterator<String> it = a.keys();
        long now = System.currentTimeMillis();
        while (it.hasNext()) {
            String p = it.next();
            JSONObject s = a.optJSONObject(p);
            if (s == null || !s.optBoolean("on", false)) continue;
            try {
                if (s.optLong("at", 0) <= now) {
                    if ("time".equals(s.optString("mode", "time")) && "daily".equals(s.optString("repeat", "once"))) { s.put("at", nextTimeOfDay(s.optInt("hour", 9), s.optInt("minute", 0), now + 60000L)); put(ctx, p, s); }
                    else { s.put("on", false).put("lastResult", "Missed: the phone was off."); put(ctx, p, s); continue; }
                }
            } catch (Exception ignored) { }
            arm(ctx, p);
        }
    }

    // ---- opening Orbit + notifications ----
    static Intent launchIntent(Context ctx, String profile, boolean unattended) {
        Intent i = new Intent(ctx, OrbitBrowserActivity.class);
        i.putExtra("autoSendProfile", profile);
        i.putExtra("unattended", unattended);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return i;
    }
    static void cancelNotice(Context ctx, String profile) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(id(profile));
    }
    static void notifyUser(Context ctx, String profile, String title, String text, PendingIntent open) { notifyUser(ctx, profile, title, text, open, false); }
    /** quiet = low importance: shows in the notification shade only, no popup, no sound. */
    static void notifyUser(Context ctx, String profile, String title, String text, PendingIntent open, boolean quiet) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        String ch = quiet ? CHANNEL_DONE : CHANNEL;
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(quiet ? new NotificationChannel(CHANNEL_DONE, "Scheduled messages: sent", NotificationManager.IMPORTANCE_LOW) : new NotificationChannel(CHANNEL, "Scheduled messages", NotificationManager.IMPORTANCE_HIGH));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, ch) : new Notification.Builder(ctx);
        int small = ctx.getResources().getIdentifier("orbit_ic_notif", "drawable", ctx.getPackageName());
        b.setSmallIcon(small != 0 ? small : android.R.drawable.ic_lock_idle_alarm).setColor(0xFF524FFF)
                .setContentTitle(title).setContentText(text).setAutoCancel(true);
        if (open != null) b.setContentIntent(open);
        nm.notify(id(profile), b.build());
    }

    /** Called by Orbit when a run ended. Saves the result, arms the next run (reset mode: nextAt = end of the new timer), tells the person. */
    static void finished(Context ctx, String profile, boolean ok, String message, long nextResetAt, boolean test) {
        JSONObject s = get(ctx, profile);
        if (s == null) return;
        try {
            s.put("retry", 0).put("lastRun", System.currentTimeMillis()).put("lastResult", (test ? "Test: " : "Scheduled: ") + (ok ? "Sent" : message));
            if (test) { /* a test never changes the schedule itself */ }
            else if (ok && "reset".equals(s.optString("mode", "time")) && "reset".equals(s.optString("repeat", "once"))) {
                if (nextResetAt > System.currentTimeMillis()) { s.put("at", nextResetAt).put("on", true); }
                else { s.put("on", false).put("lastResult", "Sent. No new timer was found, so the schedule turned off."); }
            } else if ("reset".equals(s.optString("mode", "time"))) {
                s.put("on", false);
            }
            put(ctx, profile, s);
            if (!test && s.optBoolean("on", false)) arm(ctx, profile);
        } catch (Exception ignored) { }
        if (ok) { if (s.optBoolean("notifyok", true)) notifyUser(ctx, profile, "Scheduled message sent", "Your message was sent.", null, true); } // the switch "Notify when sent"
        else notifyUser(ctx, profile, "Scheduled message did not send", message + " Tap to try again while you watch.",
                PendingIntent.getActivity(ctx, id(profile), launchIntent(ctx, profile, false), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
    }
}
