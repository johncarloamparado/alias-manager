package __PACKAGE__;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/**
 * Home-screen widget: which accounts are ready to use right now, and when the running ones finish.
 * The list ("widget_json") is written by Alias Manager every time something changes: [{l: label, s: AI name, at: readyAtMs}].
 * at <= now (or 1) means ready now. The widget also refreshes when a Ready alarm fires and every ~30 minutes.
 */
public class OrbitWidgetProvider extends AppWidgetProvider {
    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) mgr.updateAppWidget(id, build(ctx));
    }

    static void refresh(Context ctx) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(ctx);
            int[] ids = m.getAppWidgetIds(new ComponentName(ctx, OrbitWidgetProvider.class));
            if (ids == null || ids.length == 0) return;
            for (int id : ids) m.updateAppWidget(id, build(ctx));
        } catch (Exception ignored) { }
    }

    private static int rid(Context ctx, String name, String type) {
        return ctx.getResources().getIdentifier(name, type, ctx.getPackageName());
    }

    static RemoteViews build(Context ctx) {
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), rid(ctx, "orbit_widget", "layout"));
        List<Object[]> rows = new ArrayList<>(); // {label, ai, at}
        try {
            JSONArray a = new JSONArray(ctx.getSharedPreferences("orbit_profiles", Context.MODE_PRIVATE).getString("widget_json", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i); if (o == null) continue;
                rows.add(new Object[]{o.optString("l", "?"), o.optString("s", ""), Long.valueOf(o.optLong("at", 0))});
            }
        } catch (Exception ignored) { }
        final long now = System.currentTimeMillis();
        Collections.sort(rows, new Comparator<Object[]>() {
            @Override public int compare(Object[] x, Object[] y) {
                long ax = (Long) x[2], ay = (Long) y[2];
                boolean rx = ax <= now, ry = ay <= now;
                if (rx != ry) return rx ? -1 : 1;
                return Long.compare(ax, ay);
            }
        });
        StringBuilder sb = new StringBuilder();
        int shown = 0;
        java.text.DateFormat tf = android.text.format.DateFormat.getTimeFormat(ctx);
        for (Object[] r : rows) {
            if (shown >= 6) break;
            long at = (Long) r[2];
            if (sb.length() > 0) sb.append('\n');
            String ai = ((String) r[1]).isEmpty() ? "" : " · " + r[1];
            if (at <= now) sb.append("✓ ").append(r[0]).append(ai);
            else sb.append("⏱ ").append(r[0]).append(ai).append("  → ").append(tf.format(new Date(at)));
            shown++;
        }
        if (rows.size() > shown) sb.append("\n+").append(rows.size() - shown).append(" more");
        if (sb.length() == 0) sb.append("No accounts yet. Open Orbit.");
        rv.setTextViewText(rid(ctx, "w_text", "id"), sb.toString());
        Intent launch = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
        if (launch != null) {
            PendingIntent open = PendingIntent.getActivity(ctx, 0, launch, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            rv.setOnClickPendingIntent(rid(ctx, "w_root", "id"), open);
        }
        return rv;
    }
}
