package __PACKAGE__;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import org.json.JSONObject;

/**
 * Scheduled message, "no screen" mode (PROTOTYPE). Started by the alarm (OrbitScheduleReceiver) or by "Send a test in the background".
 * It opens the schedule's AI (a new chat, or the chosen chat) in a HIDDEN browser that uses the account's own isolated profile, types the text, presses Send, waits until the AI
 * shows the message, counts the chat (timer + Ready alarm) and stops. About 15-30 seconds, one foreground notification, a short wake lock.
 * Nothing runs between two schedules. It uses the same page script as the visible run (OrbitBrowserActivity.AUTO_JS).
 */
public class OrbitSendService extends Service {
    static final String CHANNEL = "orbit_sending";
    private static final int NOTE_ID = 7742;
    private static boolean running = false;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable step = new Runnable() { @Override public void run() { poll(); } };
    private WebView wv;
    private WindowManager wm;
    private boolean attached = false, finished = false;
    private PowerManager.WakeLock wl;
    private String sid, profile, pid, text, target, chatUrl;
    private boolean incognito, test;
    private long began;
    private String last = "start";
    private int waits = 0;
    private boolean waitRam;

    /** Starts a background run for this account. Throws if Android refuses to start a foreground service from here. */
    static void start(Context ctx, String profile, boolean test) { start(ctx, profile, test, 0); }
    /** attempt = how many low-memory checks already happened (0 = first run). */
    static void start(Context ctx, String profile, boolean test, int attempt) {
        Intent i = new Intent(ctx, OrbitSendService.class);
        i.putExtra("profile", profile).putExtra("test", test).putExtra("attempt", attempt);
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i); else ctx.startService(i);
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = note("Sending your scheduled message", "This closes by itself in a moment.");
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(NOTE_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(NOTE_ID, n);
        } catch (Exception e) {
            String p = intent == null ? null : intent.getStringExtra("profile");
            if (p != null) OrbitScheduleReceiver.openVisibly(this, p, "Android did not let Orbit send in the background.");
            stopSelf();
            return START_NOT_STICKY;
        }
        String p = intent == null ? null : intent.getStringExtra("profile");
        if (running) return START_NOT_STICKY; // a run is already going: the first one finishes and stops the service
        JSONObject s = p == null ? null : OrbitScheduleReceiver.get(this, p);
        if (s == null || s.optString("text", "").trim().isEmpty()) { stopForeground(true); stopSelf(); return START_NOT_STICKY; }
        running = true;
        sid = p; profile = s.optString("profile", p); pid = OrbitScheduleReceiver.pidOf(s); target = s.optString("target", "new"); chatUrl = s.optString("url", ""); test = intent.getBooleanExtra("test", false); text = s.optString("text", ""); waitRam = !test && s.optBoolean("ramwait", true); waits = intent.getIntExtra("attempt", 0); incognito = s.optBoolean("incognito", false); began = System.currentTimeMillis();
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "orbit:send");
            wl.setReferenceCounted(false);
            wl.acquire(120000L); // never longer than 2 minutes
        } catch (Exception ignored) { }
        h.post(new Runnable() { @Override public void run() { waitThenBegin(); } });
        return START_NOT_STICKY;
    }

    /** Small silent note shown while it waits for memory (not ongoing, so it can be swiped away). */
    private Notification quietNote(String title, String text) {
        Notification n = note(title, text);
        n.flags &= ~Notification.FLAG_ONGOING_EVENT;
        return n;
    }

    private Notification note(String title, String text) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Sending scheduled messages", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        int small = getResources().getIdentifier("orbit_ic_notif", "drawable", getPackageName());
        b.setSmallIcon(small != 0 ? small : android.R.drawable.stat_notify_sync).setColor(0xFF524FFF)
                .setContentTitle(title).setContentText(text).setOngoing(true);
        return b.build();
    }

    /** Low on memory (a game is open, for example)? Do not wait awake: give the phone back, set ONE alarm for a minute later and stop. Up to 10 tries. */
    private void waitThenBegin() {
        if (finished) return;
        boolean ok = true;
        if (waitRam) {
            try {
                android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                ok = OrbitScheduleMath.ramOk(mi.availMem, mi.lowMemory);
            } catch (Throwable ignored) { ok = true; }
        }
        if (ok) { begin(); return; }
        if (!OrbitScheduleMath.canRetry(waits)) { fail("Not enough free memory for 10 minutes, so nothing was sent."); return; }
        waits++;
        OrbitScheduleReceiver.scheduleRetry(this, sid, waits, OrbitScheduleMath.RETRY_MS);
        try { ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(NOTE_ID + 1, quietNote("Waiting for free memory", "Try " + waits + " of 10. It sends as soon as there is room.")); } catch (Throwable ignored) { }
        h.removeCallbacks(step);
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable ignored) { }
        running = false;
        stopForeground(true);
        stopSelf();
    }

    private void begin() {
        began = System.currentTimeMillis();
        try {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) { fail("This phone's WebView cannot keep accounts separate."); return; }
            wv = new WebView(getApplicationContext());
            WebViewCompat.setProfile(wv, OrbitScheduleReceiver.profileKeyFor(this, profile));
            WebSettings ws = wv.getSettings();
            ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setLoadsImagesAutomatically(false); // no pictures: less memory and data
            ws.setJavaScriptCanOpenWindowsAutomatically(false); ws.setSupportMultipleWindows(false);
            ws.setAllowFileAccess(false); ws.setSaveFormData(false);
            wv.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) { String sc = req.getUrl().getScheme(); return !("http".equals(sc) || "https".equals(sc)); }
            });
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            int w = dm.widthPixels, hh = dm.heightPixels;
            // Attach it OFF SCREEN when "Display over other apps" is allowed (a page that is attached behaves like a normal one); otherwise give the detached view a size.
            if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
                try {
                    wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
                    WindowManager.LayoutParams lp = new WindowManager.LayoutParams(w, hh,
                            Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                            PixelFormat.TRANSLUCENT);
                    lp.gravity = Gravity.TOP | Gravity.START; lp.x = -4 * w; lp.y = 0; lp.alpha = 0.01f;
                    wm.addView(wv, lp); attached = true;
                } catch (Throwable t) { attached = false; }
            }
            if (!attached) {
                wv.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(hh, View.MeasureSpec.EXACTLY));
                wv.layout(0, 0, w, hh);
            }
            wv.loadUrl("chat".equals(target) && !chatUrl.isEmpty() ? chatUrl : OrbitScheduleReceiver.newChatUrl(this, pid, incognito));
            h.postDelayed(step, 4000);
        } catch (Throwable t) {
            fail("Could not start the hidden browser (" + t.getClass().getSimpleName() + ").");
        }
    }

    private void poll() {
        if (finished || wv == null) return;
        if (System.currentTimeMillis() - began > 75000L) { fail(OrbitBrowserActivity.autoFailText(last)); return; }
        String u = wv.getUrl();
        if (u == null || !OrbitScheduleReceiver.onAiSite(this, pid, u)) { h.postDelayed(step, 1500); return; }
        final WebView v = wv;
        v.evaluateJavascript("(" + OrbitBrowserActivity.AUTO_JS + ")(" + JSONObject.quote(text) + "," + (incognito ? "true" : "false") + ")", new android.webkit.ValueCallback<String>() {
            @Override public void onReceiveValue(String value) {
                if (finished || v != wv) return;
                String r = value == null ? "" : value;
                if (r.length() >= 2 && r.startsWith("\"")) r = r.substring(1, r.length() - 1);
                last = r;
                if (r.equals("done")) succeed();
                else if (r.equals("limit") || r.equals("login") || r.startsWith("failed")) fail(OrbitBrowserActivity.autoFailText(r));
                else h.postDelayed(step, 1500);
            }
        });
    }

    private void succeed() {
        if (finished) return;
        finished = true;
        long next = OrbitScheduleReceiver.recordChat(this, sid, incognito);
        OrbitScheduleReceiver.finished(this, sid, true, "", next, test);
        cleanup();
    }

    private void fail(String msg) {
        if (finished) return;
        finished = true;
        OrbitScheduleReceiver.finished(this, sid, false, msg, 0, test);
        cleanup();
    }

    private void cleanup() {
        h.removeCallbacks(step);
        try { ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).cancel(NOTE_ID + 1); } catch (Throwable ignored) { }
        try { if (attached && wm != null && wv != null) wm.removeView(wv); } catch (Throwable ignored) { }
        try { if (wv != null) { wv.stopLoading(); wv.destroy(); } } catch (Throwable ignored) { }
        wv = null; attached = false;
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable ignored) { }
        running = false;
        stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() {
        h.removeCallbacks(step);
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable ignored) { }
        running = false;
        super.onDestroy();
    }
}
