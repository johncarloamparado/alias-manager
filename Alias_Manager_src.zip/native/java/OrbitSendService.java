package __PACKAGE__;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import org.json.JSONObject;

/**
 * Scheduled message, "no screen" mode (PROTOTYPE). Started by the alarm (OrbitScheduleReceiver) or by "Send a test in the background".
 * It opens the schedule's AI (a new chat, or the chosen chat) in a HIDDEN browser that uses the account's own isolated profile, types the text, presses Send, waits until the AI
 * shows the message, counts the chat (timer + Ready alarm) and stops. About 15-30 seconds, one foreground notification, a short wake lock.
 * Nothing runs between two schedules. It uses the same page script as the visible run (OrbitBrowserActivity.AUTO_JS).
 */
public class OrbitSendService extends Service {
    static final String CHANNEL = "orbit_sending";
    private static final int NOTE_ID = 7742;
    private static boolean running = false;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable step = new Runnable() { @Override public void run() { poll(); } };
    private WebView wv;
    private WindowManager wm;
    private boolean attached = false, finished = false;
    private PowerManager.WakeLock wl;
    private String sid, profile, pid, text, target, chatUrl;
    private boolean incognito, test;
    private long began;
    private String last = "start";
    private int waits = 0, netWaits = 0;
    private boolean reloaded = false;
    private org.json.JSONArray files = new org.json.JSONArray();
    private int phase = 0, nonImg = 0, img = 0;   // 0 = find the page's file box, 1 = sending the files to it, 2 = checking the AI shows them all, 3 = done (type the text and press Send)
    private long limitMs = 90000L, verifyAt = 0, okSince = 0, verifyBudget = 60000L;
    private java.util.concurrent.ExecutorService io;
    private boolean waitRam;

    /** Starts a background run for this account. Throws if Android refuses to start a foreground service from here. */
    static void start(Context ctx, String profile, boolean test) { start(ctx, profile, test, 0); }
    /** attempt = how many low-memory checks already happened (0 = first run). */
    static void start(Context ctx, String profile, boolean test, int attempt) {
        Intent i = new Intent(ctx, OrbitSendService.class);
        i.putExtra("profile", profile).putExtra("test", test).putExtra("attempt", attempt);
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i); else ctx.startService(i);
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = note("Sending your scheduled message", "This closes by itself in a moment.");
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(NOTE_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(NOTE_ID, n);
        } catch (Exception e) {
            String p = intent == null ? null : intent.getStringExtra("profile");
            if (p != null) OrbitScheduleReceiver.openVisibly(this, p, "Android did not let Orbit send in the background.");
            stopSelf();
            return START_NOT_STICKY;
        }
        String p = intent == null ? null : intent.getStringExtra("profile");
        if (running) return START_NOT_STICKY; // a run is already going: the first one finishes and stops the service
        JSONObject s = p == null ? null : OrbitScheduleReceiver.get(this, p);
        if (!OrbitScheduleReceiver.hasPayload(s)) { stopForeground(true); stopSelf(); return START_NOT_STICKY; }
        running = true;
        sid = p; files = OrbitScheduleReceiver.filesOf(s); profile = s.optString("profile", p); pid = OrbitScheduleReceiver.pidOf(s); target = s.optString("target", "new"); chatUrl = s.optString("url", ""); test = intent.getBooleanExtra("test", false); text = s.optString("text", ""); waitRam = !test && s.optBoolean("ramwait", true); waits = intent.getIntExtra("attempt", 0); incognito = s.optBoolean("incognito", false); began = System.currentTimeMillis();
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "orbit:send");
            wl.setReferenceCounted(false);
            wl.acquire(120000L); // never longer than 2 minutes
        } catch (Exception ignored) { }
        h.post(new Runnable() { @Override public void run() { waitThenBegin(); } });
        return START_NOT_STICKY;
    }

    /** Small silent note shown while it waits for memory (not ongoing, so it can be swiped away). */
    private Notification quietNote(String title, String text) {
        Notification n = note(title, text);
        n.flags &= ~Notification.FLAG_ONGOING_EVENT;
        return n;
    }

    private Notification note(String title, String text) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Sending scheduled messages", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        int small = getResources().getIdentifier("orbit_ic_notif", "drawable", getPackageName());
        b.setSmallIcon(small != 0 ? small : android.R.drawable.stat_notify_sync).setColor(0xFF524FFF)
                .setContentTitle(title).setContentText(text).setOngoing(true);
        return b.build();
    }

    /** Low on memory (a game is open, for example)? Do not wait awake: give the phone back, set ONE alarm for a minute later and stop. Up to 10 tries. */
    private void waitThenBegin() {
        if (finished) return;
        boolean ok = true;
        if (waitRam) {
            try {
                android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                ok = OrbitScheduleMath.ramOk(mi.availMem, mi.lowMemory);
            } catch (Throwable ignored) { ok = true; }
        }
        if (ok) { begin(); return; }
        if (!OrbitScheduleMath.canRetry(waits)) { fail("Not enough free memory for 10 minutes, so nothing was sent."); return; }
        waits++;
        OrbitScheduleReceiver.scheduleRetry(this, sid, waits, OrbitScheduleMath.RETRY_MS);
        try { ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(NOTE_ID + 1, quietNote("Waiting for free memory", "Try " + waits + " of 10. It sends as soon as there is room.")); } catch (Throwable ignored) { }
        h.removeCallbacks(step);
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable ignored) { }
        running = false;
        stopForeground(true);
        stopSelf();
    }

    /** With photos or files: first check that every one can still be read and is not huge, before anything is loaded. */
    private void begin() {
        if (files.length() == 0) { beginWeb(); return; }
        io = java.util.concurrent.Executors.newSingleThreadExecutor();
        io.execute(new Runnable() { @Override public void run() {
            String bad = null; long total = 0; int ni = 0, im = 0;
            for (int i = 0; i < files.length() && bad == null; i++) {
                org.json.JSONObject f = files.optJSONObject(i);
                if (f == null) continue;
                String nm = f.optString("name", "a file");
                try (java.io.InputStream is = getContentResolver().openInputStream(android.net.Uri.parse(f.optString("uri")))) { if (is == null) bad = "A file is no longer available: " + nm + ". Pick it again in the schedule."; }
                catch (Throwable t) { bad = "A file is no longer available: " + nm + ". Pick it again in the schedule."; }
                long sz = f.optLong("size", 0); total += sz;
                if (bad == null && sz > 100L * 1024 * 1024) bad = nm + " is over 100 MB: too big to send in the background.";
                if (f.optString("type", "").startsWith("image/")) im++; else ni++;
            }
            if (bad == null && total > 400L * 1024 * 1024) bad = "The files add up to more than 400 MB: too much to send in the background.";
            final String b = bad; final int fni = ni, fim = im; final long tot = total;
            h.post(new Runnable() { @Override public void run() {
                if (finished) return;
                if (b != null) { fail(b + " Nothing was sent."); return; }
                nonImg = fni; img = fim;
                double mb = tot / 1048576.0;
                verifyBudget = Math.min(300000L, 30000L + (long) (mb * 3000)); // how long the AI may take to show the uploaded files
                beginWeb();
            } });
        } });
    }

    private void beginWeb() {
        began = System.currentTimeMillis();
        try {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) { fail("This phone's WebView cannot keep accounts separate."); return; }
            wv = new WebView(getApplicationContext());
            WebViewCompat.setProfile(wv, OrbitScheduleReceiver.profileKeyFor(this, profile));
            wv.onResume(); wv.resumeTimers(); // never let a hidden page sleep
            try { // make the hidden page believe it is visible, from the very first script (newer WebView versions)
                if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT))
                    WebViewCompat.addDocumentStartJavaScript(wv, OrbitBrowserActivity.HIDDEN_POLY, new java.util.HashSet<String>(java.util.Collections.singletonList("*")));
            } catch (Throwable ignored) { }
            WebSettings ws = wv.getSettings();
            ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); // pictures stay on: the page should look like a normal one
            ws.setJavaScriptCanOpenWindowsAutomatically(false); ws.setSupportMultipleWindows(false);
            ws.setAllowFileAccess(false); ws.setSaveFormData(false);
            wv.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) { String sc = req.getUrl().getScheme(); return !("http".equals(sc) || "https".equals(sc)); }
            });
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            int w = dm.widthPixels, hh = dm.heightPixels;
            // Attach it OFF SCREEN when "Display over other apps" is allowed (a page that is attached behaves like a normal one); otherwise give the detached view a size.
            if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
                try {
                    wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
                    WindowManager.LayoutParams lp = new WindowManager.LayoutParams(w, hh,
                            Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                            PixelFormat.TRANSLUCENT);
                    lp.gravity = Gravity.TOP | Gravity.START; lp.x = -4 * w; lp.y = 0; lp.alpha = 0.01f;
                    wm.addView(wv, lp); attached = true;
                } catch (Throwable t) { attached = false; }
            }
            if (!attached) {
                wv.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(hh, View.MeasureSpec.EXACTLY));
                wv.layout(0, 0, w, hh);
            }
            loadWhenOnline();
        } catch (Throwable t) {
            fail("Could not start the hidden browser (" + t.getClass().getSimpleName() + ").");
        }
    }

    private String startUrl() { return "chat".equals(target) && !chatUrl.isEmpty() ? chatUrl : OrbitScheduleReceiver.newChatUrl(this, pid, incognito); }

    /** Right after the phone wakes up the network may need a moment: wait up to 30 seconds for it before loading the page. */
    private void loadWhenOnline() {
        if (finished || wv == null) return;
        boolean online = true;
        try {
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            android.net.NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            online = ni != null && ni.isConnected();
        } catch (Throwable ignored) { online = true; } // no permission to ask: just try
        if (!online && netWaits < 15) { netWaits++; h.postDelayed(new Runnable() { @Override public void run() { loadWhenOnline(); } }, 2000L); return; }
        began = System.currentTimeMillis();
        wv.loadUrl(startUrl());
        h.postDelayed(step, 4000);
    }

    private void poll() {
        if (finished || wv == null) return;
        long age = System.currentTimeMillis() - began;
        if (age > limitMs) { fail(OrbitBrowserActivity.autoFailText(last)); return; }
        String u = wv.getUrl();
        if (u == null || !OrbitScheduleReceiver.onAiSite(this, pid, u)) {
            if (age > 25000L && !reloaded) { reloaded = true; wv.loadUrl(startUrl()); } // the first load went nowhere: one more try
            h.postDelayed(step, 1500); return;
        }
        if (files.length() > 0 && phase < 3) { attachStep(); return; }
        final WebView v = wv;
        v.evaluateJavascript(OrbitBrowserActivity.HIDDEN_POLY + "(" + OrbitBrowserActivity.AUTO_JS + ")(" + JSONObject.quote(text) + "," + (incognito ? "true" : "false") + ")", new android.webkit.ValueCallback<String>() {
            @Override public void onReceiveValue(String value) {
                if (finished || v != wv) return;
                String r = value == null ? "" : value;
                if (r.length() >= 2 && r.startsWith("\"")) r = r.substring(1, r.length() - 1);
                last = r;
                if (r.equals("done")) succeed();
                else if (r.equals("limit") || r.equals("login") || r.startsWith("failed")) fail(OrbitBrowserActivity.autoFailText(r));
                else h.postDelayed(step, 1500);
            }
        });
    }

    private static String unq(String v) { return v != null && v.length() >= 2 && v.startsWith("\"") ? v.substring(1, v.length() - 1) : (v == null ? "" : v); }

    /** Photos and files: find the page's file box, hand the files over in pieces, wait until the AI shows ALL of them. If it does not, nothing is sent. */
    private void attachStep() {
        final WebView v = wv;
        if (phase == 0) {
            v.evaluateJavascript(OrbitBrowserActivity.HIDDEN_POLY + OrbitBrowserActivity.ATT_JS + ";__orbitAtt.prep()", new android.webkit.ValueCallback<String>() {
                @Override public void onReceiveValue(String value) {
                    if (finished || v != wv) return;
                    if (unq(value).equals("input")) { phase = 1; began = System.currentTimeMillis(); limitMs = 120000L + verifyBudget * 2; pumpFiles(); }
                    else if (System.currentTimeMillis() - began > 45000L) fail("Could not find where to attach files on the page. Nothing was sent.");
                    else h.postDelayed(step, 1500);
                }
            });
        } else if (phase == 2) {
            v.evaluateJavascript("__orbitAtt.check(" + nonImg + "," + img + ")", new android.webkit.ValueCallback<String>() {
                @Override public void onReceiveValue(String value) {
                    if (finished || v != wv) return;
                    String r = unq(value);
                    long now = System.currentTimeMillis();
                    if (r.equals("ok")) {
                        if (okSince == 0) okSince = now;
                        if (now - okSince >= 2000L) { phase = 3; began = now; limitMs = 90000L; h.postDelayed(step, 300); } else h.postDelayed(step, 800);
                        return;
                    }
                    okSince = 0;
                    if (r.startsWith("error:")) fail("The AI refused the files (" + r.substring(6) + "). Nothing was sent.");
                    else if (now - verifyAt > verifyBudget) fail("The AI did not accept all " + files.length() + " files (it shows " + r.replace("wait:", "") + "). Nothing was sent.");
                    else h.postDelayed(step, 1500);
                }
            });
        } else h.postDelayed(step, 1500); // phase 1: the files are on their way
    }

    /** Runs a script in the page and waits for its answer (called from the file thread). */
    private String evalWait(final String js) throws Exception {
        final String[] out = new String[1];
        final java.util.concurrent.CountDownLatch l = new java.util.concurrent.CountDownLatch(1);
        h.post(new Runnable() { @Override public void run() {
            if (wv == null || finished) { l.countDown(); return; }
            wv.evaluateJavascript(js, new android.webkit.ValueCallback<String>() { @Override public void onReceiveValue(String v) { out[0] = v; l.countDown(); } });
        } });
        if (!l.await(40, java.util.concurrent.TimeUnit.SECONDS)) throw new java.io.IOException("the page did not answer");
        if (finished) throw new java.io.IOException("stopped");
        return out[0];
    }

    /** Reads each file straight from where it is (gallery, file manager) and gives the page ~190 KB at a time: never the whole file in memory, nothing copied to Orbit's storage. */
    private void pumpFiles() {
        if (io == null) io = java.util.concurrent.Executors.newSingleThreadExecutor();
        io.execute(new Runnable() { @Override public void run() {
            String failMsg = null; String commit = "";
            try {
                for (int i = 0; i < files.length() && failMsg == null; i++) {
                    org.json.JSONObject f = files.getJSONObject(i);
                    evalWait("__orbitAtt.begin(" + JSONObject.quote(f.optString("name", "file")) + "," + JSONObject.quote(f.optString("type", "application/octet-stream")) + ")");
                    try (java.io.InputStream is = getContentResolver().openInputStream(android.net.Uri.parse(f.optString("uri")))) {
                        if (is == null) { failMsg = "A file is no longer available: " + f.optString("name") + ". Nothing was sent."; break; }
                        byte[] buf = new byte[196608]; int r;
                        while ((r = is.read(buf)) > 0) evalWait("__orbitAtt.chunk('" + android.util.Base64.encodeToString(buf, 0, r, android.util.Base64.NO_WRAP) + "')");
                    }
                    evalWait("__orbitAtt.end()");
                }
                if (failMsg == null) commit = unq(evalWait("__orbitAtt.commit()"));
            } catch (Throwable t) { failMsg = "Could not send the files to the page (" + t.getClass().getSimpleName() + "). Nothing was sent."; }
            final String fm = failMsg, cm = commit;
            h.post(new Runnable() { @Override public void run() {
                if (finished) return;
                if (fm != null) { fail(fm); return; }
                if (!cm.startsWith("committed")) { fail("The page did not take the files (" + cm + "). Nothing was sent."); return; }
                phase = 2; verifyAt = System.currentTimeMillis(); h.postDelayed(step, 1500);
            } });
        } });
    }

    private void succeed() {
        if (finished) return;
        finished = true;
        long next = OrbitScheduleReceiver.recordChat(this, sid, incognito);
        OrbitScheduleReceiver.finished(this, sid, true, "", next, test);
        cleanup();
    }

    private void fail(String msg) {
        if (finished) return;
        finished = true;
        OrbitScheduleReceiver.finished(this, sid, false, msg, 0, test);
        cleanup();
    }

    private void cleanup() {
        h.removeCallbacks(step);
        try { ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).cancel(NOTE_ID + 1); } catch (Throwable ignored) { }
        try { if (attached && wm != null && wv != null) wm.removeView(wv); } catch (Throwable ignored) { }
        try { if (wv != null) { wv.stopLoading(); wv.destroy(); } } catch (Throwable ignored) { }
        wv = null; attached = false;
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable ignored) { }
        try { if (io != null) io.shutdownNow(); } catch (Throwable ignored) { }
        running = false;
        stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() {
        h.removeCallbacks(step);
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable ignored) { }
        running = false;
        super.onDestroy();
    }
}
