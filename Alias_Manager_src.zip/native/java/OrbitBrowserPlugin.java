package __PACKAGE__;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.JSObject;
import com.getcapacitor.JSArray;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "OrbitBrowser")
public class OrbitBrowserPlugin extends Plugin {
    /** Last time one of our screens left the foreground (0 = since the app process started). Used by the app lock: asks again after 30 s away. */
    static volatile long lastActive = 0;
    private boolean suppressLockOnce = false;
    private String pendingSaveText = null;

    @Override protected void handleOnPause() { lastActive = System.currentTimeMillis(); super.handleOnPause(); }

    // ---------- App lock (phone PIN / pattern / fingerprint through Android's own screen-lock screen) ----------
    @PluginMethod
    public void setLock(PluginCall call) {
        boolean on = Boolean.TRUE.equals(call.getBoolean("enabled", false));
        getContext().getSharedPreferences("orbit_profiles", Context.MODE_PRIVATE).edit().putBoolean("app_lock", on).commit();
        call.resolve();
    }

    @PluginMethod
    public void needsUnlock(PluginCall call) {
        JSObject ret = new JSObject();
        boolean on = getContext().getSharedPreferences("orbit_profiles", Context.MODE_PRIVATE).getBoolean("app_lock", false);
        boolean needed = on && (lastActive == 0 || System.currentTimeMillis() - lastActive > 30000);
        if (suppressLockOnce) { suppressLockOnce = false; needed = false; } // came back from a file picker we opened ourselves
        ret.put("needed", needed);
        call.resolve(ret);
    }

    @PluginMethod
    public void authenticate(PluginCall call) {
        JSObject ret = new JSObject();
        try {
            KeyguardManager km = (KeyguardManager) getContext().getSystemService(Context.KEYGUARD_SERVICE);
            Intent i = (km != null && km.isDeviceSecure()) ? km.createConfirmDeviceCredentialIntent("Orbit", "Unlock to continue") : null;
            if (i == null) { ret.put("ok", true); ret.put("noLock", true); call.resolve(ret); return; }
            startActivityForResult(call, i, "authResult");
        } catch (Exception e) {
            call.reject("Unable to ask for the screen lock: " + e.getMessage());
        }
    }

    @ActivityCallback
    public void authResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        boolean ok = result != null && result.getResultCode() == Activity.RESULT_OK;
        if (ok) lastActive = System.currentTimeMillis();
        JSObject ret = new JSObject(); ret.put("ok", ok);
        call.resolve(ret);
    }

    // ---------- Save / open a backup file anywhere (pick Google Drive in Android's own file screen) ----------
    @PluginMethod
    public void saveFile(PluginCall call) {
        try {
            String text = call.getString("text", "");
            String name = call.getString("name", "alias-manager-backup.json");
            pendingSaveText = text == null ? "" : text;
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/json");
            i.putExtra(Intent.EXTRA_TITLE, name);
            suppressLockOnce = true;
            startActivityForResult(call, i, "saveResult");
        } catch (Exception e) {
            call.reject("Unable to open the save screen: " + e.getMessage());
        }
    }

    @ActivityCallback
    public void saveResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject ret = new JSObject();
        boolean saved = false;
        try {
            if (result != null && result.getResultCode() == Activity.RESULT_OK && result.getData() != null && result.getData().getData() != null && pendingSaveText != null) {
                Uri u = result.getData().getData();
                try (java.io.OutputStream os = getContext().getContentResolver().openOutputStream(u, "wt")) {
                    if (os != null) { os.write(pendingSaveText.getBytes("UTF-8")); os.flush(); saved = true; }
                }
            }
        } catch (Exception e) {
            pendingSaveText = null;
            call.reject("Could not write the file: " + e.getMessage());
            return;
        }
        pendingSaveText = null;
        ret.put("saved", saved);
        call.resolve(ret);
    }

    @PluginMethod
    public void pickFile(PluginCall call) {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain", "application/octet-stream"});
            suppressLockOnce = true;
            startActivityForResult(call, i, "pickResult");
        } catch (Exception e) {
            call.reject("Unable to open the file screen: " + e.getMessage());
        }
    }

    @ActivityCallback
    public void pickResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject ret = new JSObject();
        try {
            if (result != null && result.getResultCode() == Activity.RESULT_OK && result.getData() != null && result.getData().getData() != null) {
                Uri u = result.getData().getData();
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                try (java.io.InputStream in = getContext().getContentResolver().openInputStream(u)) {
                    if (in == null) throw new java.io.IOException("cannot open file");
                    byte[] buf = new byte[65536]; int n; long total = 0;
                    while ((n = in.read(buf)) > 0) { total += n; if (total > 20L * 1024 * 1024) throw new java.io.IOException("file is too big"); bo.write(buf, 0, n); }
                }
                ret.put("text", bo.toString("UTF-8"));
            }
        } catch (Exception e) {
            call.reject("Could not read the file: " + e.getMessage());
            return;
        }
        call.resolve(ret);
    }
    /** Returns and clears the queued "first chat" events written by OrbitBrowserActivity. */
    @PluginMethod
    public void consumeEvents(PluginCall call) {
        JSObject ret = new JSObject();
        try {
            SharedPreferences p = getContext().getSharedPreferences("orbit_profiles", Context.MODE_PRIVATE);
            String raw;
            synchronized (OrbitBrowserActivity.LOCK) {
                raw = p.getString("events", "[]");
                p.edit().remove("events").commit();
            }
            ret.put("events", new JSArray(raw));
        } catch (Exception e) {
            ret.put("events", new JSArray());
        }
        call.resolve(ret);
    }

    /** Replace all "cooldown finished" notifications with the given list: reminders:[{id,label,at(ms)}]. */
    @PluginMethod
    public void scheduleReminders(PluginCall call) {
        JSObject ret = new JSObject();
        try {
            JSArray list = call.getArray("reminders");
            int n = OrbitReminderReceiver.sync(getContext(), list == null ? new JSArray() : list);
            boolean allowed = true;
            if (Build.VERSION.SDK_INT >= 33 && n > 0
                    && getContext().checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                allowed = false;
                getActivity().requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7731);
            }
            ret.put("scheduled", n);
            ret.put("notificationsAllowed", allowed);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Unable to schedule reminders: " + e.getMessage());
        }
    }

    /** Keeps a copy of the alias list for Orbit, so Orbit never depends only on the Intent it was opened with. */
    @PluginMethod
    public void syncAliases(PluginCall call) {
        try {
            JSArray list = call.getArray("aliases");
            SharedPreferences.Editor ed = getContext().getSharedPreferences("orbit_profiles", Context.MODE_PRIVATE).edit();
            ed.putString("aliases_json", list == null ? "[]" : list.toString());
            JSArray prov = call.getArray("providers");
            if (prov != null) ed.putString("providers_json", prov.toString());
            JSArray widget = call.getArray("widget");
            if (widget != null) ed.putString("widget_json", widget.toString());
            ed.commit();
            if (widget != null) OrbitWidgetProvider.refresh(getContext());
            call.resolve();
        } catch (Exception e) {
            call.reject("Unable to sync aliases: " + e.getMessage());
        }
    }

    /** Orbit's own settings for the Alias Manager backup file: profiles, which alias each profile uses, colors/emoji, WebView keys. */
    @PluginMethod
    public void getBackup(PluginCall call) {
        try {
            SharedPreferences p = getContext().getSharedPreferences("orbit_profiles", Context.MODE_PRIVATE);
            JSObject ret = new JSObject();
            ret.put("profiles", p.getString("profiles", "Account 1"));
            ret.put("active", p.getString("active", ""));
            ret.put("links", new JSObject(p.getString("links", "{}")));
            ret.put("styles", new JSObject(p.getString("styles", "{}")));
            ret.put("keys", new JSObject(p.getString("keys", "{}")));
            ret.put("projects", new JSObject(p.getString("projects", "{}")));
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Unable to read Orbit backup: " + e.getMessage());
        }
    }

    /** Puts a backup made by getBackup() back. Cookies/logins are NOT part of it (they cannot be backed up). */
    @PluginMethod
    public void restoreBackup(PluginCall call) {
        try {
            String profiles = call.getString("profiles", "");
            if (profiles == null || profiles.trim().isEmpty()) { call.resolve(); return; }
            SharedPreferences.Editor ed = getContext().getSharedPreferences("orbit_profiles", Context.MODE_PRIVATE).edit();
            ed.putString("profiles", profiles);
            String active = call.getString("active", "");
            if (active != null && !active.isEmpty()) ed.putString("active", active);
            JSObject links = call.getObject("links"); if (links != null) ed.putString("links", links.toString());
            JSObject styles = call.getObject("styles"); if (styles != null) ed.putString("styles", styles.toString());
            JSObject keys = call.getObject("keys"); if (keys != null) ed.putString("keys", keys.toString());
            JSObject projects = call.getObject("projects"); if (projects != null) ed.putString("projects", projects.toString());
            ed.commit();
            call.resolve();
        } catch (Exception e) {
            call.reject("Unable to restore Orbit backup: " + e.getMessage());
        }
    }

    /** Alias Manager deleted aliases: remove each one's Orbit profile (login data, link, tab). The last remaining profile is emptied instead of removed. */
    @PluginMethod
    public void removeAliases(PluginCall call) {
        try {
            JSArray ids = call.getArray("ids");
            if (ids == null || ids.length() == 0) { call.resolve(); return; }
            SharedPreferences p = getContext().getSharedPreferences("orbit_profiles", Context.MODE_PRIVATE);
            org.json.JSONObject links = new org.json.JSONObject(p.getString("links", "{}"));
            org.json.JSONObject keys = new org.json.JSONObject(p.getString("keys", "{}"));
            org.json.JSONObject styles = new org.json.JSONObject(p.getString("styles", "{}"));
            org.json.JSONObject seen = new org.json.JSONObject(p.getString("seen", "{}"));
            java.util.List<String> profiles = new java.util.ArrayList<>();
            for (String s : p.getString("profiles", "Account 1").split("\\n")) if (!s.trim().isEmpty()) profiles.add(s.trim());
            if (profiles.isEmpty()) profiles.add("Account 1");
            String active = p.getString("active", profiles.get(0));
            java.util.LinkedHashSet<String> pend = new java.util.LinkedHashSet<>();
            for (String k : p.getString("pending_erase", "").split("\\n")) if (!k.trim().isEmpty()) pend.add(k.trim());
            boolean changed = false;
            for (int i = 0; i < ids.length(); i++) {
                String id = ids.getString(i);
                String prof = null;
                java.util.Iterator<String> it = links.keys();
                while (it.hasNext()) { String n = it.next(); if (id.equals(links.optString(n, ""))) { prof = n; break; } }
                if (prof == null) continue;
                String key = keys.optString(prof, "");
                if (key.isEmpty()) key = OrbitBrowserActivity.profileKey(prof);
                links.remove(prof); seen.remove(prof); pend.add(key);
                if (profiles.size() > 1) { profiles.remove(prof); keys.remove(prof); styles.remove(prof); }
                else keys.put(prof, "orbit_" + java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 10)); // only tab left: keep it, with fresh empty data
                changed = true;
            }
            if (!profiles.contains(active)) active = profiles.get(0);
            if (changed) {
                p.edit().putString("links", links.toString()).putString("keys", keys.toString()).putString("styles", styles.toString())
                    .putString("seen", seen.toString()).putString("profiles", android.text.TextUtils.join("\n", profiles)).putString("active", active)
                    .putString("pending_erase", android.text.TextUtils.join("\n", pend)).putLong("rev", System.currentTimeMillis()).commit();
                OrbitBrowserActivity.erasePendingStatic(p); // may need a moment if Orbit is open; Orbit finishes it when it comes back
            }
            call.resolve();
        } catch (Exception e) {
            call.reject("Unable to remove Orbit data: " + e.getMessage());
        }
    }

    @PluginMethod
    public void open(PluginCall call) {
        try {
            Intent intent = new Intent(getContext(), OrbitBrowserActivity.class);
            JSArray aliases = call.getArray("aliases");
            if (aliases != null) {
                getContext().getSharedPreferences("orbit_profiles", Context.MODE_PRIVATE)
                    .edit().putString("aliases_json", aliases.toString()).commit();
            }
            intent.putExtra("aliases", aliases == null ? "[]" : aliases.toString());
            JSArray prov = call.getArray("providers");
            if (prov != null) {
                getContext().getSharedPreferences("orbit_profiles", Context.MODE_PRIVATE).edit().putString("providers_json", prov.toString()).commit();
                intent.putExtra("providers", prov.toString());
            }
            String service = call.getString("service");
            if (service != null && !service.isEmpty()) intent.putExtra("service", service);
            intent.putExtra("createIfMissing", call.getBoolean("createIfMissing", false));
            intent.putExtra("keepLive", call.getInt("keepLive", 2));
            intent.putExtra("autoStart", call.getBoolean("autoStart", true));
            String aliasId = call.getString("aliasId");
            if (aliasId != null && !aliasId.isEmpty()) intent.putExtra("aliasId", aliasId); // open the profile linked to this alias
            getActivity().startActivity(intent);
            call.resolve();
        } catch (Exception e) {
            call.reject("Unable to open Orbit Browser: " + e.getMessage());
        }
    }
}
