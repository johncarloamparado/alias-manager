#!/usr/bin/env python3
"""Install the Orbit Browser (Java) into the Capacitor-generated android/ project.

Deterministic and idempotent: running it 1x or 2x gives the same result.
Fails loudly (non-zero exit) if anything is not in the expected place.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent
ANDROID = ROOT / "android"
NATIVE = ROOT / "native" / "java"
FILES = ("OrbitBrowserPlugin.java", "OrbitBrowserActivity.java", "OrbitReminderReceiver.java", "OrbitWidgetProvider.java", "OrbitKeepAliveService.java", "OrbitScheduleReceiver.java", "OrbitSendService.java", "OrbitScheduleMath.java")
RES_SRC = ROOT / "native" / "res"
WEBKIT_VERSION = "1.14.0"


def die(msg):
    print("ERROR: " + msg, file=sys.stderr)
    sys.exit(1)


if not ANDROID.exists():
    die("android/ missing; run `npx cap add android` first")

# --- 1. Find MainActivity (Capacitor 7 generates Java) and read its package ---
java_root = ANDROID / "app/src/main/java"
mains = sorted(java_root.glob("**/MainActivity.java"))
if not mains:
    kt = sorted(java_root.glob("**/MainActivity.kt"))
    die("MainActivity.java not found" + (" (found MainActivity.kt: this patch is Java-only)" if kt else ""))
main = mains[0]
text = main.read_text()
m = re.search(r"^package\s+([\w.]+)\s*;", text, re.M)
if not m:
    die("cannot read package from " + str(main))
pkg = m.group(1)
dest = main.parent  # same folder as MainActivity => guaranteed matching package
print("Package: " + pkg)
print("Dest   : " + str(dest.relative_to(ANDROID)))

# --- 2. Copy native sources with the real package ---
for name in FILES:
    src = NATIVE / name
    if not src.exists():
        die("missing source " + str(src))
    body = src.read_text()
    if "package __PACKAGE__;" not in body:
        die(name + " must start with `package __PACKAGE__;`")
    (dest / name).write_text(body.replace("__PACKAGE__", pkg))

# --- 2b. Home-screen widget resources (layout / xml / drawable) ---
res_dest = ANDROID / "app/src/main/res"
if not RES_SRC.exists():
    die("missing " + str(RES_SRC))
for rf in sorted(p for p in RES_SRC.rglob("*") if p.is_file() and p.suffix in (".xml", ".png")):
    target = res_dest / rf.relative_to(RES_SRC)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(rf.read_bytes())
    print("OK res  : " + str(target.relative_to(ANDROID)))

# --- 3. Register the plugin in MainActivity (inject, do not rewrite) ---
reg = "registerPlugin(OrbitBrowserPlugin.class);"
text = re.sub(r"[ \t]*registerPlugin\((?:[\w.]*\.)?OrbitBrowserPlugin\.class\);[ \t]*\n", "", text)
if "onCreate(" in text:
    text = re.sub(r"(\n([ \t]*)super\.onCreate\(savedInstanceState\);)",
                  lambda mo: "\n" + mo.group(2) + reg + mo.group(1), text, count=1)
else:
    if "import android.os.Bundle;" not in text:
        text = re.sub(r"(package\s+[\w.]+\s*;\n)", r"\1\nimport android.os.Bundle;", text, count=1)
    method = ("\n    @Override\n    public void onCreate(Bundle savedInstanceState) {\n"
              "        " + reg + "\n        super.onCreate(savedInstanceState);\n    }\n")
    idx = text.rstrip().rfind("}")
    text = text[:idx].rstrip() + "\n" + method + "}\n"
if text.count("OrbitBrowserPlugin.class") != 1:
    die("MainActivity registration failed")
main.write_text(text)

# --- 4. Manifest: exactly one Activity + one Receiver declaration, notification permission ---
manifest = ANDROID / "app/src/main/AndroidManifest.xml"
mt = manifest.read_text()
mt = re.sub(r"\s*<activity\s+android:name=\"[^\"]*OrbitBrowserActivity\"[^>]*/>", "", mt)
mt = re.sub(r"\s*<receiver\s+android:name=\"[^\"]*OrbitReminderReceiver\"(?:[^>]*/>|[^>]*>.*?</receiver>)", "", mt, flags=re.S)
mt = re.sub(r"\s*<receiver\s+android:name=\"[^\"]*OrbitScheduleReceiver\"(?:[^>]*/>|[^>]*>.*?</receiver>)", "", mt, flags=re.S)
mt = re.sub(r"\s*<receiver\s+android:name=\"[^\"]*OrbitWidgetProvider\"(?:[^>]*/>|[^>]*>.*?</receiver>)", "", mt, flags=re.S)
mt = re.sub(r"\s*<service\s+android:name=\"[^\"]*OrbitKeepAliveService\"(?:[^>]*/>|[^>]*>.*?</service>)", "", mt, flags=re.S)
mt = re.sub(r"\s*<service\s+android:name=\"[^\"]*OrbitSendService\"(?:[^>]*/>|[^>]*>.*?</service>)", "", mt, flags=re.S)
if "android.permission.RECEIVE_BOOT_COMPLETED" not in mt:
    mt = mt.replace("<application", '<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />\n    <application', 1)
if "android.permission.POST_NOTIFICATIONS" not in mt:
    if "<application" not in mt:
        die("manifest has no <application")
    mt = mt.replace("<application", '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n    <application', 1)
# Step 13e permissions: keep-alive foreground service, wake lock, battery-optimization request
EXTRA_PERMS = ("FOREGROUND_SERVICE", "FOREGROUND_SERVICE_SPECIAL_USE", "WAKE_LOCK", "REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", "SCHEDULE_EXACT_ALARM", "SYSTEM_ALERT_WINDOW")
for perm in EXTRA_PERMS:
    full = "android.permission." + perm
    if 'android:name="' + full + '"' not in mt:
        mt = mt.replace("<application", '<uses-permission android:name="' + full + '" />\n    <application', 1)
decl = ('\n        <activity\n            android:name="' + pkg + '.OrbitBrowserActivity"\n'
        '            android:exported="false"\n'
        '            android:configChanges="orientation|keyboardHidden|screenSize|smallestScreenSize|screenLayout"\n'
        '            android:supportsPictureInPicture="true"\n'
        '            android:theme="@android:style/Theme.Material.NoActionBar" />\n'
        '        <service android:name="' + pkg + '.OrbitKeepAliveService" android:exported="false" android:foregroundServiceType="specialUse">\n'
        '            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="Keeps the user-started AI chat browser alive while a reply is being written" />\n'
        '        </service>\n'
        '        <service android:name="' + pkg + '.OrbitSendService" android:exported="false" android:foregroundServiceType="specialUse">\n'
        '            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="Sends the message the user scheduled, in a hidden browser, then stops" />\n'
        '        </service>\n'
        '        <receiver android:name="' + pkg + '.OrbitReminderReceiver" android:exported="false">\n'
        '            <intent-filter>\n'
        '                <action android:name="android.intent.action.BOOT_COMPLETED" />\n'
        '            </intent-filter>\n'
        '        </receiver>\n'
        '        <receiver android:name="' + pkg + '.OrbitScheduleReceiver" android:exported="false">\n'
        '            <intent-filter>\n'
        '                <action android:name="android.intent.action.BOOT_COMPLETED" />\n'
        '            </intent-filter>\n'
        '        </receiver>\n'
        '        <receiver android:name="' + pkg + '.OrbitWidgetProvider" android:exported="true">\n'
        '            <intent-filter>\n'
        '                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />\n'
        '            </intent-filter>\n'
        '            <meta-data android:name="android.appwidget.provider" android:resource="@xml/orbit_widget_info" />\n'
        '        </receiver>\n')
if "</application>" not in mt:
    die("manifest has no </application>")
# Launcher icon: use our own adaptive icon (@mipmap/orbit_launcher) instead of the one capacitor-assets generates (it shrinks the logo).
m_app = re.search(r"<application\b[^>]*>", mt, re.S)
if not m_app:
    die("manifest has no <application ...> tag")
app_tag = m_app.group(0)
new_tag = app_tag
for attr in ("android:icon", "android:roundIcon"):
    if re.search(attr + r'="[^"]*"', new_tag):
        new_tag = re.sub(attr + r'="[^"]*"', attr + '="@mipmap/orbit_launcher"', new_tag)
    else:
        new_tag = new_tag.replace("<application", "<application " + attr + '="@mipmap/orbit_launcher"', 1)
mt = mt.replace(app_tag, new_tag, 1)
mt = mt.replace("</application>", decl + "    </application>", 1)
# Camera photos for uploads go through the app's FileProvider (authority <package>.fileprovider, cache folder).
fp_xml = ANDROID / "app/src/main/res/xml/file_paths.xml"
if ".fileprovider" not in mt:
    prov = ('\n        <provider\n            android:name="androidx.core.content.FileProvider"\n'
            '            android:authorities="' + pkg + '.fileprovider"\n'
            '            android:exported="false"\n            android:grantUriPermissions="true">\n'
            '            <meta-data android:name="android.support.FILE_PROVIDER_PATHS" android:resource="@xml/file_paths" />\n'
            '        </provider>\n')
    mt = mt.replace("</application>", prov + "    </application>", 1)
    print("NOTE   : FileProvider was missing; added " + pkg + ".fileprovider")
fp_xml.parent.mkdir(parents=True, exist_ok=True)
if not fp_xml.exists():
    fp_xml.write_text('<?xml version="1.0" encoding="utf-8"?>\n<paths xmlns:android="http://schemas.android.com/apk/res/android">\n'
                      '    <cache-path name="orbit_cache" path="." />\n</paths>\n')
    print("NOTE   : created res/xml/file_paths.xml")
else:
    ft = fp_xml.read_text()
    if "<cache-path" not in ft:
        ft = ft.replace("</paths>", '    <cache-path name="orbit_cache" path="." />\n</paths>')
        fp_xml.write_text(ft)
        print("NOTE   : added cache-path to file_paths.xml")
manifest.write_text(mt)

# --- 5. Gradle: exactly one androidx.webkit dependency ---
gradle = ANDROID / "app/build.gradle"
kts = False
if not gradle.exists():
    gradle = ANDROID / "app/build.gradle.kts"
    kts = True
if not gradle.exists():
    die("app/build.gradle(.kts) not found")
gt = gradle.read_text()
if "androidx.webkit:webkit" not in gt:
    dep = ('    implementation("androidx.webkit:webkit:%s")' if kts
           else "    implementation 'androidx.webkit:webkit:%s'") % WEBKIT_VERSION
    if "dependencies {" not in gt:
        die("no dependencies block in " + gradle.name)
    gt = gt.replace("dependencies {", "dependencies {\n" + dep, 1)
    gradle.write_text(gt)

# --- 6. Final validation (before Gradle starts) ---
for name in FILES:
    f = dest / name
    first = f.read_text().splitlines()[0]
    if first.strip() != "package " + pkg + ";":
        die(name + " wrong package line: " + first)
    print("OK file : " + str(f.relative_to(ANDROID)) + "  [" + first + "]")
if main.read_text().count("OrbitBrowserPlugin.class") != 1:
    die("MainActivity registration check failed")
if manifest.read_text().count("OrbitBrowserActivity") != 1:
    die("manifest Activity count != 1")
if manifest.read_text().count("OrbitReminderReceiver") != 1:
    die("manifest Receiver count != 1")
if manifest.read_text().count("OrbitWidgetProvider") != 1:
    die("manifest Widget receiver count != 1")
if ".fileprovider" not in manifest.read_text():
    die("manifest has no .fileprovider")
if "<cache-path" not in fp_xml.read_text():
    die("file_paths.xml has no cache-path")
if manifest.read_text().count("android.permission.RECEIVE_BOOT_COMPLETED") != 1:
    die("RECEIVE_BOOT_COMPLETED count != 1")
if manifest.read_text().count("android.permission.POST_NOTIFICATIONS") != 1:
    die("POST_NOTIFICATIONS count != 1")
if manifest.read_text().count("@mipmap/orbit_launcher") != 2:
    die("manifest icon / roundIcon not both set to @mipmap/orbit_launcher")
for f in ("drawable-nodpi/orbit_icon_fg.png", "drawable/orbit_icon_bg.xml", "mipmap-anydpi-v26/orbit_launcher.xml", "mipmap-nodpi/orbit_launcher.png"):
    if not (res_dest / f).exists():
        die("missing launcher icon resource " + f)
if manifest.read_text().count("OrbitKeepAliveService") != 1:
    die("manifest KeepAlive service count != 1")
for perm in EXTRA_PERMS:
    if manifest.read_text().count('android:name="android.permission.' + perm + '"') != 1:
        die(perm + " count != 1")
if 'android:supportsPictureInPicture="true"' not in manifest.read_text():
    die("manifest Activity lacks supportsPictureInPicture")
if gradle.read_text().count("androidx.webkit:webkit") != 1:
    die("webkit dependency count != 1")
print("OK MainActivity registers OrbitBrowserPlugin; manifest + gradle patched once")
